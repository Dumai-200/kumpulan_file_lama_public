# decrypt
ini adalah tools decrypt script termux

# penginstalan 

pkg update 

pkg upgrade

pkg install git

pkg install python

git clone https://github.com/Hakiki-XC/decrypt

cd decrypt 

python dec.pyc

# screenshot
<img src="https://github.com/Hakiki-XC/decrypt/blob/main/Screenshot_2021-05-03-15-38-05-526_com.termux.jpg">
# note 
jika ada bug bisa lapor ke saya

no gw : 085946352369
