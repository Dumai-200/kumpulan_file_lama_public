# Cara Install
$ apt update && apt upgrade<br>
$ pkg install python<br>
$ pkg install git<br>
$ git clone https://github.com/nnda-id/CompilePy<br>
$ cd CompilePy<br>
$ python compiler.py<br>
or<br>
$ python2 compiler.py<br>
<br>
# UPDATE<br>
Work for python2 & python3
# Cara MenggunakanNya
1. Saat kalian ingin mengcompile script python menggunakan tools ini pastikan menjalankan tools ini menggunakan versi yang sama dengan script yang mau di compaile misalnya: kalian punya script python2 maka saat menjalankan tools inipun harus menggunakan python2 ('$ python2 compiler.py') begitupun sebaliknya<br>
2. Setalah kalian menjalankan tools ini masukan input pilihan. Harus sama dengan versi python yang mau di compile dan harus sama dengan versi saat menjalankan tools ini!
3. Lalu masukan file yang mau di compile. versi python dari file tsb harus sama juga ya.
