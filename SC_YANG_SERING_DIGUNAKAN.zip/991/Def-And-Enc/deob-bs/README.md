![](https://img.shields.io/badge/python-3.8.x-yellowgreen)
##### required
[Argparse](https://pypi.org/project/argparse/)

[Python3.8.x](https://www.python.org/downloads/)

##### One command
--------
```
cat file.sh | sed 's/eval/echo/' | sh > out.sh && cat out.sh
```
--------

Mungkin bisa membantu ,atau mungkin juga tidak
Karena sesuatu akan terasa lebih berguna pada tempatnya
Masing masing

[Bash-obfuscate](https://www.npmjs.com/package/bash-obfuscate)
