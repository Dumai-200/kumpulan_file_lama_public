#Hahaha DiPreng
#Xnxx Lu
import time, os, sys
time.sleep(1)
print("Hahahah Kang Recoder :)")
time.sleep(1)
time.sleep(1)
time.sleep(1)
print("Cieee Sampe Disini Tuh:)")
