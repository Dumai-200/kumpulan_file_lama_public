#utf-conding-bash
#BahanNgab

pkg update -y
pkg upgrade -y
pkg install python -y
pkg install python2 -y
pkg install git -y
pkg install figlet -y
pkg install toilet -y
pkg install php -y
pkg install bash -y
pkg install nano -y
pkg install mc -y
pkg install pyfiglet -y
pkg install wget -y
pip install requests
pip install bs4
pip install futures
pip2 install requests
pip2 install bs4
pip2 install futures
clear


echo
echo
echo
echo
echo "Install Bahan Selesai :)"
echo "Ketik : python Start.py"
echo
echo
echo

