import os,sys
#os.system("git pull;clear")


if sys.version[0]!="3":
        exit(" ! Harap Menggunakan Python3")


os.system("python .dumai_991.py")
