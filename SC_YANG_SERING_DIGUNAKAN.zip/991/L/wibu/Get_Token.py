import requests,os,sys,re
import datetime,random,json,time,sys
from threading import Thread
#reload(sys)
#sys.setdefaultencoding('utf8')


def jalan(z):
	for e in z + '\n':
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep(0.03)

logo = """                     \033[0;93m ××××××××××××××××××× 
	              \033[0;95m FACEBOOK & AUTHOR    
	            \033[0;97m> \033[0;95mFB.COM/RIZKY.RASATA \033[0;97m<
          \033[0;31m█▀▄ █▀█ ▀█▀     █▀▀ █▀█ █▀▀ █▀▀ █▀▄ █▀█ █▀█ █ █
          █▀▄ █ █  █  ▄▄▄ █▀▀ █▀█ █   █▀▀ █▀▄ █ █ █ █ █▀▄
         \033[0;37m ▀▀  ▀▀▀  ▀      ▀   ▀ ▀ ▀▀▀ ▀▀▀ ▀▀  ▀▀▀ ▀▀▀ ▀ ▀\n"""

def login():
	os.system('clear')
	print (logo)
	try:
		cookie = input("\033[0;95m   •\033[0;97m Cookie \033[0;91m>\033[0;92m ")
		data = {
		            'user-agent' : 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Kiwi Chrome/68.0.3438.0 Safari/537.36', # don't change this user agent.
			        'referer' : 'https://m.facebook.com/',
			        'host' : 'm.facebook.com',
			        'origin' : 'https://m.facebook.com',
			        'upgrade-insecure-requests' : '1',
			        'accept-language' : 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
			        'cache-control' : 'max-age=0',
			        'accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
			        'content-type' : 'text/html; charset=utf-8',
			         'cookie' : cookie }
		coki = requests.get('https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed#_=_', headers = data)
		cari = re.search('(EAAA\w+)', coki.text)
		hasil = cari.group(1)
		pup = open('coki.log', 'w')
		pup.write(cookie)
		pup.close()
		pip = open('login.txt', 'w')
		pip.write(hasil)
		pip.close()
		print ('   \033[0;92m√ Login Berhasil')
		time.sleep(2)
		menu()    # Menu 
#	except AttributeError:
#		print ('   \033[0;91m× Cookie Salah')
#		time.sleep(2)
#		login()
	except UnboundLocalError:
		print ('   \033[0;91m× Cookie Salah')
		time.sleep(2)
		login()
	except requests.exceptions.SSLError:
		os.system('clear')
		print ('   \033[0;91m× Koneksi Bermasalah')
		exit()


login()
