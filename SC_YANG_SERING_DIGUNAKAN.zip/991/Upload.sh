cd Siap
git remote add origin https://github.com/Dumai-991/App-Heroku.git
git init
git add *
git commit -m "Script Dalam Kendala Karena Hp Mimin Rusak"
#git push
git push --set-upstream origin master
