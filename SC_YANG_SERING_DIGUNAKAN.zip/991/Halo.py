#################################################
import os,sys,requests,json,time,string		#
from datetime import datetime			#
from random import randint			#
from random import choice
import getpass,platform
import platform
import random
import itertools
import threading
import time
from requests import Session
import re, sys
import sys
from os import system
import os, sys, time, random
from sys import exit as keluar
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from sys import stdout
from os import system
#l#        exit()
#        exit(f"\r\n{m3}Ketik : python Mulai.py{q}")
#        sys.exit(f"\r\n{m3}Ketik : python Mulai.py{q}")
#	kata(f"{b3}Maaf Anda Salah Ketik Python... Silahkan Ketik : python Mulai.py{q}")
#################################################
#Jangan DiEditNantik Rusak***
#################################################
#Memek						#
#TambahAja Sendiri Asu				#
#################################################
#Import Jangan DiEdit Nantik Rusak :V Serisusn  #
#################################################
#KodeWarna Bash Python Python2 Php Json Js DLL
#################################################


#SEMOGA YANG RECODER ANAK ANJING MANDUL 8 TAHUN IYA ALLAH...!!!
#KONTOL KECIL JEMBUT LEBAT..  AMIN... SEMOGA YANG RECODER PENDEK UMHR...
#ANAK ANJING KALIAN SEMUA ANAK RECODER... MEMEK ENGTOT...
#RECODER MEMEk
now = datetime.now()
mm = str(now.month)  #Bulan
dd = str(now.day)    #Tanggal
yyyy = str(now.year) #Tahun
hour = str(now.hour) #Jam
mi = str(now.minute) #Menit
ss = str(now.second) #Detik
m = '\x1b[1;91m'
h = '\x1b[1;92m'
k = '\x1b[1;93m'
b = '\x1b[1;94m'
u = '\x1b[1;95m'
c = '\x1b[1;96m'
p = '\x1b[0m'
i = '\x1b[1;90m'
v = '\x1b[1;38;5;198m'
j = '\x1b[1;38;5;208m'
w = (m, v, j, p, k, b, u, c)
W = pilih(w)
xnxx="\033[85m"
q="\033[00m"
h2="\033[40m"
b2="\033[44m"
c2="\033[46m"
i2="\033[42m"
u2="\033[45m"
m2="\033[41m"
p2="\033[47m"
k2="\033[43m"
b='\033[1;34m'
i='\033[1;32m'
c='\033[1;36m'
m='\033[1;31m'
u='\033[1;35m'
k='\033[1;33m'
p='\033[1;37m'
h='\033[1;90m'
k3="\033[43m\033[1;37m"
b3="\033[44m\033[1;37m"
m3="\033[41m\033[1;37m"
tang="03 - 05 - 2021 Senin"
duit="https://ifile.cc/BgZu"
xn="""Username AllTools : Anak
 Password AllTools : Conding 
wa.me/6283143565470"""
grup="https://chat.whatsapp.com/LwR9NQFlHUZ5KvzFdWjbyf"
linkwa="https://wa.me/6283143565470"
hp="1"
hp1="1"
user1="Vvip"	#UserName 01
pass1="Love"	#PassWord 01
list01="Bidmzz1sjsjsjb170074ac846042f3593728"
list02="Bidmzz1sJ2L1TKyqaMEU"
list03="b170074ac846042f35937286"
list04="Premium"
def jam1():
	now = datetime.now()
	mm = str(now.month)  #Bulan
	dd = str(now.day)    #Tanggal
	yyyy = str(now.year) #Tahun
	hour = str(now.hour) #Jam
	mi = str(now.minute) #Menit
	ss = str(now.second) #Detik
	kata("""{k}Time {u}:{i} {hour} {k}–{i} {mi} {u}–{c} {ss}
{k}Date {u}:{i} {dd} {k}–{i} {mm} {u}–{c} {yyyy}""")


#Time : {hour} – {mi} – {ss}
#Date : {dd} – {mm} – {yyyy}

def tes01(mmk):
	stdout.write(mmk),;waktu(2);stdout.flush()
def list1():
	bash("clear")
	kata3(f"""{i}----------------------------------------------------------------
{k}- {c}Silahkan Masukan List Atau Serial Script AllTools !!!
{k}- {c}Jika Tidak Punya List Atau Serial Silahkan Beli..!!!
{k}- {c}Atau Donasi Untuk DiPublickan...!!!
{i}----------------------------------------------------------------
{k}- {p}Ketik >CHAT< Untuk Chat Sama Admin Lewat Whatsapp !!
{k}- {p}Ketik >GRUB< Untuk Join KeGrub WhatsApp Untuk Info Lebih Lanjut !!
{k}- {p}Ketik >GET< Untuk Ambil List Atau Serial Lewat Browsing !!!
{i}----------------------------------------------------------------
{k}- {p}Pulsa : 083143565470
{k}- {p}Dana  : 083143565470
{k}- {p}Gopay : 083143565470
{k}- {p}No Wa : 6283143565470
{i}----------------------------------------------------------------
{k}- {c}Jangan Lupa Donasi Iya Ngab Plis!!!
{k}- {c}Jika Anda Mau Donasi Seiklasnya Aja Iya.... : )
{k}- {c}Rp15.000 - Rp50.000
{k}- {c}Semoga Yabg Donasi DiLancarkan Rezekinya Semoga DiBeri KeMudagan...
{k}- {c}Semoga Panjang Umur.... Semoga Keluarga Sehat Selalu....
{k}- {c}Terima Kasih !!!!
{i}----------------------------------------------------------------
CTRL + Z Exit""")
	gr=input(f"{p}Serial—⟩⟩ {c}")
	if gr == "":
		kata(f"{k}Jangan Kosonv Sayang...")
		detik(00, 50)
		list1()
	elif gr == "CHAT":
		time.sleep(1)
		bash("xdg-open https://wa.me/6283143565470?text=Hallo+Bang")
		detik(00, 50)
		list1()
	elif gr == "GRUB":
		time.sleep(1)
		bash("xdg-open https://chat.whatsapp.com/LwR9NQFlHUZ5KvzFdWjbyf")
		detik(00, 50)
		list1()
	elif gr == (f"{list01}") or gr == (f"{list02}") or gr == (f"{list03}"):
		time.sleep(1)
		kata4(f"{c}Silahkan Tunggu Sebentar... Sedang Check List Atau Serial Anda !!")
		kata4(f"{c}Sedang DiCheack !! ");tik11()
		kata(f"{p}\rList Atau Serial Anda Benar !!")
		bash("sleep 3")
		welcome()
	elif gr == (f"{list04}"):
		time.sleep(1)
		kata4(f"{i}Tunggu Sebentar... Sedang Cheack Status Anda !!");tik11()
		kata4(f"{p}\r Dona Status Anda Premium !!")
		bash("sleep 2")
		hidemenu()
	elif gr == "GET":
#		bash("xdg-open ")
		kata4(f"{p}Maaf Belum Ada Yang Donasi Silahkan Donasi SeIkhlasnya !!")
		detik(00, 50)
		list1()
	else:
		kata(f"{m}!! {c}Maaf Pilihan Anda Tidak TerDaftad !!")
		detik(00, 40)
		list1()
def welcome1():
	bash("clear")
	kata3(f"""\r{i}_______________¶
______________¶¶¶
____________¶¶¶_¶¶¶
__________ _¶¶¶___¶¶¶
_____¶¶¶¶¶¶¶¶_____¶¶¶¶¶¶¶¶¶
______¶¶¶______________¶¶¶
_______¶¶¶____________¶¶¶{k}
______¶¶¶______________¶¶¶
_____¶¶¶¶¶¶¶¶_____¶¶¶¶¶¶¶¶¶
___________¶¶¶___¶¶¶
__________ __¶¶¶_¶¶¶
______________¶¶¶¶
_______________¶¶{q}\r
{m3}░██╗░░░░░░░██╗███████╗██╗░░░░░{b3}░█████╗░░█████╗░███╗░░░███╗███████╗{q}
{m3}░██║░░██╗░░██║██╔════╝██║░░░░░{b3}██╔══██╗██╔══██╗████╗░████║██╔════╝{q}
{m3}░╚██╗████╗██╔╝█████╗░░██║░░░░░{b3}██║░░╚═╝██║░░██║██╔████╔██║█████╗░░{q}
{m3}░░████╔═████║░██╔══╝░░██║░░░░░{b3}██║░░██╗██║░░██║██║╚██╔╝██║██╔══╝░░{q}
{m3}░░╚██╔╝░╚██╔╝░███████╗███████╗{b3}╚█████╔╝╚█████╔╝██║░╚═╝░██║███████╗{q}
{m3}░░░╚═╝░░░╚═╝░░╚══════╝╚══════╝{b3}░╚════╝░░╚════╝░╚═╝░░░░░╚═╝╚══════╝{q}
{c}@Mr.Risky
@Liris 31-04-2021
@AKIRABOTS AND ATTACKBOTS
@6283143565470
@Dana : 083143565470
@Pulsa: 083143565470{q}

{k}Time {u}:{i} {hour} {k}–{i} {mi} {u}–{c} {ss}
{k}Date {u}:{i} {dd} {k}–{i} {mm} {u}–{c} {yyyy}

{c}({k}★{c}){i}x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×x×{c}({k}★{c})
{c}({k}★{c}){i}Pilih Untuk Lanjut Sayang !!
{k}({i}1{k}){p} Login AllTools !!
{k}({i}2{k}){p} Get Username And Password
{k}({i}3{k}){p} Join Grub WhatSapp Attack In From Cyber
{k}({i}4{k}){p} Rreport
{k}({i}5{k}){p} Intall Bahan (Wajib)
{k}({i}6{k}){p} Quit""")
	wel=input(f"{c}({i}?{c}){p} Mr.Risky {c}")
	if wel == "":
		kata5(f"{m}!! {p}Jangan Kosong Sayanv")
		detik(00, 60)
		welcome1()
	elif wel == "1" or wel == "01":
		trial()
		welcome1()
	elif wel == "2" or wel == "02":
		kata(f"{p}Anda Akan Lanjut Download Fils Atau Sebagainya !!")
		down()
	elif wel == "3" or wel == "03":
		kata(f"{p}Anda Akan Lanjut KeGrub Whatsapp Attack In From Cyber")
		bash(f"xdg-open {grup}")
		welcome1()
	elif wel == "4" or wel == "04":
		kata(f"{p}Anda Akan Lanjut KeWhatSapp Admin !!")
		bash("xdg-open {linkwa}")
		detik(00, 30)
		welcome1()
	elif wel == "5" or wel == "05":
		kata(f"{c}Anda Akan Lanjut Install Bahan {m}!!")
		pkg=("""
pkg update && pkg upgrade
pkg update && pkg upgrade
pkg install python
pkg install python2
pkg install bash
pkg install php
pkg install nano
pkg install jq
pkg install node
pkg install cowsay
pkg install figlet
pkg install pyfiglet
pkg install toilet
pkg install lolcat
pkg install mc
pkg install python3
gem install lolcat
gem install lolcat
pip install gem
pkg install python
pkg install toilet
pkg install lolcat
pkg install cowsay
pkg install figlet
pkg install bash
pkg install nano
pkg install mc
pkg install jq
pkg install wget
pkg install php
gem install lolcat
pkg install python2
pkg install git
pkg install bs4
pip2 install requests
pip2 install mechanize""")
		bash(pkg+" -y")
		kata(f"{p}Install Bahan Done !!! ")
		welcome1()
	else:
		kata5(f"{m}!!! {i}Pilihan Anda Tidak Terdaftar !!")
		detik(00, 20)
		welcome1()
def down():
	bash("clear")
	kata3(f"""\r
{c}╭━━━╮╱╱╭╮╱{i}╭╮╱╭╮╱╱╱╱╱╱╱╱{k}╭━━━╮╱╱╱╱╭╮{m}╭━━━╮ 
{c}┃╭━╮┃╱╭╯╰╮{i}┃┃╱┃┃╱╱╱╱╱╱╱╱{k}┃╭━╮┃╱╱╱╱┃┃{m}┃╭━╮┃ 
{c}┃┃╱╰╋━┻╮╭╯{i}┃┃╱┃┣━━┳━━┳━╮{k}┃┃╱┃┣━╮╭━╯┃{m}┃╰━╯┣━━┳━━┳━━╮ 
{c}┃┃╭━┫┃━┫┃╱{i}┃┃╱┃┃━━┫┃━┫╭╯{k}┃╰━╯┃╭╮┫╭╮┃{m}┃╭━━┫╭╮┃━━┫━━┫ 
{c}┃╰┻━┃┃━┫╰╮{i}┃╰━╯┣━━┃┃━┫┃╱{k}┃╭━╮┃┃┃┃╰╯┃{m}┃┃╱╱┃╭╮┣━━┣━━┃ 
{c}╰━━━┻━━┻━╯{i}╰━━━┻━━┻━━┻╯╱{k}╰╯╱╰┻╯╰┻━━╯{m}╰╯╱╱╰╯╰┻━━┻━━╯ 
{c}Ꮆ🝗〸 {i}ㄩ丂🝗尺 {k}闩𝓝ᗪ {m}尸闩丂丂

{u}[{i}¥{u}]{c}<><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><>{u}[{i}¥{u}]
{u}[{i}${u}]{k}Silahkan Pilih Untuk Mendapatkan Username Dan Password !!
{u}[{i}1{u}]{p}Via Donasi
{u}[{i}2{u}]{p}Via Sms
{u}[{i}3{u}]{p}Via Whatsapp
{u}[{i}4{u}]{p}Via DownLoad
{u}[{i}5{u}]{p}Exit Ans Qiut
{u}[{i}6{u}]{p}Back To Welcome""")
	gx=input(f"{p}[{i}?{p}]{i}+++{k}⟩⟩ {c}")
	if gx == "":
		print(f"{m}Kosong ???!"),;tes01(f"{p}Isi Dengan Benar")
		time.sleep(2)
		detik(00, 45)
		down()
	elif gx == "1" or gx == "01":
		donasi()
		time.sleep(5)
		detik(00, 45)
		down()
	elif gx == "2" or gx == "02":
		sms()
		kata5("""Silahkan Tunggu Hingga Terkirim Sms KeHp Anda...
Jika Sudah Terkirim Lihat Saja DiSms (Pesan)""")
		down()
	elif gx == "3" or gx == "03":
		detik(00, 45)
		bash("xdg-open https://wa.me/6283143565470?text=Bang+Minta+Username+Sama+Password+*AllTools*+Saya+Mohon+Pelis+Mr.Risky+Ganteng+")
		time.sleep(5)
		detik(00, 45)
		bash("xdg-open https://wa.me/6283143565470?text=Bang+Minta+Username+Sama+Password+*AllTools*+Saya+Mohon+Pelis+Mr.Risky+Ganteng+")
		time.sleep(5)
		down()
	elif gx == "4" or gx == "04":
		kata5("""Anda Akan Lanjut KeBrosing Untuk Downloas File Usee Sama Pass !!!
Jika Terjadi Masalah Silahkan Chat Admin Ok ...
wa.me/6283143565470""")
		detik(00, 45)
		bash(f"xdg-open {duit}")
		time.sleep(2)
		down()
	elif gx == "5" or gx == "05":
		detik(00, 45)
		kata5(f"{m}BYE BYE BYE")
		sys.exit()
	elif gx == "6" or gx == "06":
		detik(00, 45)
		welcome1()
	else:
		kata4(f"{c}ISI DENGAN BENAR !!")
		time.sleep(2)
		down()

def error():
	kata(f"""{q}
{c}[{m}!{c}]{q} {m3}Sedang MengAlamai Masalah :V{q}

{c}[{m}!{c}]{q}{m3} Hub Adm!n :https://wa.me/6283143565470{q}
{c}[{m}!{c}]{q}{m3} Mr.Risky{q}""")
	bash("xdg-open https://wa.me/6283143565470?text=Bang+Kapan+Selesai+Perbaiki+???+")
def tik11():
    text = ["⟩   ","⟩⟩  ","⟩⟩⟩ ","⟩⟩   ","⟩   ","     ","Done !!"]
    for o in text:
            waktu(1)
            stdout.write(f"\r{u}[{i}+{u}]{p}Loading {i}"+o+""),;stdout.flush()
def tik12(ok):
    text = (f"{ok}"*1,f"{ok}"*2,f"{ok}"*3,f'{ok}'*4,f"{ok}"*5,f"{ok}"*4,f"{ok}"*3,f'{ok}'*2,f"{ok}"*1,f"         ")
    for o in text:
            waktu(0.8)
            stdout.write(f"\r{u}[{i}+{u}]{p}Loading {i}{o}"),;stdout.flush()


def main0():
	bash("git pull;reset")
#	musik()
#	botwa01()
	list1()
	welcome1()
#	down()
#	fbx()
#	donasi()
#	trial()
#	hide()  #Masih Tahap
#	jj()
#	sys.exit

def main2():
	myip()
	bash("git pull")
	info()
	bash("clear;reset")
	engtot()
def textfast():
	bash("reset")
	kata(f"\r\n\n{c}[{m}!{c}]{c}Script Sudah DiUpdate Pada Tanggal : {q}{m3}15 – 4 – 2021 Kamis")
	kata3(f"""\r\r{b3}Hallo...!!! Silahkan Masukan Username Dan Password Untuk Login...
{m3}Username Dan Password Khusus Bukan Username Dan Password Facebook !!

Jika Anda Mau Daftar Username Dan Passwors Silahkan Chat Admin..!{q}
{c}Whatsapp : {m3}+6283143565470{q}
{c}Email    : {m3}santuyaja019@gmail.com{q}
{c}Via Pulsa: {m3}083143565470{q}
{c}Dana     : {b3}083143565470{q}
{c}Link Aja : {b3}—{q}
{c}Shopey   : {b3}082169796727{q}
{m3}[ Dan Jangan Lupa Donasi ] [AXI5]{q}
{b3}Jika Anda Mempunyai Username Dan Password Jangan DiShare KePada Orang
Script Ini Sekarang Sudah PREMIUM...
Pahamkan Kak...{q}{m}!!!{q}
""")
	myip()
	loginv2()
def trial():
	tik11()
	run(f"{p}Script Ini Sudah DiUpdate... Hide Menu Sudah DiPerbarui")
	bash("sleep 2;reset;clear")
	kata(f"\r\n\n{c}[{m}!{c}]{c}Script Sudah DiUpdate Pada Tanggal : {q}{m3}{tang}{q}")
	kata3(f"""\r\r{b3}Hallo...!!! Silahkan Masukan Username Dan Password Untuk Login...
{m3}Username Dan Password Khusus Bukan Username Dan Password Facebook !!

Jika Anda Mau Daftar Username Dan Passwors Silahkan Chat Admin..!{q}
{c}Whatsapp : {m3}+6283143565470{q}
{c}Email    : {m3}santuyaja019@gmail.com{q}
{c}Via Pulsa: {m3}083143565470{q}
{c}Dana     : {b3}083143565470{q}
{c}Link Aja : {b3}—{q}
{c}Shopey   : {b3}—{q}
{m3}[ Dan Jangan Lupa Donasi ] [AXI5]{q}
{b3}Jika Anda Mempunyai Username Dan Password Jangan DiShare KePada Orang
Script Ini Sekarang Sudah PREMIUM...
Pahamkan Kak...{q}{m}!!!{q}
""")
	myip()
	loginv2()
def loginv2():
	kata(f"Login Menggunakan Hasil Daftar Tadi...!!")
	kang=input(f"{c}[{m}®{u}]{i} Username : {c}")
	if kang =="" or kang ==" ":
		kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
		bash("sleep 2")
		textfast()
	elif kang =="Anak" or kang =="anak":
		kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
		bash("sleep 2")
		kntl=getpass.getpass(f"{c}[{m}©{u}]{i} Password : {c}")
		if kntl =="" or kntl ==" ":
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
		elif kntl =="Conding" or kntl =="conding":
			kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
			bash("sleep 2")
			viapulsa()
		else:
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
	elif kang == (f"{user1}") or kang == (f"{user1}"):
		kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
		bash("sleep 2")
		kntl=getpass.getpass(f"{c}[{m}©{u}]{i} Password : {c}")
		if kntl =="" or kntl ==" ":
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
		elif kntl == (f"{pass1}") or kntl == (f"{pass1}"):
			kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
			bash("sleep 2")
			viapulsa()
		else:
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
	elif kang == (f"{hp}") or kang == (f"{hp}"):
#		kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
		kata(f"""
{p}Maaf Tools Ini Tidak Menerima Lagi Daftar Menggunakan Akun Facebook !
Jika Mau Username Sama Password Silahakan Gabunv KeGrub Whatsapp !!
Yang Tanya Chennel Admim Apa.... !! Entar Gw Tabuk Lu... Udah Tau..
Admin Engga Punya Chennel YouTube !!!
{m}
#AdmimTidakPunyaChennelYouTube!!
#JanganSpamAdmin
#SpamAdminSamaDenganDosa!!
#NotSpaming!!
#Mr.Risky""")
		bash("sleep 2")
		musik()
		sys.exit()
		kntl=getpass.getpass(f"{c}[{m}©{u}]{i} Password : {c}")
		if kntl =="" or kntl ==" ":
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			musik()
			textfast()
		elif kntl == (f"{hp2}") or kntl == ("{hp2}"):
			kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
			bash("sleep 2")
			musik()
			musik()
			musik()
			viapulsa()
		else:
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
	elif kang =="Trial-02":
		kata(f"{i}Maaf Trial Ini Sudah Habis {m}!!")
		kata(f"{i}Hubungi Admin Jika Mau Beli Trial {m}!!")
		sys.exit()
#TrialSudahHabis -_-
		kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
		kata(f"{u}[{i}✓{u}] {i}Trial Akan Habis Pada Tanggal {q}{m3}[10 — 04 — 2021]{q} {m}!!")
		bash("sleep 2")
#End SudahHabisMasahBerlaku
		kntl=getpass.getpass(f"{c}[{m}©{u}]{i} Password : {c}")
		if kntl =="" or kntl ==" ":
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
		elif kntl =="Free" or kntl =="Free":
			kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
			kata(f"{u}[{i}✓{u}] {i}Trial Akan Habis Pada Tanggal {q}{m3} [10 — 04 — 2021] {m}!!")
			bash("sleep 2")
			viapulsa()
		else:
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
	elif kang =="Mr":
#		kata(f"{i}Maaf Trial Ini Sudah Habis {m}!!")
#		kata(f"{i}Hubungi Admin Jika Mau Beli Trial {m}!!")
#		sys.exit()
		kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
#		kata(f"{u}[{i}✓{u}] {i}Trial Akan Habis Pada Tanggal {q}{m3}[10 — 04 — 2021]{q} {m}!!")
		bash("sleep 2")
		kntl=input(f"{c}[{m}©{u}]{i} Password : {c}")
		if kntl =="" or kntl ==" ":
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
		elif kntl =="Risky" or kntl =="risky":
			kata(f"{u}[{i}✓{u}] {i}Login Suksess {m}!!")
#			kata(f"{u}[{i}✓{u}] {i}Trial Akan Habis Pada Tanggal {q}{m3} [10 — 04 — 2021] {m}!!")
			bash("sleep 2")
			viapulsa()
		else:
			kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
			bash("sleep 2")
			textfast()
	else:
		kata(f"{u}[{m}×{u}]{i} Failed Or Wrong {m}!!")
		bash("sleep 2")
		textfast()
def donasi():
	kata(f"""{p}
Hallo Member Setia !!!

Saya Mau Mengatakan... Hp Mimin Pecah / Rusak Jadi Bagi Yanv Mempunyai
Kasih Sayanv Bagi Dong Donasinya :( 
Hp Mimin Rusak....

{i}Dana {c}083143565470
{i}Dana {c}083143565470
{k}Rp10.000 — Rp50.000+..{p}
Plis Bangat..... Maaf Iya Saya Tidak Memaksa Kok !!! :(
Plis :'(
Plis :'(
Jika Hp Mimin Begini Terus Hp Kapan Script Ini Berkembang
Jika Hp Mimin Begini Terus Hp Kapan Script Ini Berkembang
Terima Kasib Atas Priatinnha !!""")
def sms():
     nx=input(f"{p}Nomor Hp :{c} 08")
     qw = (f"08{nx}")
     qw = (f"+628{nx}")
     qw = (f"628{nx}")
     qw = (f"8{nx}")
     try:
#Nomor Hp Admin
#          no="083143565470"
#          no="6283143565470"
#          no="83143565470"
#          no="+6283143565470"
#          no="083143565470"
#          no="6283143565470"
#          no="83143565470"
#          no="+6283143565470"
          dat={
          "number": qw,
          "pesan": xn
          }
          br=requests.post("https://nuubi.herokuapp.com/api/smsgratis", data=dat).text
          if "SMS Gratis Telah Dikirim" in br:
              print(f"\n\033[1;97m[\033[1;92m✓\033[1;97m]Daftar Suksess \033[1;96mGet User And Pass \033[1;92mSuccess")
          elif "Terjadi kesalahan!" in br:
              kata("\n\033[1;97m[\033[1;91mx\033[1;97m]\033[1;91mDaftar Gagal\033[00m")
          else:
              print(f"\n\033[1;97m[\033[1;91mx\033[1;97m]Daftar \033[1;96m Get Used And Pass\033[1;91mFailed\033[00m")
          br=requests.post("https://nuubi.herokuapp.com/api/smsgratis", data=dat).text
          if "SMS Gratis Telah Dikirim" in br:
              print(f"\n\033[1;97m[\033[1;92m✓\033[1;97m]Sms To \033[1;96m"+qw+" \033[1;92mSuccess")
          elif "Terjadi kesalahan!" in br:
              kata("\n\033[1;97m[\033[1;91mx\033[1;97m]Pesan Gagal Dikirim\033[1;91m!!!\033[00m")
          else:
              print(f"\n\033[1;97m[\033[1;91mx\033[1;97m]Sms To \033[1;96mGagal Get Usee And Pass \033[1;91mFailed\033[00m")
#     except TypeError:
#            print("\033[1;97m\033[1;91m•\033[1;97m]Gagal Daftar !!\033[1;91m!\033[00m")
     except (KeyboardInterrupt,EOFError):
            sys.exit()
#     except requests.exceptions.ConnectionError:
#	    print("\033[1;97m[\033[1;91m!\033[1;97m]\033[1;91mConnection Error\033[00m")
     detik(00, 55)
     down()
def myip():
	link=('https://api.myip.com/')
	re=requests.get(link)
	j=json.loads(re.text)
	kata3(f"{i}Sedang MengCheck Ip You {m}!! ")
	kata(f'{b3}Server{q}{c} :   ' + j['country'])
	kata(f'{b3}Cc    {q}{c} :   ' + j['cc'])
	kata(f'{b3}Ip Kamu{q}{c}:   ' + j['ip'])
##Trial Free
def Erorr():
#	detik(30, 00)
	bash("reset")
#	musik()
	info()     #Informasi
#	error()    #Perbaiki
#	load3()
#	tik5()
#	wel()
	pwx()
#	main3()
def skip():     #Keuntungan Skip....!!!! :V
	bash("reset")
	baner()   #Benner Logo
	menu()    #Menu Untuk Dipilih
	halo()    #JikaErrorTerhadapSc
def hidemenu():
	bash("reset;git pull")
	bash("clear")
	hide()
def viapulsa():
	bash("reset;git pull")
	hidemenu()
#	baner()   #Benner Logo
#	menu()    #Menu Untuk Dipilih
#	halo()    #JikacErrorTerhadapSc

def main3():
	bash("clear && sleep 2")
	bash("git pull") #Jangab DiEditRusak 9999%
###############################
#AwasNatikRusakHahahahRecoder##
###############################
	clear()   #SemogaAndaColi
#	memek()   #Bkin Sakit Mata
	clear()   #Pembersih
	jam()     #JamSystemX
	baner()   #Benner Logo
	menu()    #Menu Untuk Dipilih
	halo()    #JikaErrorTerhadapSc
################################
#Tempat Untuk Jalan / Run Tools#
################################
#JanganDiEditNantikRusakTuduhSc#
################################
def run(teks):
    putih = (f"")
    merah = (f"{b3}")
    hapus = (f"{q}")
    teks = teks+" "
    try:
        num = 0
        while num < 1:
            for i,char in enumerate(teks):
                if i == 0:
                    sys.stdout.write('\r%s%s%s%s' % (putih,char.lower(),merah,teks[1:])),
                    sys.stdout.flush()
                else:
                    if i == 1:
                        zbl = teks[0].lower()
                        sys.stdout.write('\r%s%s%s%s%s%s' % (merah,zbl,putih,char.lower(),putih,teks[2:])),
                        sys.stdout.flush()
                    else:
                        if i == i:
                            zbl = teks[0:i].lower()
                            sys.stdout.write('\r%s%s%s%s%s%s' % (merah,zbl,hapus,char.lower(),putih,teks[i+1:])),
                            sys.stdout.flush()
                    time.sleep(0.1)
            num += 1
    except: exit()
def yangsuport(): #Yanv Telah Supurt Scriot allTools
	bash("figlet AcinaKongame | lolcat")
	print(f"""
{m3}╔═══╗─────────╔╗╔═╗      ╔═══╗{q}
{m3}║╔═╗║─────────║║║╔╝      ║╔═╗║{q}{b3}AcinaKongame♥{q}
{m3}║║─║╠══╦╦═╗╔══╣╚╝╝╔══╦═╗ ║║─╚╬══╦╗╔╦══╗{q}
{m3}║╚═╝║╔═╬╣╔╗╣╔╗║╔╗║║╔╗║╔╗╗║║╔═╣╔╗║╚╝║║═╣{q}
{m3}║╔═╗║╚═╣║║║║╔╗║║║╚╣╚╝║║║║║╚╩═║╔╗║║║║║═╣{q}
{m3}╚╝─╚╩══╩╩╝╚╩╝╚╩╝╚═╩══╩╝╚╝╚═══╩╝╚╩╩╩╩══╝{q}
""")
	bash("sleep 2")
def musik():
	bash("""mpv ~/AllTools/Get/""")

def hide():
	bash("reset;clear")
	kata(f"""{p}Silahkan Pilih Menu Untuk DiTampilakan... !!
Hapyy Bulan Ramadhan !!
Jangan Nakal Bentar Lagi Lebaran !!""")
	kata3(f"""{p}[{i}+{p}]{c}––––––––––-----––––––––––––––––––––––––––––––––––––{p}[{i}+{p}]

{p}██╗░░██╗██╗██████╗░███████╗{m}███╗░░░███╗███████╗███╗░░██╗██╗░░░██╗
{p}██║░░██║██║██╔══██╗██╔════╝{m}████╗░████║██╔════╝████╗░██║██║░░░██║
{p}███████║██║██║░░██║█████╗░░{m}██╔████╔██║█████╗░░██╔██╗██║██║░░░██║
{p}██╔══██║██║██║░░██║██╔══╝░░{m}██║╚██╔╝██║██╔══╝░░██║╚████║██║░░░██║
{p}██║░░██║██║██████╔╝███████╗{m}██║░╚═╝░██║███████╗██║░╚███║╚██████╔╝
{p}╚═╝░░╚═╝╚═╝╚═════╝░╚══════╝{m}╚═╝░░░░░╚═╝╚══════╝╚═╝░░╚══╝░╚═════╝░

{p}[{i}+{p}]{c}–––––-----–––––––––––––––––––––––––––––––––––––––––{p}[{i}+{p}]
[!].Hapyy Hide Menu And Bulan Ramadhan :D
{p}[{i}1{p}]{m}.{i}AllTools{c} @Dark Fb			{i}ON
{p}[{i}2{p}]{m}.{i}AllTools{c} @Spam Whatsapp		{m}OFF
{p}[{i}3{p}]{m}.{i}AllTools{c} @Spam Call			{m}OFF
{p}[{i}4{p}]{m}.{i}AllTools{c} @Spam Sms			{i}ON ✓
{p}[{i}5{p}]{m}.{i}AllTools{c} @End And Dom Script 	{m}OFF
{p}[{i}6{p}]{m}.{i}AllTools{c} @Bot Whatsapp		{i}ON ✓
{p}[{i}7{p}]{m}.{i}AllTools{c} @Semua Menu		{i}ON ✓
{p}[{i}0{p}]{m}.{c}Exit And Quit""")
	risky=input(f"[?]{p}.Hide Menu {k}⟩⟩⟩ {p}")
	if risky == "":
		print(f"{m}Jangan Kosonv Sayang !!!")
		hide()
	elif risky =="1" or risky =="01":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @Dark Fb")
		menudark()
#	elif risky =="2" or risky =="02":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @Spam Whatsapp")
		menuwa()
#	elif risky =="3" or risky =="03":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @Spam Call")
		menucall()
	elif risky =="4" or risky =="04":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @Spam Sms")
		menusms()
#	elif risky =="5" or risky =="05":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @End And Dom Script")
		menuend()
	elif risky =="6" or risky =="06":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @Bots Whatsapp")
		botwa01()
	elif risky =="7" or risky =="07":
		kata4(f"{p}Anda Akan Lanjut Menu AllTools @Semua Menu")
		main3()
	elif risky =="0":
		kata4(f"Terima Kasih Telah Menggunakan Tools Ini :D")
		sys.exit()
	elif risky =="2" or risky =="3" or risky =="4" or risky =="5":
		kata4(f"{p}Menu Ini Belum Selesai Tunggu Hingga Pemberitahuan... !!")
		kata4(f"Silahkan Pilih Menu 01 Atau 04 Atau 06 ")
		time.sleep(5)
		hidemenu()

	else:
		kata4(f"{c}Orang Sabar DiSayang Jada..")
		kata4(f"{p}Isi Dengan Benar Om {m}!!")
		detik(00, 20)
		hide()
def botwa01():
	bash("clear")
	kata3(f"""{p}[{k}★{p}]{q}{k3}XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX{q}{p}[{k}★{p}]
{q}{b3}
██████╗░░█████╗░████████╗░██╗░░░░░░░██╗░█████╗░░░░░░░██╗░░░██╗░░███╗░░
██╔══██╗██╔══██╗╚══██╔══╝░██║░░██╗░░██║██╔══██╗░░░░░░██║░░░██║░████║░░
██████╦╝██║░░██║░░░██║░░░░╚██╗████╗██╔╝███████║█████╗╚██╗░██╔╝██╔██║░░
██╔══██╗██║░░██║░░░██║░░░░░████╔═████║░██╔══██║╚════╝░╚████╔╝░╚═╝██║░░
██████╦╝╚█████╔╝░░░██║░░░░░╚██╔╝░╚██╔╝░██║░░██║░░░░░░░░╚██╔╝░░███████╗
╚═════╝░░╚════╝░░░░╚═╝░░░░░░╚═╝░░░╚═╝░░╚═╝░░╚═╝░░░░░░░░░╚═╝░░░╚══════╝{q}\r

{p}[{k}★{p}]{q}{k3}XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX XXX{q}{p}[{k}★{p}]
{p}[{k}1{p}]{p}———{k}⟩{i}⟩{c}Aq-WaBot		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} Narutomo V1
{p}[{k}2{p}]{p}———{k}⟩{i}⟩{c}Termux-Bot		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} MhankBarBar
{p}[{k}3{p}]{p}———{k}⟩{i}⟩{c}Termux-Wa-Bot		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} FXC7
{p}[{k}4{p}]{p}———{k}⟩{i}⟩{c}Termux-Wabot 		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} MhankBarBar
{p}[{k}5{p}]{p}———{k}⟩{i}⟩{c}Termux-Whatsapp-Bots 	{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} MrFzvx12
{p}[{k}6{p}]{p}———{k}⟩{i}⟩{c}AkiraBot-V3 		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} Akira
{p}[{k}7{p}]{p}———{k}⟩{i}⟩{c}AkiraBot-V1 		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} Akira
{p}[{k}8{p}]{p}———{k}⟩{i}⟩{c}SegeraHadir 		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} Mr.Risky
{p}[{k}9{p}]{p}———{k}⟩{i}⟩{c}SegeraHadir 		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} Mr.Risky
{p}[{k}10{p}]{p}——{k}⟩{i}⟩{c}SegeraHadir 		{i}⟨{k}⟨{p}———{k}⟩{i}⟩{c} """)
	pb=input(f"{p}[{k}!{i}!{p}]{p}——{k}⟩{i}⟩ {c}")
	if pb == "":
		kata5(f"{m}!! {p}Jangan Kosong Sayang")
		detik(00, 35)
		botwa01()
	elif pb == "1" or pb == "01":
		bahan()
		bash("""
pkg update && pkg upgrade
pkg install git -y
pkg install nodejs -y
pkg install ffmpeg -y
pkg install imagemagick -y
git clone https://github.com/Nurutomo/wabot-aq
cd wabot-aq
npm install
""")
	elif pb == "2" or pb == "02":
		bahan()
		bash("""
git clone https://github.com/MhankBarBar/whatsapp-bot
npm install gify-cli -g
npm i
npm start
""")
	elif pb == "3" or pb == "03":
		bahan()
		bash("""
termux-setup-storage -y
pkg update -y
pkg upgrade -y
pkg install python -y
pkg install git -y
git clone https://github.com/Fxc7/termux-bot-wa
cd termux-bot-wa
bash install.sh
npm start 
node Fxc7.js
""")
	elif pb == "4" or pb == "04":
		bahan()
		bash("""
pkg update
pkg upgrade
pkg install git
git clone https://github.com/MhankBarBar/termux-wabot
cd termux-wabot
bash install.sh
npm start
""")
	elif pb == "5" or pb == "05":
		bahan()
		bash("""
pkg update
pkg upgrade
pkg install git
git clone https://github.com/mrfzvx12/termux-whatsapp-bot
cd termux-whatsapp-bot
bash install.sh
npm start
""")
	elif pb == "6" or pb == "06":
		bahan()
		bash("""
pkg update
pkg upgrade
pkg install git
git clone https://github.com/AkiRaID/akirabotv3
cd akirabotv3
pkg install nodejs
pkg install ffmpeg
pkg install imagemagick
bash install.sh
node index.js
""")
	elif pb == "7" or pb == "07":
		bahan()
		bash("""
pkg update
pkg upgrade
pkg install git
git clone https://github.com/AkiRaID/akirabotv1.git
cd akirabotv1
pkg install nodejs
pkg install ffmpeg
pkg install imagemagick
bash install.sh
node index.js
""")
#	elif pb == "8" or pb == "08":
		bahan()
		bash("""

""")
#	elif pb == "9" or pb == "09":
		bahan()
		bash("""

""")
#	elif pb == "10":
		bahan()
		bash("""

""")
	elif pb == "00":
		kata5(f"{p}Anda Akan Kembali KeHideMenu")
		detik(00, 55)
		bash("reset")
		hidemenu()
	elif pb == "99":
		kata5(f"{m}BYE BYE BYE")
		detik(00, 60)
		bash("clear;cd;reset")
		sys.exit()
	else:
		kata5(f"{p}Maaf Pilihan {c}{pb}{p} Ini Tidak Terdaftar !! ")
		detik(00, 20)
		botwa01()
def menusms():
	bash("reset;clear")
	kata3(f"""\r\r\r
{p}╔═══╗────────{c}╔═══╦═╗╔═╦═══╗{i} ╭╮╱╱╱╱╱╱╱╭╮
{p}║╔═╗║────────{c}║╔═╗║║╚╝║║╔═╗║{i} ┃┃╱╱╱╱╱╱╭╯╰╮
{p}║╚══╦══╦══╦╗╔{c}╣╚══╣╔╗╔╗║╚══╗{i} ┃┃╱╱╭┳╮╭╋╮╭╯
{p}╚══╗║╔╗║╔╗║╚╝{c}╠══╗║║║║║╠══╗║{i} ┃┃╱╭╋┫╰╯┣┫┃
{p}║╚═╝║╚╝║╔╗║║║{c}║╚═╝║║║║║║╚═╝║{i} ┃╰━╯┃┃┃┃┃┃╰╮
{p}╚═══╣╔═╩╝╚╩╩╩{c}╩═══╩╝╚╝╚╩═══╝{i} ╰━━━┻┻┻┻┻┻━╯
{p}────║║{c}@Mr.Risky
{p}────╚╝{c}@DonasiBang

{p}[{k}★{p}]{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}⟩{k}⟩{i}Xx{p}xX{k}⟨{p}⟨{p}[{k}★{p}]
{p}[{k}★{p}]{c}Silahkan Pilih Menu Untuk DiInstall Om :)
{p}[{u}1{p}]{i}———{m}⟩⟩{k}SpamSms Brutal
{p}[{u}2{p}]{i}———{m}⟩⟩{k}SpamSms Elite And Brutal
{p}[{u}3{p}]{i}———{m}⟩⟩{k}SpamSms Call
{p}[{u}4{p}]{i}———{m}⟩⟩{k}SpamSms Sms
{p}[{u}5{p}]{i}———{m}⟩⟩{k}SpamSms 01
{p}[{u}6{p}]{i}———{m}⟩⟩{k}SpamSms 02
{p}[{u}7{p}]{i}———{m}⟩⟩{k}SpamSms 03
{p}[{u}8{p}]{i}———{m}⟩⟩{k}SpamSms 04
{p}[{u}9{p}]{i}———{m}⟩⟩{k}SpamSms 05
{p}[{u}10{p}]{i}——{m}⟩⟩{k}SpamSms 06
{p}[{u}00{p}]{i}——{m}⟩⟩{k}Back To Hide Menu
{p}[{u}99{p}]{i}——{m}⟩⟩{k}Quit""")
	gg=input(f"{p}[{u}??{p}]{i}——{m}⟩⟩{k} ")
	if gg=="":
		print("{m}Kosong ??")
		time.sleep(2)
		menusms()

	elif gg=="1" or gg=="01":
		bahan()
		os.system("""
apt update && apt upgrade
pkg update
pkg install python
git clone https://github.com/Anoncyb/Brutal-Spam
cd Brutal-Spam
python -m pip install -r install.txt
python brutal.py
""")
	elif gg=="2" or gg=="02":
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
pkg install python
pkg install python2
python *.py
python Halo.py
python2 *.py
clear
""")
	elif gg=="3" or gg=="03":
		bahan()
		os.system("""
pkg install python
pip install requests
git clone https://github.com/Xractz/SpamCall
cd SpamCall
python spam.py
""")
	elif gg=="4" or gg=="04":
		bahan()
		os.system("""
pkg install git
pkg install python3
pip install requests
git clone https://github.com/Xractz/SMS
cd sms
python spam.py
""")
	elif gg=="5" or gg=="05":
		bahan()
		os.system("""
apt update && pkg upgrade
apt install python
apt install git
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
python main.py
""")
	elif gg=="6" or gg=="06":
		bahan()
		os.system("""
apt install git
git clone https://github.com/fajarprasetiya/Spam-Sms
cd Spam-Sms
python prank.py
""")
	elif gg=="7" or gg=="07":
		bahan()
		os.system("""
pkg install python2
pkg install git
pip2 install requests
git clone https://github.com/MrproAL-404/spam-sms
cd spam-sms
python2 jail.py
""")
	elif gg=="8" or gg=="08":
		bahan()
		os.system("""
apt update && pkg upgrade
apt install python
apt install git
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
python main.py

""")
	elif gg=="9" or gg=="09":
		bahan()
		os.system("""
apt update && pkg upgrade
apt install python
apt install git
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
python main.py

""")
	elif gg=="10" or gg=="10":
		bahan()
		os.system("""
apt update && pkg upgrade
apt install python
apt install git
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
python main.py

""")
	elif gg=="00" or gg=="00":
		detik(00, 35)
		hide()
	elif gg=="99" or gg=="99":
		kata("{p}BYE BYE BYE \r")
		sys.exit()
	else:
		print(f"Error...")
		time.sleep(2)
		menusms()

def menuwa():
	bash("reset;clear")
	kata3(f"""\r\r\r
{p}[ {i}Jam »{p}{hour}{i}« Jam{m}——{i}Menit »{p}{mi}{i}« Menit{m}——{i}Detik »{p}{ss}{i}« Detik {p}]
{c}   S     P    A    M      W     A
{p}▒█▀▀▀█ █▀▀█ █▀▀█ █▀▄▀█ {i}▒█░░▒█ ░█▀▀█{c}@SystemX ProX
{p}░▀▀▀▄▄ █░░█ █▄▄█ █░▀░█ {i}▒█▒█▒█ ▒█▄▄█{c}@Mr.Risky
{p}▒█▄▄▄█ █▀▀▀ ▀░░▀ ▀░░░▀ {i}▒█▄▀▄█ ▒█░▒█{c}@Dumai-991
{p}[{i}+{p}]{c}––––––––––––––––––––––––––––––––––––––––––––––{p}[{i}+{p}]
{p}[{i}+{p}]{c}Athour        : Mr.Risky			 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}Whatsapp      : 6283143565470		 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}Facebook      : Risky			 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}Grup WhatSapp : Attack In Form Cyber		 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}––––––––––––––––––––––––––––––––––––––––––––––{p}[{i}+{p}]""")
	kata3(f"""
{p}[{i}-{i}+{p}]{c}»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»{p}[{i}+{i}-{p}]
{p}[{i}01{p}]{p}SpamWa Brutal				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}02{p}]{p}SpamWa Call					[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}03{p}]{p}SpamWa Sms					[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}04{p}]{p}SpamWa All					[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}05{p}]{p}SpamWa Tokopedia				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}06{p}]{p}SpamWa Call And Sms				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}07{p}]{p}SpamWa Call Or Sms				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}08{p}]{p}SpamWa Limit Day				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}09{p}]{p}SpamWa Gabut				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}10{p}]{p}SpamWa Roket				[Version » 1.] {p}[{i}+{i}-{p}]
{p}[{i}00{p}]{p}Exit And Quit				               {p}[{i}+{i}-{p}]
{p}[{i}99{p}]{p}Back To HideMenu				               {p}[{i}+{i}-{p}]
{p}[{i}-{i}+{p}]{c}»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»«»{p}[{i}+{i}-{p}]""")
	wa=input(f"{p}[{i}?{i}?{p}]{p}SpamWa {k}⟩⟩ {i}")
	if wa=="":
		print(f"Jangan Kosonv Om"),;waktu(2)
		menuwa()
	elif wa =="1" or wa =="01":
		bahan()
		os.system("""
pkg install git
git clone https://github.com/DaniAffCH/WhatsApp-spammer
cd WhatsApp-spammer
python *.py
reset
python2 *.py
reset
bash *.sh
reset
""")
	elif wa =="2" or wa =="02":
		bahan()
		os.system("""

""")
	elif wa =="3" or wa =="03":
		bahan()
		os.system("""

""")
	elif wa =="4" or wa =="04":
		bahan()
		os.system("""

""")
	elif wa =="5" or wa =="05":
		bahan()
		os.system("""

""")
	elif wa =="6" or wa =="06":
		bahan()
		os.system("""

""")
	elif wa =="7" or wa =="07":
		bahan()
		os.system("""

""")
	elif wa =="8" or wa =="08":
		bahan()
		os.system("""

""")
	elif wa =="9" or wa =="09":
		bahan()
		os.system("""

""")
	elif wa =="10" or wa =="10":
		bahan()
		os.system("""

""")
	elif wa =="99" or wa =="99":
		kata4(f"{p}Anda Akan Kembali KeHide Menu !!")
		hidemenu()

	else:
		kata(f"{m}Menu Tidak Terdaftar !!")
		menuwa()

def menudark():
	bash("reset;clear")
	kata3(f"""\r\r\r{p}
  | D  | A  | R  | K  | F  | B
   {b3}▒▒▒▒▒▒▐███████▌▒▒▒▒▒▒{q}
   {b3}▒▒▒▒▒▒▐░▀░▀░▀░▌▒▒▒▒▒▒{q}
   {b3}▒▒▒▒▒▒▐▄▄▄▄▄▄▄▌▒▒▒▒▒▒{q}
   {b3}▄▀▀▀█▒▐░▀▀▄▀▀░▌▒█▀▀▀▄{q}
   {b3}▌▌▌▌▐▒▄▌░▄▄▄░▐▄▒▌▐▐▐▐{q}
{c}╔═══╗╔═══╗╔═══╗╔╗╔═╗╔═══╗╔══╗─
{c}╚╗╔╗║║╔═╗║║╔═╗║║║║╔╝║╔══╝║╔╗║─
{c}─║║║║║║─║║║╚═╝║║╚╝╝─║╚══╗║╚╝╚╗
{p}─║║║║║╚═╝║║╔╗╔╝║╔╗║─║╔══╝║╔═╗║{c}@SystemX ProX
{p}╔╝╚╝║║╔═╗║║║║╚╗║║║╚╗║║───║╚═╝║{c}@Mr.Risky
{p}╚═══╝╚╝─╚╝╚╝╚═╝╚╝╚═╝╚╝───╚═══╝{c}@DarkFb
{p}[{i}+{p}]{c}––––––––––––––––––––––––––––––––––––––––––––––{p}[{i}+{p}]
{p}[{i}+{p}]{c}Athour        : Mr.Risky			 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}Whatsapp      : 6283143565470		 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}Facebook      : Risky			 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}Grup WhatSapp : Attack In Form Cyber		 {p}[{i}+{p}]{c}
{p}[{i}+{p}]{c}––––––––––––––––––––––––––––––––––––––––––––––{p}[{i}+{p}]""")
	kata3(f"""
{p}[{i}++{p}]{c}––––––––––––––––––––––––––––––––––––––––––––––{p}[{i}++{p}]
{p}[{i}0{i}1{p}]{k}⟩⟩⟩ {c}Dark Fb			[Version » 12.1]  {p}[{i}++{p}]
{p}[{i}0{i}2{p}]{k}⟩⟩⟩ {c}Dark Gold		[Version » 18.2]  {p}[{i}++{p}]
{p}[{i}0{i}3{p}]{k}⟩⟩⟩ {c}Dark Premium		[Version » 13.2]  {p}[{i}++{p}]
{p}[{i}0{i}4{p}]{k}⟩⟩⟩ {c}Dark Fb			[Version » 11.2]  {p}[{i}++{p}]
{p}[{i}0{i}5{p}]{k}⟩⟩⟩ {c}Dark Fb Vip		[Version » 15.2]  {p}[{i}++{p}]
{p}[{i}0{i}6{p}]{k}⟩⟩⟩ {c}Dark Fb New		[Version » 12.2]  {p}[{i}++{p}]
{p}[{i}0{i}7{p}]{k}⟩⟩⟩ {c}Dark Fb Vvip		[Version » 10.2]  {p}[{i}++{p}]
{p}[{i}0{i}8{p}]{k}⟩⟩⟩ {c}Dark Fb Pro		[Version » 14.2]  {p}[{i}++{p}]
{p}[{i}0{i}9{p}]{k}⟩⟩⟩ {c}Dark Fb Setan		[Version » 15.2]  {p}[{i}++{p}]
{p}[{i}1{i}0{p}]{k}⟩⟩⟩ {c}Dark Fb 01		[Version » 17.2]  {p}[{i}++{p}]
{p}[{i}9{i}9{p}]{k}⟩⟩⟩ {c}Back To HideMenu			  {p}[{i}++{p}]
{p}[{i}0{i}0{p}]{k}⟩⟩⟩ {c}Exit					  {p}[{i}++{p}]
{p}[{i}++{p}]{c}––––––––––––––––––––––––––––––––––––––––––––––{p}[{i}++{p}]""")
	kk=input(f"{p}[{i}?{i}?{p}]{c}⟩⟩⟩ {c}")
	if kk ==""*100:
		kata(f"{m}Jangan Kosonv Ayam !!")
		kata(f"Untuk Bulan Ramadhan Kalau Engga !!")
		menudark()
	elif kk =="1" or kk =="01":
		bahan()
#git clone
		bash("""
pkg install git
pkg install curl
python2 -m pip install fake-useragent
git clone https://github.com/Mr-XsZ/Dark-Fb
cd Dark-Fb
bash install.sh
""")
	elif kk =="2" or kk =="02":
		bahan()
#git clone
		bash("""
pkg install python2
pkg install git
pkg install curl
git clone https://github.com/darkfb/terbaru
cd terbaru
pip2 install -r requirements.txt
python2 dark.pyc
""")
	elif kk =="3" or kk =="03":
		bahan()
#git clone
		bash("""
pkg install git python2
pip2 install --upgrade pip
git clone https://github.com/TheMagizz/DarkPremium
cd DarkPremium
pip2 install -r requirements.txt
python2 DarkFB.py
""")
	elif kk =="4" or kk =="04":
		bahan()
#git clone
		bash("""
pkg update
pkg upgrade
pkg install python2 git -y
git clone https://github.com/Bl4ckDr460n/Black-Fb-Premium.git
cd Black-Fb-Premium
pip2 install -r req.txt
python2 BlackFbPremium.py
""")
	elif kk =="5" or kk =="05":
		bahan()
#git clone
		bash("""
pkg install git python2
pip2 install --upgrade pip
git clone https://github.com/TheMagizz/DarkPremium
DARK FB Re-code :
git clone https://github.com/MasKawer/darkfb
cd DarkFB
pip2 install -r requirements.txt
python2 DarkFB.py
""")
	elif kk =="6" or kk =="06":
		bahan()
#git clone
		bash("""
pkg install git
pkg install python2
pip2 install --upgrade pip
git clone https://github.com/HackerGamers71/DarkFB-Premium
cd DarkFB-Premium
python2 DarkFB.py
""")
	elif kk =="7" or kk =="07":
		bahan()
#git clone
		bash("""
apt update && apt upgrade -y
pkg install python2
pkg install git
pip2 install --upgrade pip
pip2 install requests
pip2 install mechanize
git clone https://github.com/MuhamadZalim97/Dark-FB-Premium
cd Dark-FB-Premium
chmod +x dark.py
python2 dark.py
""")
	elif kk =="8" or kk =="08":
		bahan()
#git clone
		bash("""
pkg install git python2
pip2 install --upgrade pip
git clone https://github.com/MrGameOver16/dark-fb-pro
cd dark-fb-pro
pip2 install -r requirements.txt
python2 Dark-PRO.py
""")
	elif kk =="9" or kk =="09":
		bahan()
#git clone
		bash("""
pkg install git
pkg install curl
python2 -m pip install fake-useragent
git clone https://github.com/Mr-XsZ/Dark-Fb
cd Dark-Fb
bash install.sh
""")
	elif kk =="10":
		bahan()
#git clone
		bash("""
pkg install git python2
pip2 install --upgrade pip
git clone https://github.com/MrGameOver16/dark-fb-pro
cd dark-fb-pro
pip2 install -r requirements.txt
python2 Dark-PRO.py
""")
	elif kk =="99" or kk =="99":
		bash("clear;reset;sleep 2")
		hide()
	elif kk =="00" or kk =="00":
		kata4(f"{c}Bye Bye Bye Selamat Tinggal Love You!!")
		sys.exit()
	else:
		print(f"Pilihan Anda Tidak Terdaftar !!")
		detik(00, 20)
		hide()

def pwx():
	bash("reset")
	info()
	kata3(f"""{h2}{m3}
   ██░▀██████████████▀░██
   █▌▒▒░████████████░▒▒▐█	░░░░░▄▄▀▀▀▀▀▀▀▀▀▄▄░░░░░
   █░▒▒▒░██████████░▒▒▒░█	░░░░█░░░░░░░░░░░░░█░░░░
   ▌░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░▐	░░░█░░░░░░░░░░▄▄▄░░█░░░
   ░▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒░	░░░█░░▄▄▄░░▄░░███░░█░░░
  ███▀▀▀██▄▒▒▒▒▒▒▒▄██▀▀▀██	░░░▄█░▄░░░▀▀▀░░░▄░█▄░░░
  ██░░░▐█░▀█▒▒▒▒▒█▀░█▌░░░█	░░░█░░▀█▀█▀█▀█▀█▀░░█░░░
  ▐▌░░░▐▄▌░▐▌▒▒▒▐▌░▐▄▌░░▐▌	░░░▄██▄▄▀▀▀▀▀▀▀▄▄██▄░░░
   █░░░▐█▌░░▌▒▒▒▐░░▐█▌░░█	░▄█░█▀▀█▀▀▀█▀▀▀█▀▀█░█▄░
   ▒▀▄▄▄█▄▄▄▌░▄░▐▄▄▄█▄▄▀▒
   ░░░░░░░░░░└┴┘░░░░░░░░░		┊ ▇▇▇▇▇
   ██▄▄░░░░░░░░░░░░░░▄▄██		┊┊▇▇▇▇▇
   ████████▒▒▒▒▒▒████████		┊┊▇▇▇▇▇
   █▀░░███▒▒░░▒░░▒▀██████		▅▅▇▇▇▇▇▅▅
   █▒░███▒▒╖░░╥░░╓▒▐█████		▕▍╱╲╲╱╱╲
   █▒░▀▀▀░░║░░║░░║░░█████		╭▎▏▍╲╱▍▕
   ██▄▄▄▄▀▀┴┴╚╧╧╝╧╧╝┴┴███		┃╯╲＿╱╲＿╱
   ██████████████████████		╰╯┊┊╭╰━━━╮
{b3}[•]××××××××××××××××××××××××××××××××X{m3}	┊┳┳╯╰━━━╮┃
{b3}[•]By Script :Mr.Risky		   X{m3}	┊┃┃━╯╰━┊╰╯
{b3}[•]Suports   :AcinaKongame	   X{m3}	┊┃╰┳┳┳┳┛
{b3}[•]Github    :github.com/Dumai-991 X{m3}	┊╰━┻┻┻┻━╮
{b3}[•]WhatsApp  :6283143565470        X{m3}	┊┊┊┊┊┊┊┊┃
{b3}[•]××××××××××××××××××××××××××××××××X{m3}	╰━━━━━━━╯{q}{m3}
Anda Belum Register Atau Belum Login....!!!
Silakan Masukan User Dan Pass...!!!
Username Dan Password Terdaftar Secara Random...!!!
Sebelum Masuk Masukkan Username Dan Kata Sandi Untuk Lanjut !!!{q}
""")
	axis=input(f"{k}Username : {c}")
	if axis =="":
		kata(f"{m}Jangan Kosong Sayang...!!")
		bash("sleep 2;clear")
		engtot()
	elif axis == "Dumai":
#		main3()
		kata(f"{c}[{m}!{c}]{i} Lanjut Sayanv...!!!")
		axis2=input(f"{k}Password : {c}")
		if axis2 =="":
			kata(f"{m}Jangan Kosong Sayang...!!")
			bash("sleep 2;clear")
			engtot()
		elif axis2 == "Riau":
			kata(f"{c}[{m}!{c}]{i}Password Benar Sayanv...!!")
			bash("sleep 2;git pull;reset")
			main3()
		else:
			kata(f"{c}[{m}!{c}]{k} Kata Sandi Anda Salah... !!!!")
			os.system("xdg-open https://wa.me/6283143565470?text=Bang+Username+Sama+Passwordnya+Apa+Bang...+Bilang+Oranv+Ini+Usernamenya+*Dumai*+Passwordnya+*Riau*+??+")
			bash("sleep 2")
	elif axis == "991" or axis == "Admin":
		bash("git pull")
		kata(f"{c}[{i}✓{c}]{i} Anda Sangat Beruntung Karena Menggunakan Username Ini !!!")
		main3()


	else:
		kata(f"{c}[{m}!{c}]{k} Username Salah Banvsat!!!!")
#		os.system("xdg-open https://wa.me/6283143565470?text=Bang+Username+Sama+Passwordnya+Apa+Bang...+Bilang+Oranv+Ini+Usernamenya+*Dumai*+Passwordnya+*Riau*+??+")
		bash("sleep 2")


def new():

	list1=["Trial","Trial2","Trial9","Trial4","PREMIUM"]
#	xm=["xmxlajdbqpdn103ibz","asfnwnxbbbapqjbx","hdhdbq00dknxnbxallbx","bdbdbbqpqonxnxna","nsnsnncnqopqpohOlajdb"]
	list2=["Dumai","Dumai8","Dumai2","Dumai4","PREMIUM","ADMIN"]
#	J=random.randint(0,5)
	bb=random.randint(0,6)
	ml=random.randint(0,6)
	kata3(f"{k}Username Anda :{c} {list1[bb]}{q}")
	time.sleep(1)
	kata3(f"{k}Password Anda :{c} {list2[ml]}{q}")
#	time.sleep(1)
#	kata(f"{k}Token Anda    :{b3} {xm[ml]}{q}")
	bash("sleep 1")
	ang=input(f"{k}UserName :{c} ")
	if ang == "":
		print("Jangan Kosong... Sayang")
		os.system("sleep 5;reset")
		pwx()
	elif ang == (f"{list1[J]}"):
		kata(f"\r{c}[{m}!{c}]{k} Username Anda Sudah TerDaftar {m}!!!"+'\r')
		os.system("sleep 1")
		fack=input(f"{k}Password :{c} ")
		if fack == "":
			print(f"Jangan Kosong Lonte...")
			bash("sleep 2;reset")
			pwx()
		elif fack == (f"{list2[ml]}"):
			kata(f"{c}[{m}!{c}]{i} Password Anda Sudah TerDaftar {m}!!!")
			time.sleep(1)
			main3()
		else:
			kata3(f"{c}Isi Dengan Benar Kambing...{m}!!!")
			bash("sleep 3;reset")
			pwx()
#		random2()
	elif ang == "ADMIN" or ang == "admin":
		bash("sleep 2")
		skip()
	elif ang == "991" or ang == "991":
		bash("sleep 2")
		skip()

	else:
		kata("Isi Dengan Benar KonToX...")
		print("Salah Goblog.... :)")
		os.system("sleep 4;reset")
		pwx()


#	wel()
#	random1()
def wel12():
    for ku in '[•]Loading... ':
        for n in range(30):
            print((random.choice(string.ascii_letters + string.digits + '.') + '\x08'), end='', flush=True)
            time.sleep(0./1)

        print(ku, end='', flush=True)

def random1():
	list1=["Trial","Trial2","Trial9","Trial4","PREMIUM"]
	list2=["Dumai","Dumai8","Dumai2","Dumai4","PREMIUM"]
	J=random.randint(0,5)
	g=random.randint(0,5)
	kata3(f"{k}Username Anda :{b3} {list1[J]}{q}")
	time.sleep(1)
	kata3(f"{k}Password Anda :{b3} {list2[g]}{q}")
	time.sleep(1)
	print("")
	ang=input(f"{k}UserName :{c} ")
	if ang == "":
		print("Jangan Kosong... Sayang")
		os.system("sleep 5;reset")
		main2()

	elif ang == (f"{list1[J]}") or ang == (f"{list1[J]}"):
		kata(f"{c}[{m}!{c}]{k} Username Anda Sudah TerDaftar {m}!!!")
		os.system("sleep 1")
		fack=input(f"{k}Password :{c} ")
		if fack == "":
			print(f"Jangan Kosong Lonte...")
			bash("sleep 2;reset")
			main2()
		elif fack == (f"{list2[g]}") or fack == (f"{list2[g]}"):
			kata(f"{c}[{m}!{c}]{i} Password Anda Terdaftar TerDaftar {m}!!!")
			time.sleep(1)
			main3()
		else:
			kata3(f"{c}Isi Dengan Benar Kambing...{m}!!!")
			bash("sleep 3;reset")
			main2()
#		random2()
	elif ang == (f"PREMIUM") or ang == (f"PREMIUM"):
		time.sleep(1)
		okey()
	elif ang == "ADMIN" or ang == "admin":
		bash("sleep 2")
		skip()
	elif ang == "991" or ang == "991":
		bash("sleep 2")
		skip()

	else:
		kata("Isi Dengan Benar KonToX...")
		print("Salah Goblog.... :)")
		os.system("sleep 4;reset")
		pwx()
def detik(start_minute, start_second):
    total_second = start_minute * 60 + start_second
    while total_second:
        mins, secs = divmod(total_second, 60)
#	print(f"{mins:02d} ≈ {secs:02d}")
        print(f'    {m3}~~{mins:02d}{q}{k}~~:~~{q}{b3}{secs:02d}~~{q}', end='\r')
        time.sleep(1./25)
        total_second -= 1
    kata(f"{c}[{m}!{c}]{i} Lanjut... Mamang...")
    bash("sleep 1")
#Contoh    countdownTimer(25, 00)
def okey():

	kata3(f"""
{b3}SELAMAT !!!! ANDA MENDAPATKAN TRIAL PREMIUM JANGAN LUPA BERSYUKUR..!
KEUNTUNGAN PREMIUM [ SKIP INTRO , SEGERA HADIR !!! ]{q}

{m3}BY MR.RISKY
{k3}@GOOD FOR MEMEK
""")
	time.sleep(5)
	skip()
#{b3};V

#{q}	{b3}• \              /
#{q}	{b3}•  \    ;V      /
#{q}	{b3}•   \	       /
#{q}	     {b3}\	      /
#{q}	      {b3}\	     /
#{q}	{b3}°      \    /
#{q}	{b3}°	\  /
#{q}	{b3}√        \/

#{m3};V;V;V;V;V;V;V;V;V;V;V;V;V;V;V
def spin():
        try:
                L="/-\\|"
                for q in range(20):
                        time.sleep(0.1)
                        sys.stdout.write("\r["+L[q % len(L)]+"]")
                        sys.stdout.flush()
        except:
                exit()


def random2():
#IziNDulu
	list1=["Trial","Trial2","Trial3","Trial4","PREMIUM"]
	list2=["Dumai","Dumai991","Dumai2","Dumai4","PREMIUM"]
	e=random.randint(0,5)
	g=random.randint(0,5)
	time.sleep(1)
	kata3(f"{k}Password Anda :{b3} {list2[g]}{q}")
	fack=input(f"{k}Password :{c} ")
	if fack == "":
		print(f"Jangan Kosong Lonte...")
		bash("sleep 2;reset")
		main2()
	elif fack == (f"{list2[g]}") or fack == (f"{list2[g]}"):
		print(f"Okeeyyyy Suksess Login...")
		time.sleep(2)
		main3()
	else:
		kata3(f"{c}Isi Dengan Benar Kambing...{m}!!!")
		bash("sleep 3;reset")
		main2()
def info():
	kata2(f"""
{b3}Terima Kasih Telah Menggunakan Script AllTools :')...
Script Yang Rusak Sudah DiUpdate Sama #Mr.Risky
Jika Ada Masalah Terhadap Script Silahkan Report KeAdmin
{q}
@{m3}https://wa.me/6283143565470
@{m3}Mr.Risky

{b3}Terima Kasih KePada
{m3}DUMAI-991 ♥
{m3}MR.RISKY ♥
{b3}Terima Kasih Telah Suport Script
{k3}Chennel YouTube AcinaKongame ♥
{k3}Chennel TouTube c0nquer0r. s3c ♠{q}
""")
	detik(00, 23)
	bash("reset")

def jam():
	now = datetime.now()
	mm = str(now.month)  #Bulan
	dd = str(now.day)    #Tanggal
	yyyy = str(now.year) #Tahun
	hour = str(now.hour) #Jam
	mi = str(now.minute) #Menit
	ss = str(now.second) #Detik
#Kata Goblok
	kata3(f"""
{m3}Mesin PengHitung Tanggal ~ Waktu
Intronya Emang Lambat..

TANGGAL : {dd}
BULAN   : {mm}
TAHUN   : {yyyy}

JAM     : {hour}
MENIT   : {mi}
DETIK   : {ss}
{q}
""")
def load5():
	text = [f"{i}[>>>>             ] 35%","[>>>>>>>>>        ] 46%","[>>>>>>>>>>>>     ] 96%","[>>>>>>>>>>>>>>>>>] 100%"]
	for o in text + "\r":
		print("\r\033[1;91m[●] \033[1;92mLoading \033[1;97m"+o+"\r"),;sys.stdout.flush();time.sleep(1)
def tik5():
#    titik = [".    ",'..     ','...    ',"....?   ",'....?? ',"....? ","....  ","...    ","..    ",".      ","        "]
    for o in ".         ",'..       ','...      ',"....?      ",'....??      ',"....?    ","....      ","...       ","..          ",".         ","             ":
#            print(f"\r\033[1;91m[●] \033[1;92mSedang DiCheck\r \033[1;97m{o}"),;sys.stdout.flush();time.sleep(1);
            waktu(0.8)
            stdout.write(f"\r[+]Loading"+o+""),;stdout.flush()
#	    waktu("0.3")
#            stdout.write("\r \033[1;91m[●] \033[1;92mSedang DiCheck \033[1;97m"+o)
#            stdout.flush()
def fb():
	os.system("xdg-open https://m.facebook.com/ilovexnxx")
	os.system("sleep 5")
	os.system("xdg-open https://chat.whatsapp.com/LwR9NQFlHUZ5KvzFdWjbyf")
	os.system("sleep 3")
#Ubah Aja Linknya Aku Iklas Kok
#Bapak Kau Super Boy..
#Anjinh


def git():

	os.system("""
open-xdg https://m.facebook.com/ilovexnxx
clear
git clone https://github.com/Dumai-200/Config
clear
""")


def halo():

	clear()
	kata2(f"{h}Sebelum Lanjut Apakah Anda Sudah Install Bahan...?")
	kata2(f"{p}Jika Sudah Jawab {k}Y")
	kata(f"{p}Jika Belum Jawab {k}N")
	asw=input(f"{c}[{k}•{c}]{m}===={c}[{k}•{c}]{m}====={c}]>>>> {c}")

	if asw == "":
		kata(f"{h}Jangan {p}Kosonglah Anjing....")
		os.system("sleep 2")

	elif asw == "y":
		kata(f"{c}Ok... Lanjut....")
		os.system("sleep 2")
		main()

	elif asw == "Y":
		kata(f"{c}Ok... Lanjut....")
		os.system("sleep 2")
		main()

	elif asw == "N":
		kata(f"{h}Bye{p} Bye{h} Bye")
		kata(f"{m}Hacker Pro.... {p}Salam Dari Dumai")
		bahan()
		halo()

	elif asw == "n":
		kata(f"{h}Bye{p} Bye{h} Bye")
		kata(f"{m}Hacker Pro.... {p}Salam Dari Dumai")
		bahan()
		halo()
	else:
		kata(f"{m}Soryy..... {p}Error.....")
		os.system("sleep 2")
		halo()


def keluarx():

	print(f"{c}Bye Bye Bye Anak Haram")
	sys.exit

def enter():

	load()
	kata2(f"{k}Tekan Enter Untuk Lanjut...{m}KONTOL...")
	os.system("sleep 2")
	print("")
	input(f"{c}[{p} Next {k}>><<{p} Lanjut {c}]")

def b():

	os.system("clear")

def load():
        try:
                z = 50
                x = 0
                for c in range(z):
                        z -= 1
                        x += 1
                        sys.stdout.write(f"\r {i}Download {k}[{b2}%s{h}%s{k}]{c2} %s/%s"%("⋙"*x,"≡"*z,x,z)),;sys.stdout.flush()
                        time.sleep(0.3)
        except KeyboardInterrupt:
                sys.exit()

def load3():

	text = [f"{i}[>>>>             ] 35%","[>>>>>>>>>        ] 46%","[>>>>>>>>>>>>     ] 96%","[>>>>>>>>>>>>>>>>>] 100%"]
	for o in text:
		print("\r\033[1;91m[●] \033[1;92mLoading \033[1;97m"+o+"\r"),;sys.stdout.flush();time.sleep(1)
#	        print(f"\r\033[1;97m[\033[1;96m!\033[1;97m]Loading...(\033[1;92m"+o+"\033[90m%\033[1;97m)", time.sleep("10") , end="", flush=False)

def bahan3():

	clear()
	os.system("""
pkg update -y
clear
pkg upgrade -y
clear
pkg install bash -y
clear
pkg install git -y
clear
pkg install python -y 
clear
pkg install cowsay -y
clear
pkg install figlet -y
clear
pkg install gem -y
clear
pkg install toilet -y
clear
cd $HOME
git clone https://github.com/Dumai-991/Update
clear
cd Update
clear
bash Install.sh
clear
cd $HOME
clear
""")

def welcome():

	kata3(f"""
{p}Assalamulaikum... Buat Kaum Islam...
{p}Salom Buat...  Kaum Kristen...

{c}Selamat Datang DiTools Ini... Tools Ini 100% Work...
Dan Tools Ini.. Akan Bertambah Setiap Kali... Anda MengUpdate...
Admin Sudah Menyiapkan Pilihan Update.. Pada Nomor [ 99 ]...
Jika Ada Masalah Terhadap Tools.. Silahkan Report Bug....

{k}~~~~~~~{i}Mr.Risky
{k}~~~~~~~{i}083143565470
""")
	os.system("sleep 3;clear")


def clear():
    os.system("sleep 1;clear;reset")

def kata(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(1./400)
def kata5(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(1./333)
def kata2(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(1./100)
def kata3(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(2./2555)
def kata6(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0./250)
def kata4(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(1./27)
def load2():
    for x in range(0,101):
        time.sleep(1./10)
        print(f"\r\033[1;97m[\033[1;96m!\033[1;97m]Loading...(\033[1;92m{x}\033[90m%\033[1;97m)", end="", flush=True)
def Wa():
       os.system("xdg-open https://api.whatsapp.com/send/?phone=%2B6283143565470&text&app_absent=0")
       sys.exit("\033[1;97m[\033[1;91m!\033[1;97m]\033[1;91mExit\033[1;97m")
def baner():
    kata3(f"""
{m3}{c}[ {i}VERSION {c}]{m}~~~{c}[  {i}INFO{c}  ]
{c}[  {k}1.12   {c}]{m}~~~{c}[ {k}Pindah{c} ]
{c}[  {k}20.1   {c}]{m}~~~{c}[ {k}Pindah{c} ]
{c}[  {k}23.9   {c}]{m}~~~{c}[ {k}Pindah{c} ]
{c}[  {k}26.8   {c}]{m}~~~{c}[  {m}End{c}   ]
{c}[  {k}????   {c}]{m}~~~{c}[ {m}??????{c} ]{q}

{c}[{m}!{c}]{b3}BUAT SEDANG MENGGUNAKAN SCRIPT ALLTOOLS !!!{q}
{c}[{m}!{c}]{b3}TOLONG DONG... DONASINYA... VIA PULSA KOK PELIT AMAT....{q}
{c}[{m}!{c}]{b3}AXIS [083143565470] VIA PULSA AJA BANG...{q}
{c}[{m}!{c}]{b3}SCRIPTNYA AJA SUDAH SEKITAR 3 BULAN.. BALUM DONASI..{q}
{c}[{m}!{c}]{b3}JIKA GINI TERUS ENGGA ADA YANG DONASI IYA UDAH SCRIPTNYA MIMIN{q}
{c}[{m}!{c}]{b3}BIARKAN SAMPE RUSAK... !!! I SAD BOY....{q}

	I LOVE YOU XNXX...


{c}[{k}•{c}]{m3}============================================================{q}{c}[{k}•{c}]{m}{q}
{k3}░█████╗░██╗░░░░░██╗░░░░░{b3}████████╗░█████╗░░█████╗░██╗░░░░░░██████╗{q}
{k3}██╔══██╗██║░░░░░██║░░░░░{b3}╚══██╔══╝██╔══██╗██╔══██╗██║░░░░░██╔════╝{q}
{k3}███████║██║░░░░░██║░░░░░{b3}░░░██║░░░██║░░██║██║░░██║██║░░░░░╚█████╗░{q}
{k3}██╔══██║██║░░░░░██║░░░░░{b3}░░░██║░░░██║░░██║██║░░██║██║░░░░░░╚═══██╗{q}
{k3}██║░░██║███████╗███████╗{b3}░░░██║░░░╚█████╔╝╚█████╔╝███████╗██████╔╝{q}
{k3}╚═╝░░╚═╝╚══════╝╚══════╝{b3}░░░╚═╝░░░░╚════╝░░╚════╝░╚══════╝╚═════╝░{q}
{c}[{k}•{c}]{m3}============================================================{q}{c}[{k}•{c}]{q}
[{k}•{c}]{h}Script By         : {c}Mr.Risky
[{k}•{c}]{h}Github            : {c}github.com/Dumai-991
[{k}•{c}]{h}WhatSapp          : {c}083143565470
[{k}•{c}]{h}NB                : {c}Jika Error Terhadap Tools Riport Admin
{c}[{k}•{c}]{m3}============================================================{q}{c}[{k}•{c}]{m}{q}
"""),;os.system("""
date=`date "+%d"`
month=`date "+%m"`
years=`date "+%y"`

day=`date "+%A"`

echo "  \033[95m╼\033[94m☾ \033[93mDATE \033[95m: \033[92m$date\033[95m/\033[92m$month\033[95m/\033[92m$years \033[94m☽\033[95m╾╼\033[94m☾ \033[93mDAY \033[95m: \033[92m$day \033[94m☽\033[95m╾"
""")

def menu():

	kata3(f"""
{c}[{k}•{c}]{i}{b3}========================================================={q}{c}[{k}•{c}]
{k3}[ NO ]~~~~~~[ NAME SCRIPT ]~~~~~~~~~~~~~[ VERSION ]~~~~~~~~~{q}
{m3}[ 01 ]~Script Dark Fb			[  12.1   ]{q}
{b3}[ 02 ]~Script SpamSms			[  00.0   ]{q}
{m3}[ 03 ]~Script Update Termux		[  15.5   ]{q}
{b3}[ 04 ]~Script FreeSms			[  00.0   ]{q}
{m3}[ 05 ]~Script Sensai			[  12.1   ]{q}
{b3}[ 06 ]~Script RajaCrack			[  12.1   ]{q}
{m3}[ 07 ]~Script Phising			[  00.0   ]{q}
{b3}[ 08 ]~Script Ratu Error		[  10.1   ]{q}
{m3}[ 09 ]~Script Dark Gold			[  12.1   ]{q}
{b3}[ 10 ]~Script KingCrack			[  12.2   ]{q}
{m3}[ 11 ]~Script Crack All Negara		[  19.0   ]{q}
{b3}[ 12 ]~Script MetasPloit		[  12.1   ]{q}
{m3}[ 13 ]~Script Crack Pemula		[  12.7   ]{q}
{b3}[ 14 ]~Script CR4CK			[  12.9   ]{q}
{m3}[ 15 ]~Script Fb Mafia			[  17.0   ]{q}
{b3}[ 16 ]~Script UNIS3X			[  00.0   ]{q}
{m3}[ 17 ]~Script Empas MonToon		[  20.0   ]{q}
{b3}[ 18 ]~Script Bajingan			[  00.6   ]{q}
{m3}[ 19 ]~Script DmBf			[  12.1   ]{q}
{b3}[ 20 ]~Script Hack Gmail		[  12.9   ]{q}
{m3}[ 21 ]~Script Bot~WhatsApp~New		[  ????   ]{q}
{b3}[ 22 ]~Script CFBID			[  12.0   ]{q}
{m3}[ 23 ]~Script CFBID2			[  13.1   ]{q}
{b3}[ 24 ]~Script MBF 			[  12.1   ]{q}
{m3}[ 25 ]~Script B2			[  19.9   ]{q}
{b3}[ 26 ]~Script Silet			[  23.0   ]{q}
{m3}[ 27 ]~Script Hack CCTV			[  19.0   ]{q}
{b3}[ 28 ]~Script Virus Hp			[  6.12   ]{q}
{m3}[ 29 ]~Script Cek Ip Me			[  15.5   ]{q}
{b3}[ 30 ]~Script BotChat			[  4.0    ]{q}
{m3}[ 31 ]~Script Scan IP Web		[  2.0    ]{q}
{b3}[ 32 ]~Script EncPytHon			[  22.0   ]{q}
{m3}[ 33 ]~Script Lacak IP			[  12.0   ]{q}
{b3}[ 34 ]~Script MrTamfanSpam		[  19.9   ]{q}
{m3}[ 35 ]~Script Prem     			[  12.1   ]{q}
{b3}[ 36 ]~Script Treker Fb			[  11.1   ]{q}
{m3}[ 37 ]~Script Hack IG			[  0.00   ]{q}
{b3}[ 38 ]~Script DarkFB New		[  0.00   ]{q}
{m3}[ 39 ]~Script BRUTEFERONCEnew		[  0.00   ]{q}
{b3}[ 40 ]~Script LiteSpam			[  0.00   ]{q}
{m3}[ 41 ]~Script VirusAll			[  34.6   ]{q}
{b3}[ 42 ]~Script Mempercatikan Termux	[  20.9   ]{q}
{m3}[ 43 ]~Script HxWhatsapp		[  00.0   ]{q}
{b3}[ 44 ]~Script Trojans			[  10.1   ]{q}
{m3}[ 45 ]~Script Dompile (Enc) 		[  12.1   ]{q}
{b3}[ 46 ]~Script Cracker 			[  23.0   ]{q}
{m3}[ 47 ]~Script DarkFb			[  00.0   ]{q}
{b3}[ 48 ]~Script SpamSMS			[  00.0   ]{q}
{m3}[ 49 ]~Script DeathHacker :V		[  10.5   ]{q}
{b3}[ 50 ]~Script CLAY (Hasil Recode)	[  19.1   ]{q}
{m3}[ 51 ]~Script DarkPrimium		[  12.1   ]{q}
{b3}[ 52 ]~Script DarkGold			[  23.8   ]{q}
{m3}[ 53 ]~Script SpamWa Brutal		[  11.5   ]{q}
{b3}[ 54 ]~Script Logo Termux		[  ????   ]{q}
{m3}[ 55 ]~Script Termux Benner		[  ????   ]{q}
{b3}[ 56 ]~Script Termux By Mr.Risky	[  19.20  ]{q}
{m3}[ 57 ]~Script Tools Tuan Badut		[  20.3   ]{q}
{b3}[ 58 ]~Script Tools BajinganV2		[  13.2   ]{q}
{m3}[ 59 ]~Script Cookies Menjadi Token	[  15.1   ]{q}
{b3}[ 60 ]~Script Bot-Facebook		[  14.8   ]{q}
{m3}[ 61 ]~Script SpamCALL			[  18.1   ]{q}
{b3}[ 62 ]~Script Elite Fb			[  ????   ]{q}
{m3}[ 63 ]~Script Virtex (2k21)		[  ????   ]{q}
{b3}[ 64 ]~Script Hack Fb FreeFire		[  12.2   ]{q}
{m3}[ 65 ]~Script Md5-Crack			[  12.1   ]{q}
{b3}[ 66 ]~Script Tombol-Special-Termux	[  19.1   ]{q}
{m3}[ 67 ]~Script Termux-Sytyle		[  48.8   ]{q}
{b3}[ 68 ]~Script Wifi-Hack			[  28.1   ]{q}
{m3}[ 69 ]~Script FbTool			[  10.1   ]{q}
{b3}[ 70 ]~Script Kunci Profil Facebook	[  ????   ]{q}
{m3}[ 71 ]~Script Membuat Akun Ssh/Ssl	[  19.2   ]{q}
{b3}[ 72 ]~Script TSpeed Ssh/Ssl		[  09.1   ]{q}
{m3}[ 73 ]~Script Membuat Web 		[  12.1   ]{q}
{b3}[ 74 ]~Script Spam Sms/Call		[  19.1   ]{q}
{m3}[ 75 ]~Script Perusak (Hoax)		[  ERROR  ]{q}
{b3}[ 76 ]~Script Lacak Ip (Work)		[  Root   ]{q}
{m3}[ 77 ]~Script Bots Chat			[  12.1   ]{q}
{b3}[ 78 ]~Script Hack Fb Teman (Work)	[  25.9   ]{q}
{m3}[ 79 ]~Script Segera Hadir		[  19.1   ]{q}
{b3}[ 80 ]~Script Segera Hadir		[  18.1   ]{q}
{m3}[ 81 ]~Script Segera Hadir		[  16.1   ]{q}
{b3}[ 82 ]~Script Segera Hadir		[  29.8   ]{q}
{m3}[ 83 ]~Script Segera Hadir		[  21.9   ]{q}
{b3}[ 84 ]~Script Segera Hadir		[  ????   ]{q}
{m3}[ 85 ]~Script Segera Hadir		[  ????   ]{q}
{b3}[ 86 ]~Script Segera Hadir		[  ????   ]{q}
{m3}[ 87 ]~Script Segera Hadir		[  !!!!   ]{q}
{b3}[ 89 ]~Script Segera Hadir		[  !!!!   ]{q}
{m3}[ 90 ]~Script Segera Hadir		[  31.2   ]{q}
{b3}[ 91 ]~Script Segera Hadir		[  21.2   ]{q}
{m3}[ 92 ]~Script Segera Hadir		[  !!!!   ]{q}
{b3}[ 93 ]~Script Segera Hadir		[  ????   ]{q}
{h}[ -- ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[  ----   ]
{p}[ 88 ]~Report Bug Script		[  Admin  ]{q}
{h}[ 99 ]~Update Script			[  Wajib  ]{q}
{p}[ 77 ]~Join Group Whatsapp		[  Wajib  ]{q}
{h}[ 00 ]~Exit				[  Babi   ]{q}
{p}[ -- ]~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~[  ----   ]
{c}[{k}•{c}]{i}========================================================={c}[{k}•{c}]
{k3}NB     : Jangan Lupa Join KeGrub Kita Okyyy{q}
{m3}Link   : https://chat.whatsapp.com/LwR9NQFlHUZ5KvzFdWjbyf{q}
{b3}Donasi : Via Pulsa [{q} {m3}083143565470{q} {b3}]  Axis{q}
{k3}Fb Link: htpps://m.facebook.com/ilovexnxx{q}
{c}[{u}•{k}•{c}]{b3}≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈{q}{c}[{u}•{k}•{c}]
{m3}[ππ]Daftar Menu Yang Lagi Viral !!!!![ππ]{q}
{m3}[••]21 ≈≈ Bots WhatsApp New{q}	     {m3}[••]{q}
{m3}[••]14 ≈≈ Cr4ck Facebook{q} 	     {m3}[••]{q}
{m3}[••]42 ≈≈ Percantikan Termux{q}	     {m3}[••]{q}
{m3}[••]54 ≈≈ Logo Termux{q} 		     {m3}[••]{q}
{m3}[••]56 ≈≈ Termux Logo By Mr.Risky{q}    {m3}[••]{q}
{m3}[••]60 ≈≈ Bot Facebook{q}		     {m3}[••]{q}
{m3}[ππ]Daftar Menu Yang Lagi Viral !!!!![ππ]{q}
{c}[{u}•{k}•{c}]{b3}≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈{q}{c}[{u}•{k}•{c}]
{b3}Terima Kasih Telah Suports Script Ini :) ♥{q}
{b3}♥AcinaKongame♥{q}
{b3}♥Mr.Risky♥{q}
""")
def bash(llp): #Bash

	os.system(llp) #System/Bash

def sub(memek): #Chennel SuportS

	for q in range(memek):
		kata3(f"{m3}Jangan Lupa DiSubScription {m3}Chennel ♥AcinaKongame♥"*q)
		os.system("sleep 1")
		kata(f"{b3}Terima Kasih Telah Suports Script AllTools 2021 Dan Jangan Lupa Share Script Ini Kepada Teman Anda.. 1 Follow Github = 100 Teman Admin♥")
def ___X___():
#Ctrl + K  = Cut
	print("""
{m3}[ 70 ]~Script 			[     ]{q}
{b3}[ 70 ]~Script 			[     ]{q}
{m3}[ 70 ]~Script 			[     ]{q}
{b3}[ 70 ]~Script 			[     ]{q}
""")
#Merah Duluan
#Ctrl + U  = Paste
	print("""
{b3}[ 60 ]~Script 			[     ]{q}
{m3}[ 60 ]~Script 			[     ]{q}
""")
#Biru Duluan
#Cuma Mau DiCopy Lalu Paste
#???
#???

	#SCRIOT BY MR.RISKY
#import os,sys,requests,json,time

#b='\033[1;34m'
#i='\033[1;32m'
#c='\033[1;36m'
#m='\033[1;31m'
#u='\033[1;35m'
#k='\033[1;33m'
#p='\033[1;37m'
#h='\033[1;90m'

def bahan2():

	kata("Ok Lanjut... MengIntall...")
	os.system("""
pkg update -y
pkg upgrade -y
pkg install git -y
npm cache clear
npm audit fix
""")



def bot():

	os.system("clear")
	kata2(f"""
		{c}[{k}VERSION {k}1.12{c}]
{m}[•]======================================[•]
{h}[•]01[•]~BabyBot	[ New ]		 [•]
{p}[•]02[•]~AnKer		[ New ]		 [•]
{h}[•]03[•]~AhfisJunianto  [ New ]		 [•]
{p}[•]04[•]~DNSBots        [ New ] 	 [•]
{h}[•]05[•]~FXC7BOT        [ New ]		 [•]
{p}[•]00[•]~Back           [ Fack]		 [•]
{m}[•]======================================[•]
{c}		|BY MR.RISKY|
{m}[•]======================================[•]
""")
	kata(f"{c}Silahkan Pilih Bot Whatsapp Mau DiInstall.???")
	os.system("sleep 2")
	kon=input(f"{c}[•]{m}==={c}[•]{m}MR.RISKY{k}>>> {m}")
	if kon == "":
		kata(f"{m}Error...??? Anjinh...")
		os.system("sleep 2")
		bot()

	elif kon == "1" or kon == "01":
		load()
		bahan2()
		os.system("""
pkg install git
https://github.com/Ramlan666/babybot
cd babybot
bash install.sh
node index.js
""")
	elif kon == "2" or kon == "02":
		load()
		bahan2()
		os.system("""
git clone https://github.com/4NK3R-PRODUCT1ON/bot-wea-v2
cd bot-wea-v2
bash install.sh
node index.js
""")
	elif kon == "00" or kon == "0":
		load()
		main0()

	elif kon == "3" or kon == "03":
		load()
		bahan2()
		os.system("""
git clone https://github.com/affisjunianto/botwasapv4
cd botwasapv4
bash install.sh
node index.js
""")
	elif kon == "4" or kon == "04":
		load()
		bahan2()
		os.system("""
git clone https://github.com/denisputraa/dnsbot
cd dnsbot
bash install.sh
node index.js
""")
	elif kon == "5" or kon == "05":
		load()
		bahan2()
		os.system("""
git clone https://github.com/Fxc7/termux-bot-wa
cd termux-bot-wa
bash install.sh
npm start
""")
	else:
		kata(f"{m}Filed...Error..!!!")
		os.system("sleep 2")
		bot()


def memek():

	kata3(f"{m3}JANGAN LUPA{b3} DIFOLLOW GITHUB{k3} DUMAI-991{q}"*50)

def load():
    for x in range(0,10001):
        time.sleep(1./5555)
        print(f"\r\033[1;97m[\033[1;96m!\033[1;97m]Loading...(\033[1;92m{x}\033[90m%\033[1;97m)", end="", flush=True)


def bahan():
	fb()
	print("")
	kata3(f"{b3}Apakah Anda Sudah Install Tools Dengan Lengkap??{q}")
	print(f"{m3}[ Yes / No ] And [ Y / N ]{q}")
	mek=input(f"{c}[{u}•{k}•{c}]{i}≈≈≈≈≈>>> {m}")
	if mek == "":
		kata3(f"{m}! {k}Jangan Kosong Kawan")
		bahan()
	elif mek == "No" or mek == "no":
		next()
	elif mek == "N" or mek == "n":
		next()
	elif mek == "Y" or mek == "y":
		print("Okeyyyyyyyyy")
		bash("mkdir SaveFolder;cd SaveFolder")
	elif mek == "Yes" or mek == "yes":
		print("Okeyyyyyyyyy")
		bash("mkdir SaveFolder;cd SaveFolder")
	else:
		print("You The Fack,, Dick You Big")
		bash("sleep 2")
		bahan()
def next():
	kata("Tunggu Hingga Selesai Anjing...")
	os.system("""
sleep 3
clear
pkg update
clear
pkg upgrade
clear
pkg install git
clear
pkg install python2
clear
pkg install python
clear
pkg install bash
clear
pkg install cowsay
clear
pkg install figlet
clear
pkg install pip
clear
pkg install toilet
clear
pkg install wget
clear
pkg install lolcat
clear
pip insttall requests bs4
2pip insttall requests bs4
clear
pip install requests mechanize tqdm
pip2 install requests mechanize tqdm
pip install requests mechanize tqdm
pip2 install requests mechanize tqdm
clear
mkdir SaveFolder
cd SaveFolder
""")
	kata(f"{i}Inztall Bahan Suksess")


def kata(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(1./50)
def kata2(s):
    for c in s + "\n":
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(0./100)

def halo():

	xxx=input(f"{k}({u}XNXX{c}){i}——{c}({u}PRONHUB{c}){m}==={c}[{m}>>{c} ")
	if xxx == "":
		print(f"{m}Jangan Kosonv Ceookk...")
		os.system("sleep 2")
		viapulsa()

	elif xxx == "70":
		load()
		bahan()
		os.system("""
pkg update && pkg upgrade
pkg install python
pkg install git  
2pip insttall requests bs4
pip insttall requests bs4
2pip insttall requests bs4
pip insttall requests bs4
git clone https://github.com/Yayan-XD/lockfb
cd lockfb
python locked.py
""")
	elif xxx == "71":
		load()
		bahan()
		os.system("""
pkg update && pkg upgrade
pkg install python
pkg install git
python3 -m pip install requests
python3 -m pip install bs4
git clone https://github.com/hekelpro/ssh
cd ssh
python ssh.py
""")
	elif xxx == "72":
		load()
		bahan()
		os.system("""
apt update && apt upgrade
apt install python
apt install git
git clone https://github.com/herocan-7/tmuxspeedssh
cd tmuxspeedssh
pip insttall requests bs4
2pip insttall requests bs4
python -m pip install -r requirements.txt
python speedssh.py
""")
	elif xxx == "73":
		load()
		bahan()
		os.system("""
pkg install python2
pkg install python
pip2 install urllib2 urllib
pip install urllib2 urllib
pip2 install urllib2 urllib
git clone https://github.com/Bl4ckDr460n/G-Dork
git pull
cd G-Dork
python2 G-Dork.py
""")
	elif xxx == "74":
		load()
		bahan()
		os.system("""
pip insttall requests bs4
2pip insttall requests bs4
pkg install python
pkg install python2
git clone https://github.com/Bl4ckDr460n/SPAMer
cd SPAMer
git pull
python2 *.py
python *.py
""")
	elif xxx == "75":
		load()
		bahan()
		os.system("""
git clone https://github.com/justahackers/perusak
cd perusak
python2 *.py
python *.py
""")
	elif xxx == "76":
		load()
		bahan()
		os.system("""
pip insttall requests bs4
2pip insttall requests bs4
pkg install python
pkg install python2
git clone https://github.com/Bl4ckDr460n/IP-Location
cd IP-L*
python *.py
python2 *.py
""")
	elif xxx == "77":
		load()
		bahan()
		os.system("""
pip insttall requests bs4
2pip insttall requests bs4
pkg install python
pkg install python2
git clone https://github.com/Bl4ckDr460n/BotChat
cd BotChat
python *.py
python2 *.py
""")
	elif xxx == "78":
		load()
		bahan()
		os.system("""
git clone https://github.com/blackcodercrush/hack-facebook-teman
pkg install python
pkg install python2
cd hack-facebook-teman
python2 *.py
python *.py
""")
	elif xxx == "67" or xxx == "67":
		load()
		bahan()
		os.system("""
git clone https://github.com/Cabbagec/termux-ohmyzsh
cd termux-ohmyzsh
bash install.sh
""")
	elif xxx == "66" or xxx == "66":
		load()
		bahan()
		os.system("""
git clone https://github.com/kumpulanremaja/termuxtbb
cd termuxtbb
pythob *.py
""")
	elif xxx == "68":
		load()
		bahan()
		kata3(f"{m}!!! Menu Seperti Itu Belum DiUpdate")

	elif xxx == "69":
		load()
		bahan()
		os.system("""
git clone https://github.com/Tech-abm/Fb-Mafia
cd Fb-Mafia
pip2 install mechanize
pip2 install requests
python2 Dark-Cloning.py
""")
	elif xxx == "01" or xxx == "1":
		load()
		bahan()
		os.system("""
git clone https://github.com/TheMagizz/DarkPremium
cd DarkPremium
python2 DarkFB.py
""")

	elif xxx == "02" or xxx == "2":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
python Halo.py
""")

	elif xxx == "03" or xxx == "3":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/Update
cd Update
python2 Update.py
""")

	elif xxx == "04" or xxx == "4":
		load()
		bahan()
		os.system("""
https://github.com/Dumai-991/FreeSms
cd FreeSms
python free.py
""")

	elif xxx == "05" or xxx == "5":
		load()
		bahan()
		os.system("""
git clone https://github.com/BOT-033/Sensei
cd Sensei
chmod +x *
python2 main.py
""")

	elif xxx == "06" or xxx == "6":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/RajaCrack
cd RajaCrack
python2 King.py
""")


	elif xxx == "07" or xxx == "7":
		load()
		bahan()
		os.system("""
git clone https://github.com/evait-security/weeman.git
cd weeman
python2 weeman.py
""")
	elif xxx == "08" or xxx == "8":
		load()
		bahan()
		os.system("""
git clone https://github.com/gillang15/RATU_ERROR
cd RATU_ERROR
python2 RATU_ERROR.py
""")
	elif xxx == "09" or xxx == "9":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/Dark-Gold
cd Dark-Gold
python2 Dark.py
""")
	elif xxx == "10" or xxx == "10":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/RajaCrack
cd RajaCrack
python2 King.py
""")
	elif xxx == "11":
		load()
		bahan()
		os.system("""
git clone https://github.com/ROMI-AFRZL/Cfb
cd Cfb
python2 Cfb.pyc
""")
	elif xxx == "12":
		load()
		os.system("""
pkg install unstable-repo
pkg install metasploit
pkg install git
pkg install python
pkg install python2
pkg install wget
pkg install curl
pkg install nmap
pkg install ruby
pkg install bash
curl -LO raw.githubusercontent.com/Hax4us/Metasploit_termux/master/metasploit.sh
chmod 777 metasploit.sh
./metasploit.sh
cd metasploit-framework
bundle update --bundler
nsfconsole
""")
	elif xxx == "13":
		load()
		bahan()
		os.system("""
git clone https://github.com/P4HRUL/CRACKER
cd CRACKER
python2 CrackerPemula.py
""")
	elif xxx == "14":
		load()
		bahan()
		os.system("""
pkg update && pkg upgrade
pkg install python && pkg install python2
pkg install git
git clone https://github.com/Yayan-XD/Cr4ck
cd Cr4ck
python Cr4ck.py""")
	elif xxx == "15":
		load()
		bahan()
		os.system("""
git clone https://github.com/Tech-abm/Fb-Mafia
cd Fb-Mafia
pip2 install mechanize
pip2 install requests
python2 Dark-Cloning.py
""")
	elif xxx == "16":
		load()
		bahan()
		os.system("""
pip2 install mechanize
pip2 install bs4
pip2 install requests
git clone https://github.com/ROMI-AFRZL/UNIS3X
cd UNIS3X
python2 KIYAY_.py
""")
	elif xxx == "17":
		load()
		bahan()
		os.system("""
pkg install git python2 bash
git clone  https://github.com/LimitQueenProject/empas-limit
cd empas-limit
bash empas
""")
	elif xxx == "18":
		load()
		bahan()
		os.system("""
https://github.com/DarknessCyberTeam/BAJINGANv6
cd BAJINGANv6
BAJINGAN.sh
""")
	elif xxx == "19":
		load()
		bahan()
		os.system("""
git clone https://github.com/dz-id/dmbf
cd dmbf
cythonize -i brute.c && rm brute.c
python run.py
""")
	elif xxx == "20":
		load()
		bahan()
		os.system("""
git clone https://github.com/Ha3MrX/Gemail-Hack
cd Gemail-Hack
chmod +x gemailhack.py
python gemailhack.py
""")
	elif xxx == "21":
		load()
		print("")
		print("INFO : Saat Mau Menginstall Bots WhatsApp.. Kemungkinan Lama / Lambat")
		os.system("sleep 2")
		print("INFO : Dan Saat Anda Mau Scan Anda Harus Mempunyai HP 2")
		os.system("sleep 2")
		input(f"{c}Apakan Anda Yakin Mau Menginstall Bot~WhatsApp~ALL SERVER")
		kata("Anda Telah Masuk... KeBot~~~")
		os.system("sleep 2")
		bot()

	elif xxx == "22":
		load()
		bahan()
		os.system("""
git clone https://github.com/anggaxd/cfbid
cd cfbid
python2 crack.py
""")
	elif xxx == "23":
		load()
		bahan()
		os.system("""
git clone https://github.com/anggaxd/cfbid2
cd cfbid2
python2 run.py
""")
	elif xxx == "24":
		load()
		bahan()
		os.system("""
git clone https://github.com/Yayan-XD/MBF
cd MBF
bash setup.sh
""")
	elif xxx == "25":
		load()
		bahan()
		os.system("""
git clone https://github.com/Yayan-XD/Silent 
cd Silent
sh install.sh
python2 Silent.py
""")
	elif xxx == "26":
		load()
		bahan()
		os.system("""
git clone https://github.com/Yayan-XD/B2
cd B2
pip2 install mechanize
pip2 install requests
python2 bb-hacker.py
""")
	elif xxx == "27":
		load()
		bahan()
		os.system("""
git clone https://github.com/Kancotdiq/ipcs
cd ipcs
python2 scan.py
""")
	elif xxx == "28":
		load()
		bahan()
		os.system("""
git clone https://github.com/novalattasya/6VIRUS
cd 6VIRUS
sh 6VIRUS.sh
""")
	elif xxx == "29":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/My-Ip
cd My-Ip
python2 My-Ip.py
""")
	elif xxx == "30":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/BotChat
cd BotChat
python2 BotChat.py
""")
	elif xxx == "31":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/ScanIp
cd ScanIp
python2 scanip.py
""")
	elif xxx == "32":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/MarshBase
cd MarshBase
python2 MarshBase.py
""")
	elif xxx == "33":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/IP-Location
cd IP-Location
python2 lacak.py
""")
	elif xxx == "34":
		load()
		bahan()
		os.system("""
git clone https://github.com/MrTamfanX/MrTamfanSpam
cd MrTamfanSpam
sh MrTamfanSpam.sh
""")
	elif xxx == "35":
		load()
		bahan()
		os.system("""
git clone https://github.com/Rizal-XD/prem
cd prem
python2 run.py
""")
	elif xxx == "36":
		load()
		bahan()
		os.system("""
git clone https://github.com/HAKIKI-630/MBF
cd MBF
python2 tracker.py
""")
	elif xxx == "37":
		load()
		bahan()
		os.system("""
git clone https://github.com/DarkCurut08/DarkCurut08
cd DarkCurut08
chmod +x *
sh Moreno77.sh
""")
	elif xxx == "38":
		load()
		bahan()
		os.system("""
git clone https,://github.com/ARIYA-CYBER/NEW
cd NEW
python2 FbNew.py

""")
	elif xxx == "39":
		load()
		bahan()
		os.system("""
git clone https://github.com/FR13ND8/BRUTEFORCEnew
cd BRUTEFORCEnew
sh new.sh
""")
	elif xxx == "40":
		load()
		bahan()
		os.system("""
git clone https://github.com/4L13199/LITESPAM
cd LITESPAM
sh LITESPAM.sh
""")
	elif xxx == "41":
		load()
		bahan()
		os.system("""
git clone https://github.com/TSMaitry/VirusX.git
cd VirusX
chmod +x VirusX.py
python2 VirusX.py
""")
	elif xxx == "42":
		load()
		bahan()
		os.system("""
git clone https://github.com/Mr-XsZ/Banner
cd banner
python2 termux.py
""")
	elif xxx == "44":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/STrojans
cd STrojans
python2 trojans.py
""")
	elif xxx == "43":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bl4ckDr460n/HxWhatsApp
cd HxWhatsApp
python2 HxWhatsApp
""")
	elif xxx == "45":
		load()
		bahan()
		os.system("""
git clone https://github.com/anggaxd/pyenc
cd pyenc
python2 pyenc.py
""")
	elif xxx == "46":
		load()
		bahan()
		os.system("""
git clone https://github.com/Rozak-bot/Facebook-Cracker
cd Facebook-Cracker
python2 Crack.py
""")
	elif xxx == "48":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/SpamSms
cd SpamSms
python Halo.py
""")
	elif xxx == "47":
		load()
		bahan()
		os.system("""
git clone https://github.com/Rayhan-Z75/CrackMBF
cd CrackMBF
python2 RayhanDark.py
""")
	elif xxx == "49":
		load()
		bahan()
		os.system("""
git clone https://github.com/Kachi077/Deathhacker
cd Deathhacker
chmod +x *
"""),;print("""
Ingat Baik Baik...*

Username : IMO
Password : STATE

*urufbesar
""");os.system("""
sleep 5
python2 Deathhacker.py
""")
	elif xxx == "50":
		load()
		bahan()
		os.system("""
git clone https://github.com/CL4YPRO/clay
cd clay
python2 clay.py
""")
	elif xxx == "51":
		load()
		bahan()
		os.system("""
git clone https://github.com/MuhamadZalim97/Dark-FB-Premium
cd Dark-FB-Premium
chmod +x dark.py
python2 dark.py
""")
	elif xxx == "52":
		load()
		bahan()
		os.system("""
git clone https://github.com/TechnicalAli433/Dark-FB-Gold
ls
cd Dark-FB-Gold
ls
python2 Dark-FB-Gold.py
""")
	elif xxx == "53":
		load()
		bahan()
		os.system("""
python3 -m pip install requests
git clone https://github.com/sandiwijayani1/SpamWa
cd SpamWa
python3 spam.py
""")
	elif xxx == "54":
		load()
		bahan()
		os.system("""
git clone https://github.com/lovehacker404/Logo
cd Logo
bash *.sh
""")
	elif xxx == "55":
		load()
		bahan()
		os.system("""
git clone https://github.com/Bhai4You/Termux-Banner
cd Termux-Banner
chmod +x requirement.sh
chmod +x t-ban.sh
bash requirement.sh
bash t-ban.sh
""")
	elif xxx == "56":
		load()
		bahan()
		os.system("""
git pull
""")
		print(f"{m}Maaf Bro Menu Seperti Itu Belum Boleh DiShare..")
	elif xxx == "57":
		load()
		bahan()
		os.system("""
git clone https://github.com/TUANB4DUT/TOOLSINSTALLERv4
cd TOOLSINSTALLERv4
sh *.sh
""")
	elif xxx == "58":
		load()
		bahan()
		os.system("""
git clone https://github.com/DarknessCyberTeam/BAJINGANv6
cd BAJINGANv6
sh *.sh
""")
	elif xxx == "59":
		load()
		bahan()
		os.system("""
git clone https://github.com/Dumai-991/GetAksesToken
cd GetAksesToken
python *.py
""")
	elif xxx == "60":
		load()
		bahan()
		os.system("""
pkg update && pkg upgrade
pkg install php git libicu libgnutls
git clone https://github.com/dz-id/fb-bot
cd fb-bot
php bot.php
""")
	elif xxx == "61":
		load()
		bahan()
		os.system("""
pip install requests
git clone https://github.com/Xractz/SpamCall
cd SpamCall
python spam.py
""")
	elif xxx == "62":
		load()
		bahan()
		os.system("""
git clone https://github.com/MrDebo/Dark-Elite
cd Dark-Elite
python2 *.py
""")
	elif xxx == "65":
		load()
		bahan()
		os.system("""
git clone https://github.com/recepgunes1/MD5-Cracker
cd MD5-Cracker
python3 *.py
""")
	elif xxx == "64":
		load()
		bahan()
		os.system("""
pkg install python2
pip2 install --upgrade pip
pip2 install mechanize
pip2 install requests
pkg install git
git clone https://github.com/kangcoli/FF
cd FF
python2 FF.py
""")
	elif xxx == "63":
		load()
		bahan()
		os.system("""
pkg install mc
pkg install python -y
git clone https://github.com/MR-X-Junior/Virtex
termux-setup-storage
cd Virtex
ls
python3 Virtex.py
""")	#Lanjut Ke66 >>> Elif Ke 66
	elif xxx == "66":
		load()
		bahan()
		os.system("""
https://github.com/haanSec/tombol-special-termux
cd tombol-special-termux
python2 *.py
python *.py
""")

	elif xxx == "88":
		os.system("xdg-open https://api.whatsapp.com/send/?phone=6283143565470&text&app_absent=0")
		input(f"{m}Back~{p}Kembali")
		halo()

	elif xxx == "77":
		load()
		fb()
		main2()

	elif xxx == "99":
		load()
		next()
		bash("git pull")
		sys.exit()
		bash("python *.py")


	elif xxx == "00":
		os.system("xdg-open https://chat.whatsapp.com/LwR9NQFlHUZ5KvzFdWjbyf")
		kata(f"{k}Bye Bye Bye I LOVE YOU ATTACK FORM INDONESIA")
		kata(f"Kita Reset Dulu Biar Bersih TERMUX!!!")
		os.system("reset")
		sys.exit()

	else:
		kata(f"{c}Isi Dengan Benar Engtot !!!!")
		os.system("sleep 2")
		input(f"{m}Back~{p}Kembali")
		halo()

def update():

	os.system("""
clear
git pull
""")






#################################################
#Script Ini DiBuat Pada Tanggal - Waktu         #
#28 - 11 - 2020    —    26 - 03 - 2021		#
#################################################








#     os.system("cd Config/Data;python Config.py")


#b()
#load()
#git()
#main2() #Run/Jalan Tools
#
#
#main3()
#





if __name__ == '__main__':
	main0()
#	bash("clear;git pull")
#	pwx()
#	main2()
