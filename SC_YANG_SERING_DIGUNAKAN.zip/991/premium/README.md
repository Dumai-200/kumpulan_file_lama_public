# ✭ PREMIUM CRACK
#### Made With ❤️ By Dapunta
## ⇨  Feature Login
[✯] Login Cookies  
[✯] Login Token  
[✯] Cookies/Token Awet  
## ⇨  Feature Crack
[✯] Crack From Friend, Public, Followers, Likers    
[✯] Crack Default/Manual Pass  
[✯] Crack Methode Api, Mbasic, Free FB  
[✯] Crack With TTL  
[✯] Crack Default 7 Password  
- name  
- name123  
- name12345  
- anjing  
- sayang  
- bismillah
- 123456
## ⇨  Install Script On Termux
$ pkg update && upgrade  
$ pkg install python  
$ pkg install git  
$ pip install bs4  
$ pip install requests  
$ pip install mechanize  
$ pip install futures  
$ rm -rf premium  
$ git clone https://github.com/Dapunta/premium  
## ⇨  Run Script
$ cd premium  
$ python premium.py  
