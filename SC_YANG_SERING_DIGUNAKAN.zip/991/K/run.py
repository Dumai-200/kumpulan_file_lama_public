#LUPA TAMBAH FILE CODE GIT PULL DIDMBF
#RECODER AJA NGAB ENGGA DIENC :)
#m.fecebook.com/llovexnxx

import os,sys,time

os.system("git pull")
time.sleep(1)
os.system("python2 .dmbf.py")
