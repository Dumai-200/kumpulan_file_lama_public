###### Selamat Datang DiGithub Dumai-991
**Terima Kasih Kepada**
* **Anggaxd** Penulis Script Hack Facebook
* **Yayanxd** Penulis Script Get Informasih Facebook Target
* **Mr.Risky** Penyusun Script Dan Menggabungkan Script

### Informasih
* Login Bisa Menggunakan Metode 
1. Token Facebook
2. Cookies Facebook

* Script Menggunakan Method
1. MBasic

* Crack Menggunakan Metode
1. Crack From Public
2. Crack Form Followers
3. Crack Form Like

* Menu Tambahan
1. Get Informasih Target
2. Delete Token Facebook
3. User Status ( Not Premium )

### Bahan 
```
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install php
pkg install bash
pkg install wget
pkg install git
pkg install figlet
pkg install cowsay
pkg install lolcat
pkg install toilet
pkg install pyfiglet
gem install lolcat
git clone https://github.com/Dumai-991/dmbf
cd dmbf
```
* _Untuk Update Script Ketik_ ```git pull```

### Run And Stop Script
* Untuk Jalankan Script Ketik :
```
python2 dmbf.py
```
* Untuk Stopkan Script :
_Tekan CTRL + Z_

### Akun Sosial
* [**Facebook**](https://fb.me/llovexnxx)
* [**Whatsapp**](https://wa.me/6283143565470)

### Donasi Ngab
* DANA : ```083143565470```
* OVO  : ```083143565470```
* GOPAY: ```083143565470```

###### TERIMA KASIH YANG TELAH DONASI KEPADA SAYA... :)

#### INFORMASI CRACK
* **Jika Hasil Cp Silahkan Tunggu Hinggal 7-9 Hari Baru KeBuka Sensi Cp**
* **METHODNYA MBASIC JADI PROSESHACKNYA LAMA**
<p align="center">
<img src="https://raw.githubusercontent.com/Dumai-991/dmbf/main/Screenshot_2021-06-14-12-19-04-13.jpg">
</p>
<p align="center">
