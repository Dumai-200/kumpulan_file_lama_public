pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install bash
pkg install lolcat
pkg install cowsay
pkg install figlet
pkg install ruby
pkg install bs4
pip install bs4
apt update && apt upgrade
apt-get install python
apt-get install git
python -m pip install -r python.txt
python -m pip install requests
python -m pip install bs4
python -m pip install mechanize
python -m pip install click
python -m pip install prompt_toolkit
python -m pip install crayons
python2 -m pip install requests
python2 -m pip install bs4
python2 -m pip install mechanize
python2 -m pip install click
python2 -m pip install prompt_toolkit
python2 -m pip install crayons
reset
clear
figlet "Tes"
lolcat "Tes"
cowsay "Tes"
sleep 1
echo "Silahkan Ketik : python AllTools.py"
