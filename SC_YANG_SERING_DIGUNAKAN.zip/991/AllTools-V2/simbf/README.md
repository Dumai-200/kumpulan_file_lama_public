# Information
* Type : "git pull" For Updates Tools
* Method Crack https://b-api.facebook.com
* Log in With Token And Cookie (anti checkpoint, don't use new account)
* Have Any Problem Login Token Please Check This : https://www.facebook.com/100015073506062/posts/1137297496782690/?app=fbl

# Command
```
$ pkg install python2 git
$ pip2 install requests
$ git clone https://github.com/anggaxd/simbf
$ cd simbf
$ python2 run.py
```

<h3 align="center">My Social Media</h3>
<p align="center">
<a href="https://www.instagram.com/gaaarzxd" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/instagram.svg" alt="_asmin19" height="30" width="40" /></a>
<a href="https://www.facebook.com/gaaaarzxd" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/facebook.svg" alt="zettid.1" height="30" width="40" /></a>
<a href="https://m.youtube.com/channel/UCyRQesO6I0SgE2RbGfRPS7g" target="blank"><img align="center" src="https://cdn.jsdelivr.net/npm/simple-icons@3.0.1/icons/youtube.svg" alt="asmin dev" height="30" width="40" /></a>
</p>
