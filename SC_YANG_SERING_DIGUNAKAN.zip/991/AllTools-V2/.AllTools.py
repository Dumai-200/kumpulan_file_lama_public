# • Semoga Yang Recoder Pendek Umur.. Amin
# • Walau Pun Karia Ku Engga Seberapa 
#   Tapi Lo Bisa Engga Menghargai Karia Orang :V
# • Karia Ku Cumalah Kertas... Sekali DiRecoder Pasti Kalian Terkejut

import base64
exec(base64.b64decode("ICAgX19fX18gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAvIF9fXy9fX19fIF9fXyAgX19fX19fIF9fX19fICBfX19fIF8KICBcX18gXC8gX18gYC8gLyAvIC8gX18gYC8gX18gXC8gX18gYC8KIF9fXy8gLyAvXy8gLyAvXy8gLyAvXy8gLyAvIC8gLyAvXy8gLyAKL19fX18vXF9fLF8vXF9fLCAvXF9fLF8vXy8gL18vXF9fLCAvICAKICAgICAgICAgICAvX19fXy8gICAgICAgICAgICAvX19fXy8gICAK"))

