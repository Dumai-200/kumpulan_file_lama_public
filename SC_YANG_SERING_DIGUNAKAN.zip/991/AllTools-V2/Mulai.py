i='\033[1;32m'
c='\033[1;36m'
m='\033[1;31m'
u='\033[1;35m'
k='\033[1;33m'
p='\033[1;37m'
h='\033[1;90m'
import sys,os


if sys.version[0] in '2':
#	print(i+"Ketik : "+m+"python3 Mulai.py")
        exit(k+"Silahkan Gunakan Python3 Atau Version 3")

os.system("python .AllTools.py")













#1 2 3 TUTUP BOTOL YANG RECODER ANAK KNTL !!!
#Hahaha MaunRecoderManaBisa..
#Belilah Scriptnya.. Murah Kok :)
