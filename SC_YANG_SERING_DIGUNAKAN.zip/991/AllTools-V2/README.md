# Information Scripy
* By     : Mr.Risky
* Version: python3
* Enc    : Base64
* Whatsapp: 6283143565470


# Cooy Right
* Dapunta
* AnggaXD
* Fxc7
* Akira
* YayanXD
* MankBarBer
* DarkFB
* DLL


# Bahan²
```
CARA INSTALL BAHAN !!

pkg update
pkg upgrade
pkg install cowsay
pkg install python
pkg install python2
pkg install lolcat
gem install lolcat
pkg install figlet
pkg install toilet
pip -m install -r python.txt
git clone https://github.com/Dumai-991/AllTools-V2
cd AllTools-V2
python Mulai.py
```

# Akun Sosial
* https://m.facebook.com/ilovexnxx
* https://github.com/Dumai-991
* https://github.com/Dumai-200
