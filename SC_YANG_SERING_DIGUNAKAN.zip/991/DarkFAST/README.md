![](https://raw.githubusercontent.com/Dumai-991/DarkFAST/main/Image/Screenshot_2021-06-19-18-28-41-11.jpg)



### Information
* **Saya Tidak Bertanggung Jawab Atas Terjadi Masalahnya... Apapun Itu...**
* **Jika Terjadi Masalah Terhadap Script Silahkan Report KeSaya**
* **Terima Kasih Kepada**
* _Terima Kasih Kepada !!_
* [**Mr.Risky**](https://github.com/Dumai-991)
* [**Hamzah**](https://github.com/Hamzahash)
* [**AnggaXD**](https://github.com/anggaxd/anggaxd)
* [**Yayan-XD**](https://github.com/Yayan-XD)
* [**Dapunta**](https://github.com/Dapunta)

### Information Script
* _Script Ini Menggunakan 4 Method Login_
1. **B-Api Facebook**
2. **MBasic Facebook**
3. **Free Facebook**
4. **Mobile Facebook**

* _Script Ini Juga Menggunakan 6 Metode Crack_
1. **Crack Dari Teman Sendiri**
2. **Crack Dari Public**
3. **Crack Dari Followers**
4. **Crack Dari Anggota Group**
5. **Crack Dari Like Post**
6. **Crack Dari Pencarian Nama !!**

* _Script Ini Login Menggunakan_
1. **Cookies**

### Donasi Ngab
* Dana : ```083143565470```
* Ovo. : ```083143565470```
* Gopay: ```083143565470```
* Pulsa: ```083143565470``` _AXIS_

### Akun Sosial
* [Facebook](m.facebook.com/llovexnxx)
* [WhatsApp](https://wa.me/6283143565470)
* [Github](github.com/Dumai-991)

### Bahan
```
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install php
pkg install bash
pkg install wget
pkg install git
pkg install figlet
pkg install cowsay
pkg install lolcat
pkg install toilet
pkg install pyfiglet
gem install lolcat
rm -rf *
git clone https://github.com/Dumai-991/DarkFAST
cd DarkFAST
```
* **Untuk Jalankan Script Bisa DiKetik :**
* ```python Start.py```

* **Untuk Stop Script Tekan :**
* ```CTRL + Z```
