# how to install
```php
$ pkg install git python -y
$ git clone https://github.com/itsuki10/drag-fb
$ cd drag-fb
$ pip install -r requirements.txt
$ python main.py
```
<h3><a href="https://m.facebook.com/profile.php?id=100068019551652">contact me on facebook</a></h3><br><br>

