# hallo bro :v

pw_tambahan="""

kontol|sayang|indonesia|bajingan|anjing

""".strip().split("|")
ngntd=((())>(()))+((())>(()))
def awok(ngentod):
	return [ngentod,ngentod+"1234",ngentod+"123456",ngentod+"123",ngentod+"12345"]
def pw_list(ngentot):
	if len(ngentot)==2:
		aap_afandi=ngentot[1].split(" ")
		if len(aap_afandi[ngntd])!=ngntd:
			asu=awok(aap_afandi[ngntd].lower())
			if len(aap_afandi[ngntd]) < 6:
				del asu[ngntd]
				[asu.append(x) for x in pw_tambahan]
			else:
				[asu.append(x) for x in pw_tambahan]
		else: asu=pw_tambahan
	else: asu=pw_tambahan
	return asu
