import requests, bs4, sys, os, subprocess, random, time, re, json
import concurrent.futures
from datetime import datetime
from time import sleep
from requests import Session
import re, sys
import sys
from os import system
import os, sys, time, random
from sys import exit as keluar
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from sys import stdout
from os import system
import re
import os,random,time,sys
import json
try: import requests
except ModuleNotFoundError: os.system("python -m pip install requests &> /dev/null")
try: import bs4
except ModuleNotFoundError: os.system("python -m pip install bs4 &> /dev/null")
import requests as req
from time import sleep as waktu
from bs4 import BeautifulSoup as parser
koneksi_error=(req.exceptions.ConnectionError,req.exceptions.ChunkedEncodingError,req.exceptions.ReadTimeout)
N="\033[00m"
q="\033[00m"
h2="\033[40m"
b2="\033[44m"
c2="\033[46m"
i2="\033[42m"
u2="\033[45m"
m2="\033[41m"
p2="\033[47m"
k2="\033[43m"
b='\033[0;34m'
i='\033[0;32m'
c='\033[0;36m'
m='\033[0;31m'
u='\033[0;35m'
k='\033[0;33m'
p='\033[0;37m'
h='\033[0;90m'
b='\033[0;34m'
I='\033[0;32m'
C='\033[0;36m'
M='\033[0;31m'
U='\033[0;35m'
K='\033[0;33m'
P='\033[0;37m'
H='\033[0;90m'
warna_me=([i, c, m, u, k, p, h, b])
warna_ms=([i, c, m, u, k, p, h, b])
w2=(warna_me)
w=pilih(warna_me)
kosong1="Anda Tau Kontol Engga"
kosong2="Kosong...???"
pilih1="Pilihan Ini Tidak Terdaftar !!"
pilih2="Menu Pilihan Anda Tidak Ada Pantem"
tunggu1="Tunggu Bentar Ngab"
def kembali(kata,fuck=None):
        print(kata)
        waktu(2)
        fuck() if fuck is not None else exit()
def head(url,respons):
        return {"Host":url.split("//")[1],"upgrade-insecure-requests":"1","cache-control":"max-age=0","content-type":"application/x-www-form-urlencoded","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","referer":respons.url,"accept-encoding":"gzip, deflate, br","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7","user-agent":"Mozilla/5.0 (Linux; Android 5.1.1; SM-G600S Build/LMY47V; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/59.0.3071.125 Mobile Safari/537.36"}
def kntl():
#                 %s"[ K N T L ]"
        lpp___1 =("%s[          "%(k))
        lpp___2 =("%s[ %sK        "%(k, m))
        lpp___3 =("%s[ %sK %sN      "%(k, m, u))
        lpp___4 =("%s[ %sK %sN %sT    "%(k, m, u, c))
        lpp___5 =("%s[ %sK %sN %sT %sL "%(k, m, u, c, b))
        lpp___6 =("%s[ %sK %sN %sT %sL %s]"%(k, m, u, c, b, k))
        lpp___7 =("%s[ %sK %sN %sT %sL %s]"%(k, m, u, c, b, k))
        lpp___8 =("%s[ %sK %sN %sT %sL "%(k, m, u, c, b))
        lpp___9 =("%s[ %sK %sN %sT    "%(k, m, u, c))
        lpp___10 =("%s[ %sK %sN      "%(k, m, u))
        lpp___11 =("%s[ %sK        "%(k, m))
        lpp___12 =("%s           "%(k))
        lpp___13 =("%s[         ]"%(k))
        lpp___14 =("  %sK %sN %sT %sL  "%(m, u, c, b,))
        lpp___15 =("%s[          "%(k))
        lpp___16 =("%s          ]"%(k))
        lpp___17 =("%s[ %sD %sO %sN %sE %s]"%(k, i, i, i, i, k))

        lpp___all = ([lpp___1, lpp___2, lpp___3, lpp___4, lpp___5, lpp___6,lpp___7, lpp___8, lpp___9,lpp___10, lpp___11, lpp___12, lpp___13,lpp___14, lpp___13, lpp___14, lpp___13, lpp___14, lpp___13, lpp___14, lpp___15, lpp___16, lpp___17])
        for x in lpp___all:
            stdout.write(f'\r %s[%s{w}LPP%s]--->> %s'%(N,w,N,x)),
            stdout.flush()
            time.sleep(0.4)
def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(1./550)
