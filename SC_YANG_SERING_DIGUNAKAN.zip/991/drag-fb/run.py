#KangRecoder!!


import sys,shutil,os,time

runtah=["AKIRA_BOTZ/__pycache__","modul/__pycache__","wibu/__pycache__","AKIRA_BOTZ/ngewe/__pycache__"]

if sys.version[0]!="3":
	exit(" ! Harap Gunakan Python 3\n ! Ketik : python main.py")

from AKIRA_BOTZ import awokawokawok as sayang
try: [shutil.rmtree(x) for x in runtah]
except: pass
#awokawokawok()
os.system("reset;git pull;clear")
sayang()
