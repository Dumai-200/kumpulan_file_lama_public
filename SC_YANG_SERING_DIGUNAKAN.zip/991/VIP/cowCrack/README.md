# cowCrack
Ini adalah tool crack atau bruteforce facebook!
# Command Installed
```BASH
$ pkg install python
$ pkg install git
$ git clone https://github.com/Latip176/cowCrack
$ pip install requests bs4
$ cd cowCrack
$ python sapi.py
```
# Note:
Saya tidak bertanggung jawab atas semua hal yang terjadi kepada Anda karena memakai tool ini.
Saya hanya seorang author yang membuat tools dengan bahasa pemerogramman. Saya harap ini berguna.
