#### Usage?
````bash
$ pkg install git python
$ python -m pip install requests bs4
$ git clone https://github.com/dahlahmales/nmbf
$ cd nmbf
$ python main.py
````
