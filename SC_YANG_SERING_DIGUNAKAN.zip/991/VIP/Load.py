import time
from tqdm import tqdm

print("Bang Risky Ganteng")
xnxx = input("Text : ")
print(f"Sedang : {xnxx}")
for x in tqdm(range(100)):
    time.sleep(0.3)
print(f"Sukses {xnxx}")

# !! ....... Hapus Jadi (Spasi)
